pub mod logs;
mod overview;
pub(crate) mod package_manager;

mod bisect;
mod cluster_settings;
mod datapacks;
mod folder_list;
mod imported_modpacks;
mod modpack_settings;
mod mods;
mod process_logs;
mod screenshots;
mod shaders;
mod textures;
mod worlds;

pub use logs::{ClusterLogs, OpenGameOutput};
pub use overview::ClusterOverview;

pub(crate) use bisect::{BisectBanner, BisectQuestion, FindProblemModRow};
pub use cluster_settings::ClusterSettings;
pub use datapacks::ClusterDataPacks;
pub(crate) use folder_list::{confirm_dialog, dialog, supports_datapacks};
pub use mods::ClusterMods;
pub use process_logs::ProcessLogs;
pub use screenshots::ClusterScreenshots;
pub use shaders::ClusterShaders;
pub use textures::ClusterTextures;
pub use worlds::ClusterWorlds;

use freya::prelude::*;

use crate::i18n::t;
use crate::theme::{colors, text_size};

pub(crate) fn cluster_not_found() -> Element {
    rect()
        .width(Size::fill())
        .height(Size::fill())
        .center()
        .child(
            label()
                .text(t("oneclient.cluster.not_found"))
                .font_size(text_size(14.))
                .color(colors::fg_secondary()),
        )
        .into_element()
}
