use std::path::PathBuf;

use freya::prelude::*;
use oneclient_common::parse_mc_version;
use oneclient_core::clusters::Cluster;
use oneclient_core::settings::ViewLayout;

use crate::components::{
    Button, CARD_GRID_H, CARD_H, CardLayout, GRID_GAP, GRID_MIN_W, Icon, IconType, LocalImage,
    OverlayPopup, ScrollArea, Segment, SegmentedControl, TextInput, badge, icon_box, kebab_button,
    meta_size, meta_text, on_secondary, open_folder_button,
};
use crate::hooks::{
    loaded_image, settled_or_loading, use_cached_image, use_clusters, use_game_snapshot,
};
use crate::i18n::t;
use crate::theme::{colors, rounded, rounded_px, text_size};
use crate::ui::{ImageFallbackExt, border_all_color};

use super::package_manager::{CARD_SPACING, GRID_MAX_COLS, notice_bar};

const CONTROL_H: f32 = 34.;
const SEARCH_W: f32 = 180.;
const IMAGE_EDGE: u32 = 128;
const FIRST_DATAPACK_MAJOR: u32 = 13;

#[derive(Clone, Copy)]
pub(super) struct RowHeights {
    pub list: f32,
    pub grid: f32,
}

pub(super) const PACKAGE_ROWS: RowHeights = RowHeights {
    list: CARD_H,
    grid: CARD_GRID_H,
};

pub(crate) fn supports_datapacks(mc_version: &str) -> bool {
    parse_mc_version(mc_version).is_none_or(|p| p.major >= FIRST_DATAPACK_MAJOR)
}

pub(super) fn use_game_folder_in_use(cluster: Option<&Cluster>) -> bool {
    let game = use_game_snapshot();
    let clusters = settled_or_loading(&use_clusters()).unwrap_or_default();

    cluster.is_some_and(|cluster| {
        game.is_active(cluster.id)
            || clusters
                .iter()
                .any(|c| game.is_active(c.id) && c.shares_dir_with(cluster))
    })
}

pub(super) fn notify_in_use(dispatch: &crate::Actions, body: &'static str) {
    dispatch
        .notify(t("oneclient.cluster.folder_list.in_use.title"))
        .body(body)
        .error()
        .send();
}

pub(super) fn matches_search(needle: &str, fields: &[&str]) -> bool {
    needle.is_empty() || fields.iter().any(|f| f.to_lowercase().contains(needle))
}

pub(super) fn toolbar_panel(leading: Option<Element>, controls: Vec<Element>) -> Element {
    let mut top_corners = CornerRadius::new_all(0.);
    top_corners.fill_top(rounded_px(12.));

    rect()
        .vertical()
        .width(Size::fill())
        .overflow(Overflow::Clip)
        .padding(Gaps::new_symmetric(8., 12.))
        .corner_radius(top_corners)
        .background(colors::page_elevated())
        .child(
            rect()
                .horizontal()
                .width(Size::fill())
                .cross_align(Alignment::Center)
                .spacing(8.)
                .content(Content::Flex)
                .child(
                    rect()
                        .horizontal()
                        .width(Size::flex(1.0))
                        .height(Size::px(CONTROL_H))
                        .cross_align(Alignment::Center)
                        .maybe_child(leading),
                )
                .children(controls),
        )
        .into_element()
}

pub(super) fn search_input(search: State<String>) -> Element {
    TextInput::new(search)
        .placeholder(t("oneclient.cluster.package_manager.search"))
        .width(Size::px(SEARCH_W))
        .leading(
            Icon::new(IconType::SearchMd)
                .size(14.)
                .color(colors::fg_secondary())
                .into_element(),
        )
        .into_element()
}

pub(super) fn folder_button(folder: PathBuf) -> Element {
    open_folder_button(folder)
        .width(Size::px(CONTROL_H))
        .height(Size::px(CONTROL_H))
        .into_element()
}

pub(super) fn layout_toggle(layout: State<ViewLayout>) -> Element {
    SegmentedControl::new(layout)
        .height(CONTROL_H)
        .icon_size(15.)
        .equal_width(CONTROL_H)
        .segment(Segment::new(ViewLayout::List).icon(IconType::ParagraphWrap))
        .segment(Segment::new(ViewLayout::Grid).icon(IconType::DotsGrid))
        .into_element()
}

pub(super) fn toolbar_action(icon: IconType, text: &str) -> Button {
    Button::new()
        .primary()
        .height(Size::px(CONTROL_H))
        .font_size(text_size(12.))
        .child(Icon::new(icon).size(15.))
        .text(text.to_string())
}

pub(super) fn content_box(
    count: usize,
    layout: CardLayout,
    heights: RowHeights,
    row: impl Fn(usize) -> Element + 'static,
    empty: Option<Element>,
    notices: Vec<String>,
) -> Element {
    let scroll = (count > 0).then(|| {
        let area = ScrollArea::new()
            .width(Size::fill())
            .height(Size::flex(1.0))
            .scrollbar_gutter(true);
        match layout {
            CardLayout::List => area.lazy(count, heights.list, CARD_SPACING, row),
            CardLayout::Grid => area.lazy_grid(
                count,
                heights.grid,
                GRID_GAP,
                GRID_MIN_W,
                GRID_MAX_COLS,
                row,
            ),
        }
        .into_element()
    });

    let mut bottom_corners = CornerRadius::new_all(0.);
    bottom_corners.fill_bottom(rounded_px(12.));

    let empty = if count == 0 { empty } else { None };

    rect()
        .vertical()
        .width(Size::fill())
        .height(Size::flex(1.0))
        .padding(Gaps::new(0., 12., 12., 12.))
        .corner_radius(bottom_corners)
        .background(colors::page_elevated())
        .overflow(Overflow::Clip)
        .content(Content::Flex)
        .children(notices.into_iter().map(notice_bar))
        .maybe_child(scroll)
        .maybe_child(empty.map(|empty| {
            rect()
                .width(Size::fill())
                .height(Size::flex(1.0))
                .child(empty)
                .into_element()
        }))
        .into_element()
}

#[derive(Clone, PartialEq)]
pub(super) enum CardIcon {
    Image(PathBuf),
    Cached(String, IconType),
    Symbol(IconType),
}

#[derive(PartialEq)]
struct CachedIcon {
    url: String,
    fallback: IconType,
    size: f32,
}

impl Component for CachedIcon {
    fn render(&self) -> impl IntoElement {
        let query = use_cached_image(Some(self.url.clone()), IMAGE_EDGE);

        match loaded_image(Some(&self.url), &query) {
            Some(loaded) => ImageViewer::new(loaded)
                .width(Size::px(self.size))
                .height(Size::px(self.size))
                .aspect_ratio(AspectRatio::Min)
                .corner_radius(rounded(8.))
                .fallback(icon_box(self.fallback, self.size))
                .into_element(),
            None => icon_box(self.fallback, self.size),
        }
    }
}

#[derive(PartialEq)]
pub(super) struct FolderCard {
    pub icon: CardIcon,
    pub title: String,
    pub badge: (IconType, String),
    pub description: Option<String>,
    pub size: u64,
    pub layout: CardLayout,
    pub on_context: EventHandler<(f32, f32)>,
}

impl Component for FolderCard {
    fn render(&self) -> impl IntoElement {
        let mut hovered = use_state(|| false);

        let icon = card_icon(
            &self.icon,
            match self.layout {
                CardLayout::List => 44.,
                CardLayout::Grid => 40.,
            },
        );
        let on_context = Some(self.on_context.clone());

        match self.layout {
            CardLayout::List => rect()
                .horizontal()
                .width(Size::fill())
                .height(Size::px(CARD_H))
                .cross_align(Alignment::Center)
                .spacing(12.)
                .padding(Gaps::new_all(10.))
                .corner_radius(rounded(8.))
                .background(colors::card())
                .content(Content::Flex)
                .on_secondary_down(on_secondary(on_context.clone()))
                .child(self.list_info(icon))
                .child(meta_size(self.size))
                .child(kebab_button(self.on_context.clone()))
                .into_element(),
            CardLayout::Grid => {
                let hovering = *hovered.read();
                let muted = colors::fg_primary().with_a(127);

                let header = rect()
                    .horizontal()
                    .width(Size::fill())
                    .spacing(11.)
                    .content(Content::Flex)
                    .child(icon)
                    .child(
                        rect()
                            .vertical()
                            .width(Size::flex(1.0))
                            .spacing(3.)
                            .child(
                                label()
                                    .text(self.title.clone())
                                    .font_size(text_size(14.))
                                    .font_weight(FontWeight::SEMI_BOLD)
                                    .max_lines(1)
                                    .text_overflow(TextOverflow::Ellipsis)
                                    .width(Size::fill())
                                    .color(colors::fg_strong()),
                            )
                            .child(meta_text(self.grid_meta(), muted)),
                    )
                    .child(kebab_button(self.on_context.clone()));

                let description = self.description.clone().map(|text| {
                    label()
                        .text(text)
                        .font_size(text_size(11.))
                        .line_height(1.45)
                        .max_lines(2)
                        .text_overflow(TextOverflow::Ellipsis)
                        .width(Size::fill())
                        .color(colors::fg_primary().with_a(183))
                        .into_element()
                });

                rect()
                    .vertical()
                    .width(Size::fill())
                    .height(Size::fill())
                    .spacing(9.)
                    .padding(Gaps::new_all(14.))
                    .corner_radius(rounded(6.))
                    .background(if hovering {
                        colors::component_bg_hover()
                    } else {
                        colors::component_bg()
                    })
                    .border(border_all_color(
                        1.,
                        if hovering {
                            colors::component_border_hover()
                        } else {
                            colors::component_border()
                        },
                    ))
                    .overflow(Overflow::Clip)
                    .content(Content::Flex)
                    .on_pointer_enter(move |_| hovered.set(true))
                    .on_pointer_leave(move |_| hovered.set(false))
                    .on_secondary_down(on_secondary(on_context))
                    .child(header)
                    .child(
                        rect()
                            .vertical()
                            .width(Size::fill())
                            .height(Size::flex(1.0))
                            .maybe_child(description),
                    )
                    .into_element()
            }
        }
    }
}

impl FolderCard {
    fn grid_meta(&self) -> String {
        let mut parts = vec![self.badge.1.clone()];
        if self.size > 0 {
            parts.push(crate::utils::format_size(self.size));
        }
        parts.join(" \u{b7} ")
    }

    fn list_info(&self, icon: Element) -> Element {
        rect()
            .horizontal()
            .width(Size::flex(1.0))
            .cross_align(Alignment::Center)
            .spacing(12.)
            .content(Content::Flex)
            .child(icon)
            .child(
                rect()
                    .vertical()
                    .width(Size::flex(1.0))
                    .spacing(3.)
                    .child(
                        rect()
                            .horizontal()
                            .width(Size::fill())
                            .cross_align(Alignment::Center)
                            .spacing(8.)
                            .child(
                                label()
                                    .text(self.title.clone())
                                    .font_size(text_size(15.))
                                    .font_weight(FontWeight::MEDIUM)
                                    .max_lines(1)
                                    .text_overflow(TextOverflow::Ellipsis)
                                    .max_width(Size::percent(60.))
                                    .color(colors::fg_primary()),
                            )
                            .child(badge(
                                Icon::new(self.badge.0)
                                    .size(12.)
                                    .color(colors::fg_secondary())
                                    .into_element(),
                                self.badge.1.clone(),
                            )),
                    )
                    .maybe_child(self.description.clone().map(|text| {
                        label()
                            .text(text)
                            .font_size(text_size(11.))
                            .max_lines(2)
                            .text_overflow(TextOverflow::Ellipsis)
                            .width(Size::fill())
                            .color(colors::fg_secondary())
                            .into_element()
                    })),
            )
            .into_element()
    }
}

pub(super) fn card_icon(icon: &CardIcon, size: f32) -> Element {
    match icon {
        CardIcon::Image(path) => rect()
            .width(Size::px(size))
            .height(Size::px(size))
            .corner_radius(rounded(8.))
            .overflow(Overflow::Clip)
            .background(colors::component_bg())
            .child(LocalImage::new(path.clone(), IMAGE_EDGE, true).skeleton(true))
            .into_element(),
        CardIcon::Cached(url, fallback) => CachedIcon {
            url: url.clone(),
            fallback: *fallback,
            size,
        }
        .into_element(),
        CardIcon::Symbol(symbol) => icon_box(*symbol, size),
    }
}

pub(crate) fn confirm_dialog(
    title: String,
    body: String,
    on_cancel: impl FnMut() + Clone + 'static,
    mut on_confirm: impl FnMut() + 'static,
) -> Element {
    let mut cancel = on_cancel.clone();

    dialog(
        title,
        body,
        None,
        on_cancel,
        [
            Button::new()
                .secondary()
                .on_press(move |_| cancel())
                .text(t("oneclient.common.cancel"))
                .into_element(),
            Button::new()
                .danger()
                .on_press(move |_| on_confirm())
                .child(Icon::new(IconType::Trash01).size(14.))
                .text(t("oneclient.common.delete"))
                .into_element(),
        ],
    )
}

pub(crate) fn dialog(
    title: String,
    body: String,
    control: Option<Element>,
    mut on_close: impl FnMut() + 'static,
    buttons: [Element; 2],
) -> Element {
    OverlayPopup::new()
        .on_close(move |_| on_close())
        .child(
            rect()
                .width(Size::window_percent(100.))
                .height(Size::window_percent(100.))
                .center()
                .child(
                    rect()
                        .vertical()
                        .width(Size::px(400.))
                        .max_width(Size::window_percent(90.))
                        .spacing(14.)
                        .padding(Gaps::new_all(20.))
                        .corner_radius(rounded(14.))
                        .background(colors::card())
                        .border(border_all_color(1., colors::component_border()))
                        .child(
                            label()
                                .text(title)
                                .font_size(text_size(16.))
                                .font_weight(FontWeight::SEMI_BOLD)
                                .color(colors::fg_primary()),
                        )
                        .child(
                            label()
                                .text(body)
                                .font_size(text_size(12.))
                                .color(colors::fg_secondary()),
                        )
                        .maybe_child(control)
                        .child(
                            rect()
                                .horizontal()
                                .width(Size::fill())
                                .main_align(Alignment::End)
                                .spacing(8.)
                                .children(buttons),
                        ),
                ),
        )
        .into_element()
}
