mod accounts;
mod appearance;
pub(crate) mod appearance_picker;

mod apis;
mod changelog;
mod developer;
mod java;
mod language;
mod launcher;
mod minecraft;
mod storage;
mod theme_editor;

use freya::prelude::*;

pub use accounts::SettingsAccounts;
pub use apis::SettingsApis;
pub use appearance::SettingsAppearance;
pub use changelog::SettingsChangelog;
pub use developer::SettingsDeveloper;
pub use java::SettingsJava;
pub use language::SettingsLanguage;
pub use launcher::SettingsLauncher;
pub use minecraft::SettingsMinecraft;
pub use storage::SettingsStorage;
pub use theme_editor::SettingsThemeEditor;

use crate::{
    components::{Button, Icon, IconType},
    i18n::t,
    theme::{colors, rounded, text_size},
    ui::border_all_color,
};

pub fn settings_page() -> Rect {
    rect().vertical().width(Size::fill()).spacing(4.)
}

pub fn section_header(text: &'static str) -> impl IntoElement {
    rect()
        .padding(Gaps::new(16., 0., 8., 2.))
        .child(
            label()
                .text(text)
                .font_size(text_size(13.))
                .font_weight(FontWeight::MEDIUM)
                .color(colors::fg_secondary()),
        )
        .into_element()
}

pub fn settings_row(
    icon: IconType,
    title: &'static str,
    description: impl Into<String>,
    trailing: impl IntoElement,
) -> impl IntoElement {
    settings_row_inner(icon, title, description, trailing, RowTone::Normal)
}

pub fn settings_row_disabled(
    icon: IconType,
    title: &'static str,
    description: impl Into<String>,
    trailing: impl IntoElement,
) -> impl IntoElement {
    settings_row_inner(icon, title, description, trailing, RowTone::Disabled)
}

/// For destructive actions, tinted red like the other danger notices
pub fn settings_row_danger(
    icon: IconType,
    title: &'static str,
    description: impl Into<String>,
    trailing: impl IntoElement,
) -> impl IntoElement {
    settings_row_inner(icon, title, description, trailing, RowTone::Danger)
}

#[derive(Clone, Copy, PartialEq)]
enum RowTone {
    Normal,
    Disabled,
    Danger,
}

fn settings_row_inner(
    icon: IconType,
    title: &'static str,
    description: impl Into<String>,
    trailing: impl IntoElement,
    tone: RowTone,
) -> impl IntoElement {
    let description = description.into();
    let danger = tone == RowTone::Danger;
    rect()
        .maybe(tone == RowTone::Disabled, |el| el.opacity(0.4))
        .horizontal()
        .width(Size::fill())
        .content(Content::Flex)
        .cross_align(Alignment::Center)
        .spacing(16.)
        .padding(Gaps::new_symmetric(12., 16.))
        .corner_radius(rounded(12.))
        .background(if danger {
            colors::danger().with_a(26)
        } else {
            colors::page_elevated()
        })
        .maybe(danger, |el| {
            el.border(border_all_color(1., colors::danger().with_a(128)))
        })
        .child(Icon::new(icon).maybe(danger, |icon| icon.color(colors::danger())))
        .child(
            rect()
                .vertical()
                .width(Size::flex(1.0))
                .spacing(2.)
                .child(
                    label()
                        .text(title)
                        .font_size(text_size(16.))
                        .font_weight(FontWeight::MEDIUM)
                        .color(colors::fg_primary()),
                )
                .child(
                    label()
                        .text(description)
                        .font_size(text_size(12.))
                        .color(colors::fg_secondary()),
                ),
        )
        .child(trailing)
        .into_element()
}

#[derive(PartialEq)]
struct ResetButton<T: Clone + PartialEq + 'static> {
    values: Vec<(State<T>, T)>,
}

impl<T: Clone + PartialEq + 'static> Component for ResetButton<T> {
    fn render(&self) -> impl IntoElement {
        let at_default = self
            .values
            .iter()
            .all(|(value, default)| *value.read() == *default);

        let values = self.values.clone();

        Button::new()
            .ghost()
            .icon()
            .disabled(at_default)
            .alt(if at_default {
                t("oneclient.settings.reset.at_default")
            } else {
                t("oneclient.settings.reset.to_default")
            })
            .on_press(move |_| {
                for (value, default) in &values {
                    let mut value = *value;
                    value.set(default.clone());
                }
            })
            .child(
                Icon::new(IconType::RefreshCcw02)
                    .size(14.)
                    .color(colors::fg_secondary()),
            )
    }
}

pub fn resettable<T: Clone + PartialEq + 'static>(
    control: impl IntoElement,
    value: State<T>,
    default: T,
) -> impl IntoElement {
    resettable_all(control, vec![(value, default)])
}

pub fn resettable_all<T: Clone + PartialEq + 'static>(
    control: impl IntoElement,
    values: Vec<(State<T>, T)>,
) -> impl IntoElement {
    rect()
        .horizontal()
        .cross_align(Alignment::Center)
        .spacing(8.)
        .child(control)
        .child(ResetButton { values })
        .into_element()
}
