use freya::prelude::*;

use crate::i18n::t;
use crate::theme;
use crate::theme::text_size;

#[derive(PartialEq, Clone)]
pub struct NotFound {
    pub path: Vec<String>,
}

impl Component for NotFound {
    fn render(&self) -> impl IntoElement {
        tracing::warn!("Route not found: /{}", self.path.join("/"));

        rect()
            .vertical()
            .width(Size::fill())
            .height(Size::fill())
            .overflow(Overflow::Clip)
            .padding(40.)
            .spacing(16.)
            .child(
                label()
                    .text(t("oneclient.not_found.title"))
                    .font_size(text_size(32.))
                    .font_weight(FontWeight::BOLD)
                    .color(theme::colors::fg_primary()),
            )
            .child(
                label()
                    .text(t("oneclient.not_found.description"))
                    .font_size(text_size(16.))
                    .color(theme::colors::fg_secondary()),
            )
    }
}
