use freya::prelude::*;
use oneclient_events::Answer;

use crate::i18n::t;
use crate::updater::UPDATE_CHOICE_INSTALL;

use crate::components::{Button, Icon, IconType, OverlayPopup};
use crate::hooks::{use_dispatch, use_notifications_snapshot};
use crate::theme::{colors, rounded, text_size};
use crate::ui::border_all_color;

#[derive(PartialEq)]
pub struct UpdatePromptOverlay;

impl Component for UpdatePromptOverlay {
    fn render(&self) -> impl IntoElement {
        let snapshot = use_notifications_snapshot();
        let dispatch = use_dispatch();

        let Some(prompt) = snapshot.pending_prompt.clone() else {
            return rect().into_element();
        };

        // Recognised by the choice it offers so the event layer needn't enumerate prompts
        if !prompt.has_choice(UPDATE_CHOICE_INSTALL) {
            return rect().into_element();
        }

        let dismiss_label = prompt
            .dismiss
            .clone()
            .unwrap_or_else(|| t("oneclient.components.update_prompt.not_now").to_string());
        let install_label = prompt
            .choice(UPDATE_CHOICE_INSTALL)
            .map(|choice| choice.label.clone())
            .unwrap_or_else(|| t("oneclient.common.download").to_string());

        let close = dispatch.clone();
        let cancel = dispatch.clone();
        let accept = dispatch.clone();

        OverlayPopup::new()
            .on_close(move |_| close.dismiss_prompt())
            .child(
                rect()
                    .width(Size::window_percent(100.))
                    .height(Size::window_percent(100.))
                    .center()
                    .child(
                        rect()
                            .vertical()
                            .width(Size::px(440.))
                            .max_width(Size::window_percent(90.))
                            .spacing(14.)
                            .padding(Gaps::new_all(20.))
                            .corner_radius(rounded(14.))
                            .background(colors::card())
                            .border(border_all_color(1., colors::component_border()))
                            .child(
                                rect()
                                    .horizontal()
                                    .cross_align(Alignment::Center)
                                    .spacing(10.)
                                    .child(
                                        Icon::new(IconType::DownloadCloud02)
                                            .size(20.)
                                            .color(colors::brand()),
                                    )
                                    .child(
                                        label()
                                            .text(prompt.title.clone())
                                            .font_size(text_size(16.))
                                            .font_weight(FontWeight::SEMI_BOLD)
                                            .color(colors::fg_primary()),
                                    ),
                            )
                            .child(
                                label()
                                    .text(prompt.question.clone())
                                    .font_size(text_size(12.))
                                    .max_lines(4)
                                    .width(Size::fill())
                                    .color(colors::fg_secondary()),
                            )
                            .child(
                                rect()
                                    .horizontal()
                                    .width(Size::fill())
                                    .main_align(Alignment::End)
                                    .spacing(8.)
                                    .child(
                                        Button::new()
                                            .secondary()
                                            .on_press(move |_| cancel.dismiss_prompt())
                                            .text(dismiss_label),
                                    )
                                    .child(
                                        Button::new()
                                            .primary()
                                            .on_press(move |_| {
                                                accept.answer_prompt(Answer::new(
                                                    UPDATE_CHOICE_INSTALL,
                                                ))
                                            })
                                            .child(Icon::new(IconType::DownloadCloud02).size(14.))
                                            .text(install_label),
                                    ),
                            ),
                    ),
            )
            .into_element()
    }
}
