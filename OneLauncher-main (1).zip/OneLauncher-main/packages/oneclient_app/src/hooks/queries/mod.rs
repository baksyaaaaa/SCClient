use crate::hooks::use_settings_snapshot;

fn use_meta_url_key() -> String {
    use_settings_snapshot()
        .settings
        .custom_meta_url_base
        .unwrap_or_default()
        .trim()
        .to_string()
}

mod analytics;
mod auth;
mod bisect;
mod bundles;
mod changelog;
mod cluster_content;
mod clusters;
mod disable_warnings;
mod external_launchers;
mod import_screening;
mod folder_watch;
mod image;
mod java;
mod logs;
mod migration;
mod mutations;
mod package_updates;
mod packages;
mod player_profile;
mod screenshots;
mod settings_profiles;
mod skin;
mod state;
mod storage;
mod tos;
mod version_metadata;
mod versions;
pub mod wardrobe;
mod worlds;

pub use analytics::{
    try_cluster_analytics, try_global_analytics, use_cluster_analytics, use_global_analytics,
};
pub use auth::{
    AddOfflineAccountKeys, BeginMicrosoftLoginMutation, CancelMicrosoftLoginKeys,
    CancelMicrosoftLoginMutation, FinishMicrosoftLoginMutation, RefreshAccountKeys,
    RemoveAccountKeys, SetDefaultAccountKeys, UseRefreshAccount, UseRemoveAccount,
    UseSetDefaultAccount, accounts_have_microsoft, invalidate_auth_queries,
    login_code_already_handled, mutation_error, mutation_is_pending, mutation_is_running,
    mutation_ok, reset_login_code_dedup, try_account, try_accounts, try_default_account,
    use_account, use_accounts, use_add_microsoft_account, use_add_offline_account,
    use_begin_microsoft_login, use_cancel_microsoft_login, use_current_account,
    use_default_account, use_finish_microsoft_login, use_refresh_account, use_refresh_all_accounts,
    use_remove_account, use_set_default_account,
};
pub use bisect::{BisectAction, BisectMutation, bisect_report, use_bisect, use_bisect_mutation};
pub use bundles::{
    AvailableBundlesQuery, ClusterBundles, OnboardingBundlesQuery, available_bundles,
    bundle_overrides_map, bundles_with_status_items, imported_modpacks_list, modpack_sources_map,
    onboarding_bundles_items, use_available_bundles, use_bundle_overrides, use_bundle_updates,
    use_bundles_with_status, use_imported_modpacks, use_modpack_sources, use_onboarding_bundles,
};
pub(crate) use bundles::{
    UNCREATED_CLUSTER, bundle_plan, bundle_taken, pkg_key, shared_mod_keys, toggle_keys,
};
pub use changelog::{
    changelog_entries, changelog_error, changelog_is_loading, latest_changelog_version,
    use_changelog,
};
pub use cluster_content::{
    cluster_content_items, use_cluster_content, use_folder_packs, use_is_migration_source,
    use_migratable_routes, use_mods_folder_sync, use_shadowed_mods,
};
pub use clusters::{
    GraphicsBackendQuery, use_cluster, use_clusters, use_graphics_backend, use_has_game_options,
    use_shared_groups,
};
pub use disable_warnings::{DisableWarningsQuery, disable_warnings, use_disable_warnings};
pub use external_launchers::{external_launchers, use_external_launchers};
pub use import_screening::{
    import_screening, use_import_screening, use_modpack_header,
};
pub(crate) use folder_watch::use_folder_watch;
pub use image::{CachedImageQuery, loaded_image, use_cached_image};
pub use java::{
    invalidate_java_queries, java_runtimes, provider_versions, use_java_runtimes,
    use_provider_versions,
};
pub use logs::{
    ClusterLogsQuery, LogAction, LogContentQuery, UploadLogKeys, UploadLogMutation, UseLogAction,
    UseUploadLog, invalidate_logs_queries, try_cluster_logs, try_log_content, use_cluster_logs,
    use_log_action, use_log_content, use_upload_log,
};
pub use migration::{MigrationQuery, has_migration_data, migration_detection, use_migration};
pub(crate) use mutations::take_bundles;
pub use mutations::{
    ClusterAction, ClusterMutation, invalidate_cluster_content_queries, invalidate_cluster_queries,
    invalidate_profile_queries, use_cluster_mutation,
};
pub use package_updates::{PackageUpdatesQuery, package_updates, stale_hashes, use_package_updates};
pub use packages::ALL_VERSIONS;
pub use packages::{
    BROWSE_PAGE_SIZE, VERSIONS_PAGE_SIZE, category_list, content_type_for_slug, package_meta_batch,
    project_detail, project_web_urls, search_items, search_pending, search_total,
    use_package_categories, use_package_meta_batch, use_package_project, use_package_search,
    use_package_versions_when, use_project_web_urls, version_list, versions_total,
};
pub use player_profile::use_player_profile;
pub use screenshots::{
    ScreenshotAction, UseScreenshotAction, invalidate_screenshots_queries, try_cluster_screenshots,
    use_cluster_screenshots, use_local_image, use_screenshot_action, use_screenshot_folder_watch,
};
pub use settings_profiles::{
    try_game_profile, use_cluster_profile, use_cluster_settings, use_game_profile,
    use_named_profiles,
};
pub use skin::use_player_skin;
pub use state::{query_error, query_is_busy, query_is_loading, settled_or_loading};
pub use storage::{
    DiscardLeftoversKeys, DiscardLeftoversMutation, LeftoversQuery, StorageAction,
    StorageActionMutation, StorageReportQuery, UseDiscardLeftovers, UseStorageAction,
    invalidate_leftovers_queries, invalidate_storage_queries, try_leftovers, try_storage_report,
    use_discard_leftovers, use_leftovers, use_storage_action, use_storage_report,
};
pub use tos::{TermsQuery, terms_document, terms_error, terms_is_loading, use_terms};
pub use version_metadata::{
    cluster_art_url, pick_version_metadata, refresh_version_art_gallery, resolve_art_url,
    use_version_art, use_version_art_gallery, use_version_metadata,
};
pub use versions::{
    GameVersion, JavaMajorsQuery, game_versions, java_majors, loader_versions, use_game_versions,
    use_java_majors, use_loader_versions, use_version_loaders, use_versions, versions_metadata,
};
pub use worlds::{
    add_world_datapacks, delete_world, delete_world_datapack, invalidate_cluster_worlds,
    invalidate_world_contents, spawn_world_task, try_cluster_worlds, try_world_datapacks,
    try_world_size, use_cluster_worlds, use_saves_folder_watch, use_world_datapacks,
    use_world_size,
};
