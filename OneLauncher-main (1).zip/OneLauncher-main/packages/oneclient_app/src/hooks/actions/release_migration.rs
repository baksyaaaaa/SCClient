use std::collections::HashMap;

use freya::prelude::spawn_global;
use freya::query::{MutationStateData, UseMutation};
use std::collections::HashSet;

use oneclient_content::packages::release_migration::{
    ReleaseMigrationDependency, ReleaseMigrationPackage, ReleaseMigrationPlan,
    ReleaseMigrationSkip, SkipReason, add_to_waitlist, apply_release_migration_dependency,
    apply_release_migration_package, plan_release_migrations, process_waitlist,
};
use oneclient_content::packages::{
    ContentType, GameLoader, PackageBody, ProjectDetail, ProviderId, VersionDetail, VersionFile,
};
use oneclient_core::ReleaseTarget;
use oneclient_core::clusters::{
    Cluster, OfferLookup, ReleaseMigrationOffer, copy_configs, manual_migration_partners,
    record_new_versions, release_migration_offer,
};
use oneclient_events::Level;

use super::Actions;
use crate::components::IconType;
use crate::hooks::{ClusterAction, ClusterMutation};
use crate::i18n::{t, tf};
use crate::launcher;
use crate::notifications::NotificationSpec;
use crate::state::{
    AppChannel, MigrationDirection, PromptOrigin, ReleaseMigrationPrompt, ReleasePlanState,
    opening_direction,
};

fn release_key(cluster: &Cluster) -> String {
    ReleaseTarget {
        mc_version: cluster.mc_version.clone(),
        loader: cluster.mc_loader,
    }
    .key()
}

enum SourcePlan {
    Offer(ReleaseMigrationPlan),
    Nothing,
    Unreachable,
}

fn classify(plan: Result<ReleaseMigrationPlan, oneclient_content::ContentError>) -> SourcePlan {
    match plan {
        Ok(plan) if plan.unreachable => SourcePlan::Unreachable,
        Ok(plan) if plan.packages.is_empty() => SourcePlan::Nothing,
        Ok(plan) => SourcePlan::Offer(plan),
        Err(err) => {
            tracing::warn!(error = %err, "release migration plan failed");
            SourcePlan::Unreachable
        }
    }
}

enum SourcePlans {
    Ready {
        sources: Vec<Cluster>,
        plans: HashMap<(i64, i64), ReleasePlanState>,
    },
    Nothing,
    Unreachable,
}

async fn plan_sources(
    offer: &ReleaseMigrationOffer,
    bundles: &oneclient_content::bundles::BundlesManager,
    content: &oneclient_content::ContentCtx,
) -> SourcePlans {
    let ids: Vec<i64> = offer.sources.iter().map(|source| source.id).collect();
    let mut checked: HashMap<i64, SourcePlan> =
        plan_release_migrations(&ids, offer.target.id, bundles, content)
            .await
            .into_iter()
            .map(|(source_id, plan)| (source_id, classify(plan)))
            .collect();

    let mut sources = Vec::new();
    let mut plans = HashMap::new();

    for source in &offer.sources {
        match checked.remove(&source.id) {
            Some(SourcePlan::Offer(plan)) => {
                plans.insert((source.id, offer.target.id), ReleasePlanState::Ready(plan));
                sources.push(source.clone());
            }
            Some(SourcePlan::Nothing) | None => {}
            Some(SourcePlan::Unreachable) => return SourcePlans::Unreachable,
        }
    }

    if sources.is_empty() {
        SourcePlans::Nothing
    } else {
        SourcePlans::Ready { sources, plans }
    }
}

fn fake_version(name: &str, project_id: &str, size: u64) -> VersionDetail {
    VersionDetail {
        version_id: format!("fake-version-{project_id}"),
        project_id: project_id.to_string(),
        name: name.to_string(),
        version_number: "1.0.0".to_string(),
        changelog: None,
        game_versions: Vec::new(),
        loaders: vec![GameLoader::Fabric],
        published: chrono::Utc::now(),
        downloads: 0,
        files: vec![VersionFile {
            sha1: format!("fake-{project_id}"),
            url: String::new(),
            file_name: format!("{project_id}.jar"),
            primary: true,
            size,
            fingerprint: None,
        }],
        dependencies: Vec::new(),
    }
}

fn fake_package(
    name: &str,
    project_id: &str,
    content_type: ContentType,
    enabled: bool,
) -> ReleaseMigrationPackage {
    ReleaseMigrationPackage {
        source_hash: format!("fake-{project_id}"),
        enabled,
        provider: ProviderId::Modrinth,
        project_id: project_id.to_string(),
        content_type,
        display_name: name.to_string(),
        version: fake_version(name, project_id, 2_400_000),
        version_name: "1.0.0".to_string(),
        size: 2_400_000,
    }
}

fn fake_skip(name: &str, project_id: &str, reason: SkipReason) -> ReleaseMigrationSkip {
    ReleaseMigrationSkip {
        source_hash: format!("fake-{project_id}"),
        enabled: true,
        provider: ProviderId::Modrinth,
        project_id: project_id.to_string(),
        content_type: ContentType::Mod,
        display_name: name.to_string(),
        reason,
    }
}

fn fake_dependency(
    name: &str,
    project_id: &str,
    required_by: Vec<String>,
) -> ReleaseMigrationDependency {
    let now = chrono::Utc::now();
    ReleaseMigrationDependency {
        provider: ProviderId::Modrinth,
        project: ProjectDetail {
            id: project_id.to_string(),
            slug: project_id.to_string(),
            provider: ProviderId::Modrinth,
            content_type: ContentType::Mod,
            name: name.to_string(),
            summary: "Simulated dependency".to_string(),
            author: "nobody".to_string(),
            members: Vec::new(),
            gallery: Vec::new(),
            body: PackageBody::Raw(String::new()),
            license: None,
            links: Vec::new(),
            version_ids: Vec::new(),
            game_versions: Vec::new(),
            loaders: vec![GameLoader::Fabric],
            icon_url: None,
            created: now,
            updated: now,
            downloads: 0,
        },
        version: fake_version(name, project_id, 900_000),
        required_by,
    }
}

fn fake_plan(source_cluster_id: i64, target_cluster_id: i64) -> ReleaseMigrationPlan {
    let packages = vec![
        fake_package("Sodium", "AANobbMI", ContentType::Mod, true),
        fake_package(
            "Just Enough Items (JEI)",
            "u6dRKJwZ",
            ContentType::Mod,
            true,
        ),
        fake_package("Mod Menu", "mOgUt4GM", ContentType::Mod, false),
        fake_package(
            "Fresh Animations",
            "50dA9Sha",
            ContentType::ResourcePack,
            true,
        ),
        fake_package(
            "Complementary Shaders",
            "R6NEzAwj",
            ContentType::Shader,
            true,
        ),
    ];

    ReleaseMigrationPlan {
        source_cluster_id,
        target_cluster_id,
        dependencies: vec![fake_dependency(
            "Fabric API",
            "P7dR8mSH",
            vec!["fake-AANobbMI".to_string(), "fake-u6dRKJwZ".to_string()],
        )],
        unavailable: vec![
            fake_skip("Iris Shaders", "YL57xq9U", SkipReason::NoCompatibleVersion),
            fake_skip(
                "Distant Horizons",
                "uCdwusMi",
                SkipReason::MissingDependency,
            ),
        ],
        packages,
        unreachable: false,
    }
}

impl Actions {
    fn write_release_migration(&self, edit: impl FnOnce(&mut Option<ReleaseMigrationPrompt>)) {
        let mut guard = self
            .station
            .clone()
            .write_channel(AppChannel::ReleaseMigration);
        edit(&mut guard.release_migration);
    }

    fn remove_pending_release_migrations(&self, keys: Vec<String>) {
        if keys.is_empty() {
            return;
        }
        self.edit_settings(move |settings| {
            settings
                .pending_release_migrations
                .retain(|key| !keys.contains(key));
        });
    }

    async fn open_release_prompt(
        &self,
        state: &std::sync::Arc<oneclient_core::LauncherState>,
        offer: ReleaseMigrationOffer,
        sources: Vec<Cluster>,
        plans: HashMap<(i64, i64), ReleasePlanState>,
        origin: PromptOrigin,
    ) {
        let java: HashMap<i64, u32> = oneclient_core::required_java_major(state, offer.target.id)
            .await
            .ok()
            .flatten()
            .map(|major| (offer.target.id, major))
            .into_iter()
            .collect();

        self.write_release_migration(move |prompt| {
            *prompt = Some(ReleaseMigrationPrompt {
                home: offer.target,
                direction: MigrationDirection::Into,
                inbound: sources,
                outbound: Vec::new(),
                picked_inbound: None,
                picked_outbound: None,
                plans,
                java,
                origin,
            });
        });
    }

    pub fn check_release_migration(&self) {
        let actions = self.clone();
        spawn_global(async move {
            let Ok(state) = launcher::state() else { return };

            if let Err(err) = record_new_versions(&state).await {
                tracing::warn!(error = %err, "could not record new versions for migration");
            }
            actions.refresh_settings_from_core();

            let (pending, onboarded) = {
                let settings = state.settings.read();
                (
                    settings.pending_release_migrations.clone(),
                    settings.seen_onboarding,
                )
            };
            if pending.is_empty() {
                return;
            }

            if !onboarded {
                actions.remove_pending_release_migrations(pending);
                return;
            }

            let content = state.services.content();
            let mut finished = Vec::new();

            for key in pending {
                let Some(release) = ReleaseTarget::from_key(&key) else {
                    finished.push(key);
                    continue;
                };

                if !state.versions.shows_initial_migration(&release).await {
                    tracing::info!(
                        key,
                        "pending version opts out of the initial migration offer, dropping it"
                    );
                    finished.push(key);
                    continue;
                }

                let offer = match release_migration_offer(&state, &release).await {
                    Ok(OfferLookup::Offer(offer)) => offer,
                    Ok(OfferLookup::NoSources) => {
                        finished.push(key);
                        continue;
                    }
                    Ok(OfferLookup::MissingCluster) => continue,
                    Err(err) => {
                        tracing::warn!(error = %err, key, "release migration lookup failed");
                        continue;
                    }
                };

                let (sources, plans) =
                    match plan_sources(&offer, state.bundles.as_ref(), &content).await {
                        SourcePlans::Ready { sources, plans } => (sources, plans),
                        SourcePlans::Nothing => {
                            finished.push(key);
                            continue;
                        }
                        SourcePlans::Unreachable => continue,
                    };

                actions.remove_pending_release_migrations(finished);
                actions
                    .open_release_prompt(&state, *offer, sources, plans, PromptOrigin::NewRelease)
                    .await;
                return;
            }

            actions.remove_pending_release_migrations(finished);
        });
    }

    pub fn pick_migration_partner(&self, cluster_id: i64) {
        self.edit_migration_prompt(|prompt| match prompt.direction {
            MigrationDirection::Into => prompt.picked_inbound = Some(cluster_id),
            MigrationDirection::From => prompt.picked_outbound = Some(cluster_id),
        });
    }

    pub fn set_migration_direction(&self, direction: MigrationDirection) {
        self.edit_migration_prompt(|prompt| prompt.direction = direction);
    }

    fn edit_migration_prompt(&self, edit: impl FnOnce(&mut ReleaseMigrationPrompt)) {
        let mut pair = None;
        self.write_release_migration(|prompt| {
            let Some(prompt) = prompt.as_mut() else {
                return;
            };
            edit(prompt);
            let Some(key) = prompt.pair() else { return };
            if let std::collections::hash_map::Entry::Vacant(entry) = prompt.plans.entry(key) {
                entry.insert(ReleasePlanState::Loading);
                pair = Some(key);
            }
        });

        let Some((source_id, target_id)) = pair else {
            return;
        };
        let actions = self.clone();
        spawn_global(async move {
            let Ok(state) = launcher::state() else { return };
            let java = oneclient_core::required_java_major(&state, target_id)
                .await
                .ok()
                .flatten();
            let result = plan_release_migrations(
                &[source_id],
                target_id,
                state.bundles.as_ref(),
                &state.services.content(),
            )
            .await
            .pop()
            .map(|(_, plan)| plan);
            let next = match result {
                Some(Ok(plan)) if !plan.unreachable => ReleasePlanState::Ready(plan),
                Some(Ok(_)) | None => ReleasePlanState::Failed,
                Some(Err(err)) => {
                    tracing::warn!(error = %err, source_id, "release migration plan failed");
                    ReleasePlanState::Failed
                }
            };
            actions.write_release_migration(move |prompt| {
                if let Some(prompt) = prompt.as_mut() {
                    prompt.plans.insert((source_id, target_id), next);
                    if let Some(java) = java {
                        prompt.java.insert(target_id, java);
                    }
                }
            });
        });
    }

    /// Debug only: opens the popup on a hand-built plan, so the UI can be
    /// reviewed without a cluster that has migratable packages
    pub fn simulate_fake_release_migration(&self, target_cluster_id: i64) {
        let actions = self.clone();
        spawn_global(async move {
            let Ok(state) = launcher::state() else { return };
            let Ok(clusters) = state.clusters.list().await else {
                return;
            };
            let Some(target) = clusters
                .iter()
                .find(|cluster| cluster.id == target_cluster_id)
                .cloned()
            else {
                return;
            };

            let source = clusters
                .into_iter()
                .find(|cluster| cluster.id != target.id)
                .unwrap_or_else(|| target.clone());
            let pair = (source.id, target.id);
            let plan = fake_plan(source.id, target.id);

            actions.write_release_migration(move |prompt| {
                *prompt = Some(ReleaseMigrationPrompt {
                    home: target,
                    direction: MigrationDirection::Into,
                    inbound: vec![source],
                    outbound: Vec::new(),
                    picked_inbound: None,
                    picked_outbound: None,
                    plans: HashMap::from([(pair, ReleasePlanState::Ready(plan))]),
                    java: HashMap::new(),
                    origin: PromptOrigin::Fake,
                });
            });
        });
    }

    pub fn simulate_release_migration(&self, target_cluster_id: i64) {
        let actions = self.clone();
        spawn_global(async move {
            let Ok(state) = launcher::state() else { return };

            let target = match state.clusters.get(target_cluster_id).await {
                Ok(target) => target,
                Err(err) => {
                    actions
                        .notify(t("oneclient.actions.release_migration.simulation_failed"))
                        .body(err.to_string())
                        .level(Level::Error)
                        .send();
                    return;
                }
            };

            let release = ReleaseTarget {
                mc_version: target.mc_version.clone(),
                loader: target.mc_loader,
            };

            let offer = match release_migration_offer(&state, &release).await {
                Ok(OfferLookup::Offer(offer)) => offer,
                Ok(OfferLookup::NoSources | OfferLookup::MissingCluster) => {
                    actions
                        .notify(t("oneclient.actions.release_migration.nothing.title"))
                        .body(t(
                            "oneclient.actions.release_migration.nothing.all_migrated",
                        ))
                        .level(Level::Error)
                        .send();
                    return;
                }
                Err(err) => {
                    actions
                        .notify(t("oneclient.actions.release_migration.simulation_failed"))
                        .body(err.to_string())
                        .level(Level::Error)
                        .send();
                    return;
                }
            };

            let (sources, plans) =
                match plan_sources(&offer, state.bundles.as_ref(), &state.services.content()).await
                {
                    SourcePlans::Ready { sources, plans } => (sources, plans),
                    SourcePlans::Nothing => {
                        actions
                            .notify(t("oneclient.actions.release_migration.nothing.title"))
                            .body(t(
                                "oneclient.actions.release_migration.nothing.all_migrated",
                            ))
                            .level(Level::Error)
                            .send();
                        return;
                    }
                    SourcePlans::Unreachable => {
                        actions
                            .notify(t("oneclient.actions.release_migration.simulation_failed"))
                            .body(t("oneclient.actions.release_migration.unreachable"))
                            .level(Level::Error)
                            .send();
                        return;
                    }
                };

            actions
                .open_release_prompt(&state, *offer, sources, plans, PromptOrigin::Simulated)
                .await;
        });
    }

    fn set_release_migration_checking(&self, cluster_id: i64, checking: bool) {
        let mut guard = self
            .station
            .clone()
            .write_channel(AppChannel::ReleaseMigration);
        if checking {
            guard.release_migration_checking.insert(cluster_id);
        } else {
            guard.release_migration_checking.remove(&cluster_id);
        }
    }

    pub fn create_cluster_and_migrate(
        &self,
        mutation: UseMutation<ClusterMutation>,
        action: ClusterAction,
        source_cluster_id: i64,
    ) {
        let actions = self.clone();
        spawn_global(async move {
            let created = match &*mutation.mutate_async(action).await.state() {
                MutationStateData::Settled {
                    res: Ok(Some(id)), ..
                } => Some(*id),
                _ => None,
            };
            if let Some(target_cluster_id) = created {
                actions.open_manual_migration(
                    source_cluster_id,
                    MigrationDirection::From,
                    Some(target_cluster_id),
                );
            }
        });
    }

    pub fn open_manual_migration(
        &self,
        home_cluster_id: i64,
        direction: MigrationDirection,
        picked: Option<i64>,
    ) {
        if self.refuse_during_update_check(home_cluster_id) {
            return;
        }
        self.set_release_migration_checking(home_cluster_id, true);
        let actions = self.clone();
        spawn_global(async move {
            actions
                .run_manual_migration(home_cluster_id, direction, picked)
                .await;
            actions.set_release_migration_checking(home_cluster_id, false);
        });
    }

    async fn run_manual_migration(
        &self,
        home_cluster_id: i64,
        direction: MigrationDirection,
        picked: Option<i64>,
    ) {
        let Ok(state) = launcher::state() else { return };

        let partners = match manual_migration_partners(&state, home_cluster_id).await {
            Ok(Some(partners)) => partners,
            Ok(None) => return,
            Err(err) => {
                tracing::warn!(error = %err, home_cluster_id, "manual migration lookup failed");
                self.notify(t("oneclient.actions.release_migration.check_failed.title"))
                    .body(err.to_string())
                    .level(Level::Error)
                    .send();
                return;
            }
        };

        let Some(direction) =
            opening_direction(&partners.inbound, &partners.outbound, direction, picked)
        else {
            self.notify(t("oneclient.actions.release_migration.nothing.title"))
                .body(t("oneclient.actions.release_migration.nothing.no_packages"))
                .send();
            return;
        };
        let (picked_inbound, picked_outbound) = match direction {
            MigrationDirection::Into => (picked, None),
            MigrationDirection::From => (None, picked),
        };

        self.write_release_migration(move |prompt| {
            *prompt = Some(ReleaseMigrationPrompt {
                home: partners.home,
                direction,
                inbound: partners.inbound,
                outbound: partners.outbound,
                picked_inbound,
                picked_outbound,
                plans: HashMap::new(),
                java: HashMap::new(),
                origin: PromptOrigin::Manual,
            });
        });
        self.edit_migration_prompt(|_| {});
    }

    pub fn queue_release_migration(&self, target_cluster_id: i64) {
        let actions = self.clone();
        spawn_global(async move {
            let Ok(state) = launcher::state() else { return };
            let Ok(target) = state.clusters.get(target_cluster_id).await else {
                return;
            };
            let key = ReleaseTarget {
                mc_version: target.mc_version,
                loader: target.mc_loader,
            }
            .key();

            actions.write_release_migration(|prompt| *prompt = None);
            actions.edit_settings(move |settings| {
                if !settings.pending_release_migrations.contains(&key) {
                    settings.pending_release_migrations.push(key);
                }
            });
            actions.check_release_migration();
        });
    }

    pub fn process_release_waitlist(&self) {
        let actions = self.clone();
        spawn_global(async move {
            let Ok(state) = launcher::state() else { return };
            let content = state.services.content();

            let installs = match process_waitlist(
                state.bundles.as_ref(),
                |cluster_id| oneclient_core::game::is_running(&state, cluster_id),
                &content,
            )
            .await
            {
                Ok(installs) => installs,
                Err(err) => {
                    tracing::warn!(error = %err, "release migration waitlist check failed");
                    return;
                }
            };

            if installs.is_empty() {
                return;
            }

            for install in &installs {
                let args: [&dyn std::fmt::Display; 3] = [
                    &install.names.join(", "),
                    &install.mc_version,
                    &install.cluster_name,
                ];
                actions
                    .notify(tf(
                        "oneclient.actions.release_migration.builds_added.title",
                        &[&install.mc_version],
                    ))
                    .body(if install.names.len() == 1 {
                        tf(
                            "oneclient.actions.release_migration.builds_added.body.one",
                            &args,
                        )
                    } else {
                        tf(
                            "oneclient.actions.release_migration.builds_added.body.other",
                            &args,
                        )
                    })
                    .send();
            }

            super::super::invalidate_cluster_queries().await;
        });
    }

    pub fn dismiss_release_migration(&self) {
        let mut key = None;
        self.write_release_migration(|prompt| {
            key = prompt
                .take()
                .filter(|prompt| prompt.origin == PromptOrigin::NewRelease)
                .map(|prompt| release_key(&prompt.home));
        });
        if let Some(key) = key {
            self.remove_pending_release_migrations(vec![key]);
        }
    }

    pub fn migrate_release_packages(
        &self,
        packages: Vec<ReleaseMigrationPackage>,
        copy_configs_too: bool,
    ) {
        let mut taken = None;
        self.write_release_migration(|prompt| taken = prompt.take());
        let Some(prompt) = taken else { return };
        let (Some(source), Some(target)) = (prompt.source().cloned(), prompt.target().cloned())
        else {
            return;
        };
        if self.refuse_during_update_check(target.id) {
            return;
        }
        match prompt.origin {
            PromptOrigin::Fake => {
                self.notify(t("oneclient.actions.release_migration.fake.title"))
                    .body(t("oneclient.actions.release_migration.fake.body"))
                    .send();
                return;
            }
            PromptOrigin::Simulated => {}
            PromptOrigin::NewRelease | PromptOrigin::Manual => {
                self.remove_pending_release_migrations(vec![release_key(&target)]);
            }
        }

        let (source_id, target_id) = (source.id, target.id);
        spawn_global(async move {
            let Ok(state) = launcher::state() else { return };
            if let Err(err) = oneclient_content::bundles::inherit_bundle_choices(
                source_id,
                target_id,
                &state.services.content(),
            )
            .await
            {
                tracing::warn!(error = %err, "could not carry the bundle choices over to the target");
            }
        });

        if packages.is_empty() {
            return;
        }

        let chosen: HashSet<String> = packages
            .iter()
            .map(|package| package.source_hash.clone())
            .collect();
        let (dependencies, unavailable): (Vec<_>, Vec<_>) = match prompt.plan() {
            Some(ReleasePlanState::Ready(plan)) => (
                plan.dependencies
                    .iter()
                    .filter(|dependency| dependency.is_needed_by(&chosen))
                    .map(|dependency| (dependency.clone(), dependency.enabled_for(&packages)))
                    .collect(),
                plan.unavailable
                    .iter()
                    .filter(|skip| skip.reason == SkipReason::NoCompatibleVersion)
                    .cloned()
                    .collect(),
            ),
            _ => (Vec::new(), Vec::new()),
        };
        let waitlisted = !prompt.is_cross_loader();

        let actions = self.clone();
        let write = super::ClusterWrite::take(target.id);
        spawn_global(async move {
            let _write = write;
            let Ok(state) = launcher::state() else { return };
            let content = state.services.content();
            let source = copy_configs_too.then_some(source);
            let total = packages.len() + dependencies.len();

            let session = oneclient_events::GroupedProgressSession::start(
                &state.services.events,
                tf(
                    "oneclient.actions.release_migration.migrating",
                    &[&target.name],
                ),
            );
            session.expect(
                oneclient_events::TaskCategory::Packages,
                total as u64,
                total as u64,
            );

            let mut migrated = 0usize;
            let mut blocked: HashSet<String> = HashSet::new();
            for (dependency, enabled) in &dependencies {
                let child = session.child(
                    dependency.project.name.clone(),
                    1,
                    oneclient_events::TaskCategory::Packages,
                );
                match apply_release_migration_dependency(
                    target.id,
                    dependency,
                    *enabled,
                    Some(&child),
                    &content,
                )
                .await
                {
                    Ok(_) => migrated += 1,
                    Err(err) => {
                        tracing::warn!(
                            dependency = %dependency.project.name,
                            error = %err,
                            "release migration failed for dependency"
                        );
                        blocked.extend(dependency.required_by.iter().cloned());
                    }
                }
                child.finish();
            }

            for package in &packages {
                let child = session.child(
                    package.display_name.clone(),
                    1,
                    oneclient_events::TaskCategory::Packages,
                );
                if blocked.contains(&package.source_hash) {
                    tracing::warn!(
                        package = %package.display_name,
                        "skipping release migration for a package whose dependency failed"
                    );
                    child.finish();
                    continue;
                }
                match apply_release_migration_package(target.id, package, Some(&child), &content)
                    .await
                {
                    Ok(_) => migrated += 1,
                    Err(err) => tracing::warn!(
                        package = %package.display_name,
                        error = %err,
                        "release migration failed for package"
                    ),
                }
                child.finish();
            }

            if !waitlisted {
                tracing::info!(
                    target_cluster_id = target.id,
                    skipped = unavailable.len(),
                    "cross-loader migration, not adding packages without a build to the waitlist"
                );
            } else if let Err(err) = add_to_waitlist(target.id, &unavailable, &content).await {
                tracing::warn!(error = %err, "could not add packages without a build to the migration waitlist");
            }

            if let Some(source) = &source {
                match copy_configs(&state, source, &target).await {
                    Ok(copied) => tracing::info!(copied, "copied config files into the target"),
                    Err(err) => tracing::warn!(error = %err, "could not copy config files"),
                }
            }

            let failed = total - migrated;
            let session_id = session.detach();
            let spec = Some(NotificationSpec {
                title: tf(
                    "oneclient.actions.release_migration.migrated.title",
                    &[&target.name],
                ),
                body: if failed == 0 && migrated == 1 {
                    tf(
                        "oneclient.actions.release_migration.migrated.body.one",
                        &[&migrated, &target.name],
                    )
                } else if failed == 0 {
                    tf(
                        "oneclient.actions.release_migration.migrated.body.other",
                        &[&migrated, &target.name],
                    )
                } else {
                    tf(
                        "oneclient.actions.release_migration.migrated.partial",
                        &[&migrated, &total, &failed],
                    )
                },
                level: if failed == 0 {
                    Level::Info
                } else {
                    Level::Error
                },
                icon: Some(IconType::DownloadCloud02),
                progress: None,
                actions: Vec::new(),
                toast_only: false,
            });

            actions.with_engine(|app| {
                app.notifications
                    .finish_grouped_as_actions(&mut app.inbox, session_id, spec);
            });

            super::super::invalidate_cluster_queries().await;
        });
    }
}
