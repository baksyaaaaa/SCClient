use std::cell::{Cell, RefCell};
use std::collections::HashSet;

use freya::prelude::{Platform, WindowConfig, WinitPlatformExt, spawn_global};
use freya::radio::RadioStation;
use freya::winit::window::WindowId;
use oneclient_core::settings::LaunchBehaviour;

use crate::state::{AppChannel, AppState};

const ALLOWED_URL_SCHEMES: [&str; 3] = ["http", "https", "mailto"];

thread_local! {
    /// `None` while the main window is closed to the background
    static MAIN_WINDOW: Cell<Option<WindowId>> = const { Cell::new(None) };
    static REOPENING: Cell<bool> = const { Cell::new(false) };
    static MAIN_WINDOW_CONFIG: RefCell<Option<Box<dyn Fn() -> WindowConfig>>> =
        const { RefCell::new(None) };
}

/// Builds the main window again after it was closed to the background
pub fn set_main_window_config(config: impl Fn() -> WindowConfig + 'static) {
    MAIN_WINDOW_CONFIG.set(Some(Box::new(config)));
}

/// Called from the main window's root so window ops target it from anywhere, including global tasks
pub fn register_main_window(id: WindowId) {
    MAIN_WINDOW.set(Some(id));
}

#[must_use]
pub fn main_window() -> Option<WindowId> {
    MAIN_WINDOW.get()
}

pub fn focus_window() {
    let Some(id) = MAIN_WINDOW.get() else {
        reopen_main_window();
        return;
    };

    Platform::get().with_window(id, |win| {
        win.set_visible(true);
        win.set_minimized(false);
        win.focus_window();
    });
}

fn reopen_main_window() {
    if REOPENING.replace(true) {
        return;
    }
    let Some(config) = MAIN_WINDOW_CONFIG.with_borrow(|build| build.as_ref().map(|build| build()))
    else {
        REOPENING.set(false);
        return;
    };

    let platform = Platform::get();
    spawn_global(async move {
        let id = platform.launch_window(config).await;
        MAIN_WINDOW.set(Some(id));
        REOPENING.set(false);
        platform.focus_window(id);
    });
}

/// Closes the main window, the process (game tracking, tray, IPC) keeps running.
/// Only real way to get it off screen on Wayland, which can't hide windows. On macOS
/// the app stays in the Dock like any closed Mac window and clicking it reopens
pub fn hide_window() {
    let Some(id) = MAIN_WINDOW.get() else { return };

    crate::view::chat::close_chat_window();
    MAIN_WINDOW.set(None);
    Platform::get().close_window(id);
}

pub fn close() {
    let background =
        crate::launcher::state().is_ok_and(|state| state.settings.read().run_in_background);
    if background { hide_window() } else { quit() }
}

pub fn quit() {
    let platform = Platform::get();
    spawn_global(async move {
        if let Ok(state) = crate::launcher::state() {
            oneclient_core::shutdown(&state).await;
        }
        drop(platform.post_callback(|ctx| ctx.exit()));
    });
}

pub fn follow_game(
    station: &RadioStation<AppState, AppChannel>,
    launched: &HashSet<i64>,
    previous: Option<i64>,
) -> Option<i64> {
    let (current, any, behaviour) = {
        let state = station.peek();
        (
            state
                .game
                .running_clusters()
                .filter(|id| launched.contains(id))
                .min(),
            state.game.running_clusters().next().is_some(),
            state.settings.settings.launch_behaviour,
        )
    };

    tray::set_game_running(any);

    if current == previous {
        return previous;
    }

    match (behaviour, current.is_some()) {
        (LaunchBehaviour::HideWhilePlaying, true) => hide_window(),
        (LaunchBehaviour::HideWhilePlaying, false) => focus_window(),
        (LaunchBehaviour::CloseLauncher, true) => quit(),
        _ => {}
    }

    current
}

pub fn open_url(url: &str) {
    if !has_allowed_scheme(url) {
        tracing::warn!("refused to open url with a disallowed scheme: {url}");
        return;
    }

    open_target(url);
}

/// For paths the launcher itself produced, which carry no url scheme.
pub fn open_path(path: &str) {
    open_target(path);
}

pub fn reveal_file(path: std::path::PathBuf) {
    std::thread::spawn(move || {
        if let Err(err) = select_in_file_manager(&path) {
            tracing::debug!(%err, "failed to select {}, opening its folder", path.display());
            if let Some(dir) = path.parent() {
                open_target(&dir.to_string_lossy());
            }
        }
    });
}

#[cfg(target_os = "windows")]
fn select_in_file_manager(path: &std::path::Path) -> std::io::Result<()> {
    use std::os::windows::process::CommandExt;

    std::process::Command::new("explorer")
        .raw_arg(format!("/select,\"{}\"", path.display()))
        .spawn()
        .map(drop)
}

#[cfg(target_os = "macos")]
fn select_in_file_manager(path: &std::path::Path) -> std::io::Result<()> {
    let status = std::process::Command::new("open").arg("-R").arg(path).status()?;
    if status.success() {
        Ok(())
    } else {
        Err(std::io::Error::other(format!("open -R exited with {status}")))
    }
}

#[cfg(target_os = "linux")]
fn select_in_file_manager(path: &std::path::Path) -> std::io::Result<()> {
    let uri = url::Url::from_file_path(path)
        .map_err(|()| std::io::Error::other("not an absolute path"))?;
    zbus::blocking::Connection::session()
        .and_then(|connection| {
            connection.call_method(
                Some("org.freedesktop.FileManager1"),
                "/org/freedesktop/FileManager1",
                Some("org.freedesktop.FileManager1"),
                "ShowItems",
                &(vec![uri.as_str()], ""),
            )
        })
        .map(drop)
        .map_err(std::io::Error::other)
}

fn has_allowed_scheme(url: &str) -> bool {
    let Some((scheme, _)) = url.split_once(':') else {
        return false;
    };

    ALLOWED_URL_SCHEMES
        .iter()
        .any(|allowed| scheme.eq_ignore_ascii_case(allowed))
}

#[cfg(target_os = "linux")]
fn portal_open(target: &str) -> zbus::Result<()> {
    use std::collections::HashMap;
    use zbus::zvariant::{Fd, Value};

    const DESTINATION: &str = "org.freedesktop.portal.Desktop";
    const PATH: &str = "/org/freedesktop/portal/desktop";
    const INTERFACE: &str = "org.freedesktop.portal.OpenURI";

    let connection = zbus::blocking::Connection::session()?;
    let options = HashMap::<&str, Value>::new();
    if has_allowed_scheme(target) {
        connection.call_method(
            Some(DESTINATION),
            PATH,
            Some(INTERFACE),
            "OpenURI",
            &("", target, options),
        )?;
    } else {
        let file = std::fs::File::open(target)?;
        connection.call_method(
            Some(DESTINATION),
            PATH,
            Some(INTERFACE),
            "OpenFile",
            &("", Fd::from(&file), options),
        )?;
    }
    Ok(())
}

#[cfg(target_os = "linux")]
fn file_manager_show(target: &str) -> zbus::Result<()> {
    let uri = url::Url::from_directory_path(target)
        .map_err(|()| zbus::Error::Failure(format!("not an absolute path: {target}")))?;

    zbus::blocking::Connection::session()?.call_method(
        Some("org.freedesktop.FileManager1"),
        "/org/freedesktop/FileManager1",
        Some("org.freedesktop.FileManager1"),
        "ShowFolders",
        &(vec![uri.as_str()], ""),
    )?;
    Ok(())
}

#[cfg(target_os = "linux")]
fn open_target(target: &str) {
    use std::process::Stdio;

    let target = target.to_owned();
    std::thread::spawn(move || {
        if std::path::Path::new(&target).is_dir() {
            let Err(err) = file_manager_show(&target) else {
                return;
            };
            tracing::debug!(%err, "file manager failed to show {target}, falling back");
        }

        let Err(err) = portal_open(&target) else {
            return;
        };
        tracing::debug!(%err, "portal failed to open {target}, falling back");

        let opened = open::commands(&target).into_iter().any(|mut command| {
            oneclient_common::process::strip_appimage_env(&mut command);
            command
                .stdin(Stdio::null())
                .stdout(Stdio::null())
                .stderr(Stdio::null())
                .status()
                .is_ok_and(|status| status.success())
        });

        if !opened {
            tracing::warn!("failed to open {target}");
        }
    });
}

#[cfg(not(target_os = "linux"))]
fn open_target(target: &str) {
    let target = target.to_owned();
    std::thread::spawn(move || {
        if let Err(err) = open::that_detached(&target) {
            tracing::warn!("failed to open {target}: {err}");
        }
    });
}

pub fn copy_image_to_clipboard(path: std::path::PathBuf) {
    std::thread::spawn(move || {
        let img = match image::open(&path) {
            Ok(img) => img.into_rgba8(),
            Err(err) => {
                tracing::warn!("failed to decode {} for clipboard: {err}", path.display());
                return;
            }
        };
        let (width, height) = (img.width() as usize, img.height() as usize);
        let data = arboard::ImageData {
            width,
            height,
            bytes: std::borrow::Cow::Owned(img.into_raw()),
        };
        match arboard::Clipboard::new() {
            Ok(mut clip) => {
                if let Err(err) = clip.set_image(data) {
                    tracing::warn!("failed to copy image to clipboard: {err}");
                }
            }
            Err(err) => tracing::warn!("failed to open clipboard: {err}"),
        }
    });
}

pub mod tray {
    use std::cell::RefCell;

    use freya::prelude::{LaunchConfig, RendererContext};
    use freya::tray::menu::{Menu, MenuItem, PredefinedMenuItem};
    use freya::tray::{TrayEvent, TrayIcon, TrayIconBuilder};

    use crate::constants;
    use crate::i18n::t;
    use crate::ipc::{self, IpcCommand};

    const OPEN_ID: &str = "oneclient.open";
    const PLAY_ID: &str = "oneclient.play";
    const STOP_ID: &str = "oneclient.stop";
    const LOGS_ID: &str = "oneclient.logs";
    const QUIT_ID: &str = "oneclient.quit";
    #[cfg(target_os = "macos")]
    const HELP_ID: &str = "oneclient.help";
    #[cfg(target_os = "macos")]
    const REPORT_ID: &str = "oneclient.report";
    #[cfg(target_os = "macos")]
    const HELP_URL: &str = "https://discord.gg/polyfrost";
    #[cfg(target_os = "macos")]
    const REPORT_URL: &str = "https://github.com/Polyfrost/OneLauncher/issues/new/choose";

    #[cfg(target_os = "macos")]
    const ICON: &[u8] = include_bytes!("../icons/tray.png");
    #[cfg(not(target_os = "macos"))]
    const ICON: &[u8] = include_bytes!("../icons/64x64.png");

    thread_local! {
        static GAME_ITEMS: RefCell<Vec<MenuItem>> = const { RefCell::new(Vec::new()) };
        #[cfg(target_os = "macos")]
        static MENU_BAR: RefCell<Option<Menu>> = const { RefCell::new(None) };
    }

    pub(super) fn set_game_running(running: bool) {
        GAME_ITEMS.with_borrow(|items| {
            for item in items {
                item.set_enabled(running);
            }
        });
    }

    pub fn build() -> TrayIcon {
        let live_on_linux = cfg!(target_os = "linux");
        let stop = MenuItem::with_id(STOP_ID, t("oneclient.tray.stop_game"), live_on_linux, None);
        let logs = MenuItem::with_id(LOGS_ID, t("oneclient.tray.show_logs"), live_on_linux, None);

        let menu = Menu::with_items(&[
            &MenuItem::with_id(OPEN_ID, t("oneclient.tray.open"), true, None),
            &MenuItem::with_id(PLAY_ID, t("oneclient.tray.play_last"), true, None),
            &PredefinedMenuItem::separator(),
            &stop,
            &logs,
            &PredefinedMenuItem::separator(),
            &MenuItem::with_id(QUIT_ID, t("oneclient.tray.quit"), true, None),
        ])
        .expect("failed to build the tray menu");

        GAME_ITEMS.with_borrow_mut(|items| *items = vec![stop, logs]);

        #[cfg(target_os = "macos")]
        install_menu_bar();

        let builder = TrayIconBuilder::new()
            .with_menu(Box::new(menu))
            .with_tooltip(constants::WINDOW_TITLE)
            .with_menu_on_left_click(!cfg!(target_os = "windows"));
        #[cfg(target_os = "macos")]
        let builder = builder.with_icon_templated(LaunchConfig::tray_icon(ICON));
        #[cfg(not(target_os = "macos"))]
        let builder = builder.with_icon(LaunchConfig::tray_icon(ICON));

        builder.build().expect("failed to create the tray icon")
    }

    pub fn handle(event: TrayEvent, _ctx: RendererContext<'_>) {
        let command = match event {
            TrayEvent::Menu(menu) => match menu.id.0.as_str() {
                OPEN_ID => IpcCommand::Focus,
                PLAY_ID => return play_last(),
                STOP_ID => IpcCommand::Stop,
                LOGS_ID => IpcCommand::Logs,
                QUIT_ID => IpcCommand::Quit,
                #[cfg(target_os = "macos")]
                HELP_ID => return super::open_url(HELP_URL),
                #[cfg(target_os = "macos")]
                REPORT_ID => return super::open_url(REPORT_URL),
                _ => return,
            },
            #[cfg(target_os = "windows")]
            TrayEvent::Icon(freya::tray::TrayIconEvent::Click {
                button: freya::tray::MouseButton::Left,
                button_state: freya::tray::MouseButtonState::Up,
                ..
            }) => IpcCommand::Focus,
            TrayEvent::Icon(_) => return,
        };
        ipc::send(command);
    }

    /// winit only builds the app menu, so the menu bar had no Help menu. It's set up with the
    /// tray because menu clicks reach the app through the tray handler
    #[cfg(target_os = "macos")]
    fn install_menu_bar() {
        use freya::tray::menu::Submenu;

        let app_menu = Submenu::with_items(
            constants::WINDOW_TITLE,
            true,
            &[
                &PredefinedMenuItem::about(None, None),
                &PredefinedMenuItem::separator(),
                &PredefinedMenuItem::services(None),
                &PredefinedMenuItem::separator(),
                &PredefinedMenuItem::hide(None),
                &PredefinedMenuItem::hide_others(None),
                &PredefinedMenuItem::show_all(None),
                &PredefinedMenuItem::separator(),
                &PredefinedMenuItem::quit(None),
            ],
        );
        let help_menu = Submenu::with_items(
            t("oneclient.tray.menu_bar.help"),
            true,
            &[
                &MenuItem::with_id(HELP_ID, t("oneclient.tray.menu_bar.get_help"), true, None),
                &MenuItem::with_id(
                    REPORT_ID,
                    t("oneclient.tray.menu_bar.report_issue"),
                    true,
                    None,
                ),
            ],
        );
        let (Ok(app_menu), Ok(help_menu)) = (app_menu, help_menu) else {
            tracing::warn!("failed to build the menu bar");
            return;
        };

        let Ok(menu) = Menu::with_items(&[&app_menu, &help_menu]) else {
            tracing::warn!("failed to build the menu bar");
            return;
        };
        menu.init_for_nsapp();
        // Gives it the system search field
        help_menu.set_as_help_menu_for_nsapp();
        MENU_BAR.with_borrow_mut(|bar| *bar = Some(menu));
    }

    fn play_last() {
        tokio::spawn(async {
            let Ok(state) = crate::launcher::state() else {
                return;
            };
            let Ok(clusters) = state.clusters.list().await else {
                return;
            };
            if let Some(cluster) = crate::utils::sort_clusters_for_home(clusters)
                .into_iter()
                .next()
            {
                ipc::send(IpcCommand::Launch(cluster.folder_name));
            }
        });
    }
}

#[cfg(target_os = "windows")]
pub mod frame {
    use std::sync::atomic::{AtomicBool, Ordering};

    use freya::winit::platform::windows::{CornerPreference, WindowExtWindows};
    use freya::winit::raw_window_handle::{HasWindowHandle, RawWindowHandle};
    use freya::winit::window::Window;
    use freya_winit::plugins::{FreyaPlugin, PluginEvent, PluginHandle};
    use windows::Win32::Foundation::{HWND, LPARAM, LRESULT, POINT, WPARAM};
    use windows::Win32::Graphics::Dwm::DwmExtendFrameIntoClientArea;
    use windows::Win32::Graphics::Gdi::{
        GetMonitorInfoW, MONITOR_DEFAULTTONEAREST, MONITORINFO, MonitorFromWindow,
    };
    use windows::Win32::UI::Controls::MARGINS;
    use windows::Win32::UI::Shell::{DefSubclassProc, RemoveWindowSubclass, SetWindowSubclass};
    use windows::Win32::UI::WindowsAndMessaging::{
        DefWindowProcW, GWL_STYLE, GetWindowLongPtrW, HTBOTTOMRIGHT, HTLEFT, IsZoomed, MINMAXINFO,
        STYLESTRUCT, SWP_FRAMECHANGED, SWP_NOACTIVATE, SWP_NOMOVE, SWP_NOSIZE, SWP_NOZORDER,
        SetWindowLongPtrW, SetWindowPos, WM_GETMINMAXINFO, WM_NCCALCSIZE, WM_NCDESTROY,
        WM_NCLBUTTONDOWN, WM_STYLECHANGING, WS_CAPTION, WS_THICKFRAME,
    };

    static RESIZING: AtomicBool = AtomicBool::new(false);

    /// `Some` overrides the GPU detection, from `window_frame_fix` in settings.json
    pub struct FramePlugin(pub Option<bool>);

    impl FreyaPlugin for FramePlugin {
        fn plugin_id(&self) -> &'static str {
            "oneclient-window-frame"
        }

        fn on_event(&mut self, event: &mut PluginEvent, _handle: PluginHandle) {
            let PluginEvent::WindowCreated {
                window,
                graphics_driver,
                gpu_name,
                ..
            } = event
            else {
                return;
            };

            if window.is_decorated() {
                return;
            }
            let Some(hwnd) = hwnd(window) else {
                return;
            };

            let gpu = gpu_name.unwrap_or("an unknown GPU");
            let composes_frame = *graphics_driver != "OpenGL"
                || gpu.contains("NVIDIA")
                || gpu.contains("Arc")
                || (gpu.contains(" RX ") && !gpu.contains("Vega"));
            match self.0 {
                Some(true) => install(hwnd, gpu),
                Some(false) => decorate(window, hwnd),
                None if composes_frame => decorate(window, hwnd),
                None if gpu.contains("Intel") => install(hwnd, gpu),
                None => {}
            }
        }
    }

    fn hwnd(window: &Window) -> Option<HWND> {
        match window.window_handle().ok()?.as_raw() {
            RawWindowHandle::Win32(handle) => Some(HWND(handle.hwnd.get() as _)),
            _ => None,
        }
    }

    fn decorate(window: &Window, hwnd: HWND) {
        window.set_corner_preference(CornerPreference::Round);

        let margins = MARGINS {
            cxLeftWidth: 1,
            cxRightWidth: 1,
            cyTopHeight: 1,
            cyBottomHeight: 1,
        };
        if let Err(err) = unsafe { DwmExtendFrameIntoClientArea(hwnd, &margins) } {
            tracing::warn!("failed to extend the window frame for its shadow: {err}");
        }
    }

    fn install(hwnd: HWND, gpu: &str) {
        if !unsafe { SetWindowSubclass(hwnd, Some(subclass), 1, 0) }.as_bool() {
            tracing::warn!("failed to subclass the window for the {gpu} frame fix");
            return;
        }
        restyle(hwnd);
        tracing::info!("dropped the window frame styles for {gpu} on OpenGL");
    }

    fn frame_styles(style: u32) -> u32 {
        if RESIZING.load(Ordering::Relaxed) {
            (style & !WS_CAPTION.0) | WS_THICKFRAME.0
        } else {
            style & !(WS_CAPTION.0 | WS_THICKFRAME.0)
        }
    }

    fn monitor_info(hwnd: HWND) -> Option<MONITORINFO> {
        let mut info = MONITORINFO {
            cbSize: size_of::<MONITORINFO>() as u32,
            ..Default::default()
        };
        unsafe { GetMonitorInfoW(MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST), &mut info) }
            .as_bool()
            .then_some(info)
    }

    fn restyle(hwnd: HWND) {
        let style = unsafe { GetWindowLongPtrW(hwnd, GWL_STYLE) } as u32;
        unsafe { SetWindowLongPtrW(hwnd, GWL_STYLE, frame_styles(style) as isize) };

        let flags = SWP_FRAMECHANGED | SWP_NOZORDER | SWP_NOACTIVATE;
        let zoomed = unsafe { IsZoomed(hwnd) }.as_bool();
        let result = unsafe {
            match monitor_info(hwnd).filter(|_| zoomed) {
                Some(MONITORINFO { rcWork: work, .. }) => SetWindowPos(
                    hwnd,
                    None,
                    work.left,
                    work.top,
                    work.right - work.left,
                    work.bottom - work.top,
                    flags,
                ),
                None => SetWindowPos(hwnd, None, 0, 0, 0, 0, flags | SWP_NOMOVE | SWP_NOSIZE),
            }
        };
        if let Err(err) = result {
            tracing::warn!("failed to apply the window frame styles: {err}");
        }
    }

    unsafe extern "system" fn subclass(
        hwnd: HWND,
        msg: u32,
        wparam: WPARAM,
        lparam: LPARAM,
        _id: usize,
        _data: usize,
    ) -> LRESULT {
        unsafe {
            match msg {
                WM_STYLECHANGING if wparam.0 as i32 == GWL_STYLE.0 => {
                    let change = &mut *(lparam.0 as *mut STYLESTRUCT);
                    change.styleNew = frame_styles(change.styleNew);
                    DefSubclassProc(hwnd, msg, wparam, lparam)
                }
                WM_NCCALCSIZE if !RESIZING.load(Ordering::Relaxed) => {
                    DefWindowProcW(hwnd, msg, wparam, lparam)
                }
                WM_NCLBUTTONDOWN if (HTLEFT..=HTBOTTOMRIGHT).contains(&(wparam.0 as u32)) => {
                    RESIZING.store(true, Ordering::Relaxed);
                    restyle(hwnd);
                    let result = DefSubclassProc(hwnd, msg, wparam, lparam);
                    RESIZING.store(false, Ordering::Relaxed);
                    restyle(hwnd);
                    result
                }
                WM_GETMINMAXINFO => {
                    let result = DefSubclassProc(hwnd, msg, wparam, lparam);
                    if let Some(info) = monitor_info(hwnd) {
                        let (work, monitor) = (info.rcWork, info.rcMonitor);
                        let limits = &mut *(lparam.0 as *mut MINMAXINFO);
                        limits.ptMaxPosition = POINT {
                            x: work.left - monitor.left,
                            y: work.top - monitor.top,
                        };
                        limits.ptMaxSize = POINT {
                            x: work.right - work.left,
                            y: work.bottom - work.top,
                        };
                    }
                    result
                }
                WM_NCDESTROY => {
                    let _ = RemoveWindowSubclass(hwnd, Some(subclass), 1);
                    DefSubclassProc(hwnd, msg, wparam, lparam)
                }
                _ => DefSubclassProc(hwnd, msg, wparam, lparam),
            }
        }
    }
}

#[cfg(target_os = "macos")]
pub mod macos {
    use std::time::Duration;

    pub fn loop_memory_collector() {
        tokio::spawn(async {
            tokio::time::sleep(Duration::from_secs(8)).await;

            loop {
                release_unused_memory();
                tokio::time::sleep(Duration::from_secs(60)).await;
            }
        });
    }

    fn release_unused_memory() {
        unsafe {
            unsafe extern "C" {
                fn malloc_zone_pressure_relief(zone: *mut core::ffi::c_void, goal: usize) -> usize;
            }
            malloc_zone_pressure_relief(core::ptr::null_mut(), 0);
        }
    }

    /// Clicking the Dock icon reopens the main window like any other Mac app. winit's app
    /// delegate doesn't answer `applicationShouldHandleReopen:`, so it's added to its class.
    /// Call once the event loop exists, the class is registered when it starts
    pub fn handle_dock_reopen() {
        type Id = *mut core::ffi::c_void;

        // BOOL is one byte on both Intel and Apple silicon
        unsafe extern "C" fn should_handle_reopen(_: Id, _: Id, _: Id, _: i8) -> i8 {
            crate::ipc::send(crate::ipc::IpcCommand::Focus);
            1
        }

        unsafe {
            unsafe extern "C" {
                fn objc_getClass(name: *const core::ffi::c_char) -> Id;
                fn sel_registerName(name: *const core::ffi::c_char) -> Id;
                fn class_addMethod(
                    class: Id,
                    name: Id,
                    imp: *const core::ffi::c_void,
                    types: *const core::ffi::c_char,
                ) -> bool;
            }

            let class = objc_getClass(c"WinitApplicationDelegate".as_ptr());
            if class.is_null() {
                tracing::warn!("winit's app delegate is missing, the Dock icon won't reopen the window");
                return;
            }
            // Fails only if a future winit implements it itself, which is just as good
            class_addMethod(
                class,
                sel_registerName(c"applicationShouldHandleReopen:hasVisibleWindows:".as_ptr()),
                should_handle_reopen as *const core::ffi::c_void,
                c"c@:@c".as_ptr(),
            );
        }
    }
}
