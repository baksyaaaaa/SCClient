use std::collections::BTreeMap;
use std::path::PathBuf;

use serde::{Deserialize, Serialize};

use oneclient_cluster::GameSettingsProfile;

#[derive(Debug, Serialize, Deserialize, Clone, Copy, PartialEq, Eq, Default)]
#[serde(rename_all = "snake_case")]
pub enum ViewLayout {
    #[default]
    Grid,
    List,
}

#[derive(Debug, Serialize, Deserialize, Clone, Copy, PartialEq, Eq, Default)]
#[serde(rename_all = "snake_case")]
pub enum LaunchBehaviour {
    #[default]
    KeepVisible,
    HideWhilePlaying,
    CloseLauncher,
}

impl LaunchBehaviour {
    pub const ALL: [Self; 3] = [
        Self::KeepVisible,
        Self::HideWhilePlaying,
        Self::CloseLauncher,
    ];

    #[must_use]
    pub fn label(self) -> &'static str {
        match self {
            Self::KeepVisible => "Keep visible",
            Self::HideWhilePlaying => "Hide while playing",
            Self::CloseLauncher => "Close completely",
        }
    }
}

#[derive(Debug, Serialize, Deserialize, Clone, PartialEq, Eq, Default)]
#[serde(default)]
pub struct ViewState {
    pub layout: ViewLayout,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub sort: Option<String>,
    #[serde(skip_serializing_if = "BTreeMap::is_empty")]
    pub filters: BTreeMap<String, String>,
}

pub const CURRENT_SETTINGS_VERSION: u32 = 2;

#[derive(Debug, Serialize, Deserialize, Clone)]
#[serde(default)]
pub struct LauncherSettings {
    pub settings_version: u32,
    pub log_debug: bool,
    pub auto_update: bool,
    pub crash_reporting: bool,
    pub discord_enabled: bool,
    pub max_concurrent_requests: usize,
    pub global_game_settings: GameSettingsProfile,
    pub allow_parallel_running_clusters: bool,
    pub launch_behaviour: LaunchBehaviour,
    pub open_game_log_on_launch: bool,
    pub run_in_background: bool,
    pub show_tray_icon: bool,
    pub dynamic_background_enabled: bool,
    pub start_maximized: bool,
    /// Windows only: `None` detects whether the GPU needs the frame-style workaround,
    /// `Some(true)`/`Some(false)` forces it on or off
    pub window_frame_fix: Option<bool>,
    pub animations_enabled: bool,
    pub theme: String,
    pub accent_color: Option<String>,
    pub language: Option<String>,
    pub view_states: BTreeMap<String, ViewState>,
    pub seen_onboarding: bool,
    pub skip_microsoft_java: bool,
    pub microsoft_java_migrated: bool,
    pub accepted_tos_version: u32,
    pub accepted_privacy_version: u32,
    pub declined_tos: bool,
    pub seen_versions: Vec<String>,
    pub seen_changelog_version: Option<String>,
    pub acknowledged_disable_warnings: Vec<String>,
    pub pending_release_migrations: Vec<String>,
    pub modrinth_api_key: Option<String>,
    pub curseforge_api_key: Option<String>,
    pub custom_api_endpoint: Option<String>,
    pub custom_meta_url_base: Option<String>,
    pub custom_plus_endpoint: Option<String>,
    pub nightly_bundles: bool,
    pub data_dir: Option<PathBuf>,
    pub previous_data_dir: Option<PathBuf>,
}

impl LauncherSettings {
    pub fn view_state(&self, key: &str) -> ViewState {
        self.view_states.get(key).cloned().unwrap_or_default()
    }

    pub fn set_view_state(&mut self, key: impl Into<String>, state: ViewState) {
        self.view_states.insert(key.into(), state);
    }
}

impl LauncherSettings {
    /// Brings a file written by an older launcher up to the current defaults
    pub fn migrate(&mut self) {
        if self.settings_version < 2 {
            // Had no toggle so a saved `false` was never the user's choice
            // dedicated clusters plus one shared cluster may now run together
            self.allow_parallel_running_clusters = true;
        }
        self.settings_version = CURRENT_SETTINGS_VERSION;
    }
}

impl Default for LauncherSettings {
    fn default() -> Self {
        Self {
            settings_version: CURRENT_SETTINGS_VERSION,
            log_debug: false,
            auto_update: true,
            crash_reporting: true,
            discord_enabled: true,
            max_concurrent_requests: 25,
            global_game_settings: GameSettingsProfile::default_global_profile(),
            allow_parallel_running_clusters: true,
            launch_behaviour: LaunchBehaviour::default(),
            open_game_log_on_launch: true,
            // Mac apps stay in the Dock when their window closes
            run_in_background: cfg!(target_os = "macos"),
            show_tray_icon: true,
            dynamic_background_enabled: true,
            start_maximized: false,
            window_frame_fix: None,
            animations_enabled: true,
            theme: "dark".to_string(),
            accent_color: None,
            language: None,
            view_states: BTreeMap::new(),
            seen_onboarding: false,
            skip_microsoft_java: false,
            microsoft_java_migrated: false,
            accepted_tos_version: 0,
            accepted_privacy_version: 0,
            declined_tos: false,
            seen_versions: Vec::new(),
            seen_changelog_version: None,
            acknowledged_disable_warnings: Vec::new(),
            pending_release_migrations: Vec::new(),
            modrinth_api_key: None,
            curseforge_api_key: None,
            custom_api_endpoint: None,
            custom_meta_url_base: None,
            custom_plus_endpoint: None,
            nightly_bundles: false,
            data_dir: None,
            previous_data_dir: None,
        }
    }
}
