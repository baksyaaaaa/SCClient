#![recursion_limit = "256"]

#[cfg(debug_assertions)]
pub mod dev;

pub mod bisect;
pub mod changelog;
pub mod clusters;
pub mod disable_warnings;
mod error;
pub mod game;
pub mod images;
mod java_store;
pub mod logger;
pub mod migration;
pub mod recovery;
pub mod relocate;
pub mod reporting;
pub mod settings;
pub mod sharing;
pub mod simulate;
mod state;
pub mod storage;
pub mod sync;
pub mod tos;
pub mod verify;
pub mod versions;

pub use bisect::{
    BisectAnswer, BisectChoice, BisectError, BisectExit, BisectHistoryEntry, BisectMod,
    BisectPlanKind, BisectRole, BisectStage, BisectStatus, BisectSuggestion, CascadeMod,
    ConflictReport, HiddenDependency, UnresolvableMod, accept_bisect_suggestion, answer_bisect,
    bisect_report, bisect_status, continue_bisect, decline_bisect_suggestion, find_hidden_dependencies,
    finish_bisect, keep_bisect_mods_on, reset_bisect, set_bisect_mod_choice, settle_unresolvable_mod,
    skip_bisect_answer, start_bisect, undo_bisect_answer, use_hidden_dependencies,
};
pub use changelog::{ChangelogEntry, fetch_changelog};
pub use clusters::{
    Cluster, ClusterError, ClusterManager, ClusterStage, ClusterUpdate, CreateClusterOptions,
    apply_bundle_java_override, ensure_from_bundles, ensure_from_versions,
    estimate_cluster_download, required_java_major,
};
pub use disable_warnings::{DisableWarnings, fetch_disable_warnings};
pub use error::{LauncherError, LauncherResult, SentryExclusion};
pub use game::{
    GameError, GameVersionInfo, GameVersionKind, LaunchedGame, get_loader_versions,
    get_loaders_for_version, get_version_ids, get_versions_for_loader, launch_cluster,
    launch_cluster_with,
};
pub use images::ImageCacheStore;
pub use migration::launchers::{
    ExternalDetection, ExternalImportReport, ExternalInstance, ExternalLauncher, FlaggedImportMod,
    ImportAlternative, ImportChoices, InstanceArchive, ScreenedInstance, UnpublishedCheck,
    UnpublishedFile, alternative_version_id, detect_all as detect_external_launchers,
    detect_folder as detect_external_folder, discard_instance_archive, find_unpublished_mods,
    import_instance as import_external_instance, instance_mods_stamp, is_instance_archive,
    open_instance_archive, same_folder as same_external_folder,
    screen_instances as screen_external_instances, screen_modpack_file, sweep_instance_archives,
};
pub use migration::{
    ImportTarget, MigrationDetection, MigrationSource, SourceInstance, detect as detect_migration,
    import_game_dir as import_migration_game_dir,
};
pub use oneclient_cluster::logs::{
    LogFileInfo, LogKind, LogLevel, LogLine, LogTrim, LogsError, MclogsUploadResponse, ReadOptions,
    delete_log_at, list_cluster_logs, log_exceeds_upload_limit, read_log_at, upload_log_at,
};
pub use oneclient_cluster::screenshots::{
    ScreenshotInfo, ScreenshotsError, delete_screenshot, list_cluster_screenshots,
    load_picked_image, load_screenshot,
};
pub use oneclient_cluster::worlds::{
    DataPackInfo, LEVEL_DAT, PackIcon, WORLD_ICON, WorldInfo, WorldsError, add_world_datapacks,
    delete_world, delete_world_datapack, list_cluster_worlds, list_world_datapacks, world_size,
};
pub use oneclient_content::bundles::{
    ApplyBundleUpdatesResult, BUNDLE_APPLY_BUDGET, Bundle, BundleArchive, BundleError, BundleFile,
    BundleFileKind, BundleFileType, BundleManifest, BundleOptionalPackage, BundleUpdateCheckResult,
    BundleWithUpdateStatus, BundlesManager, FileUpdateStatus, PendingOptionalMod,
    apply_bundle_updates, apply_bundle_updates_with, check_bundle_updates,
    cluster_has_bundle_content, clusters_sharing_artifact, clusters_sharing_global_folders,
    delete_artifact, effective_enabled, get_bundles_with_update_status, install_bundle,
    install_cluster_bundles, install_package_from_bundle, list_cluster_bundle_overrides,
    on_user_remove_artifact, pending_optional_mods, remove_artifact_from_cluster,
    resolve_optional_mods, set_artifact_enabled_to, set_bundle_package_enabled,
    set_bundle_package_opt_in, set_bundle_package_override, set_bundle_package_overrides,
    set_bundle_package_removed,
    skip_optional_mods,
};
pub use oneclient_content::packages::LinkedArtifactInfo;
pub use oneclient_content::packages::dependents::{
    DependentPackage, DisableImpact, DisableRoot, disable_impact, ensure_cluster_dependencies,
};
pub use oneclient_content::packages::updates::{
    BrowserPackageUpdate, BrowserUpdateCheck, apply_browser_package_update,
    cached_browser_package_updates, check_browser_package_updates, refresh_browser_package_updates,
    refresh_browser_package_updates_for, skip_browser_package_update,
};
pub use oneclient_db::models::SeenStatus;
pub use oneclient_discord::{DiscordRpc, Presence};
pub use oneclient_mc::{McError as MetadataError, MetadataStore};
pub use settings::ProfileUpdate;
pub use state::LauncherServices;
pub use state::LauncherState;
pub use state::run_startup_tasks;
pub use state::shutdown;
pub use tos::{TermsDocument, fetch_terms};
pub use verify::{ClusterVerifyReport, verify_cluster_files};
pub use versions::{
    ReleaseTarget, RemoteMigration, VersionArts, VersionMetadata, VersionsManager,
    VersionsManifest, resolve_migration_chain,
};
