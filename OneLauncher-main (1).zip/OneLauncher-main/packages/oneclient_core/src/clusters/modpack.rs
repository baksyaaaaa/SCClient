use std::collections::HashSet;
use std::path::PathBuf;
use std::sync::Arc;

use oneclient_cluster::naming::{is_allowed_name_char, validate_modpack_instance_name};
use oneclient_cluster::{Cluster, ClusterKind, ClusterUpdate, CreateClusterOptions, DirTarget};
use oneclient_common::domain::{GameLoader, ProviderId};
use oneclient_common::patch::Patch;
use oneclient_content::modpacks::{self, ModpackInstallReport, ModpackManifest, ModpackRelease};
use oneclient_content::packages::store::artifact_absolute_path;
use oneclient_content::packages::{
    PackageStore, ProjectDetail, ResolvedAlternative, fetch_modpack_explanation, load_bad_modpacks,
};
use oneclient_content::{ContentCtx, ContentError};
use oneclient_db::dao::artifact::get_artifact_by_hash;
use oneclient_db::dao::cluster_bundle as bundle_dao;
use oneclient_db::models::OverrideType;
use oneclient_events::GroupedProgressSession;

use super::share::{
    SharedCluster, install_shared_instance, planned_bundle_content, resolve_base_modpack,
    shared_options,
};
use crate::LauncherResult;
use crate::images::DEFAULT_IMAGE_EDGE;
use crate::state::LauncherState;

const FALLBACK_NAME: &str = "Modpack";
const MODPACK_ICON_EDGE: u32 = 256;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ModpackSource {
    File(PathBuf),
    Provider {
        provider: ProviderId,
        project_id: String,
        version_id: String,
    },
}

#[derive(Debug, Clone)]
pub struct ModpackCluster {
    pub cluster: Cluster,
    pub report: ModpackInstallReport,
}

#[derive(Debug, Clone)]
pub struct PreparedModpack {
    pub source: ModpackSource,
    pub artifact_hash: String,
    pub archive_path: PathBuf,
    pub manifest: ModpackManifest,
    pub instance_name: String,
    pub flagged: Option<FlaggedModpack>,
    pub unlisted: Vec<modpacks::UnlistedMod>,
    pub mods_unchecked: bool,
    pub mods_unconfirmed: usize,
    pub share: Option<SharedCluster>,
    pub choices: PackChoices,
}

#[derive(Debug, Clone, Default)]
pub struct PackChoices {
    pub skipped: HashSet<String>,
    pub alternatives: Vec<ResolvedAlternative>,
    pub bundles: Option<Vec<String>>,
}

impl PreparedModpack {
    #[must_use]
    pub fn summary(&self) -> modpacks::ModpackSummary {
        match &self.share {
            Some(shared) => shared.summary(&self.manifest),
            None => self.manifest.summary(),
        }
    }

    #[must_use]
    pub fn notices(&self) -> &[String] {
        self.share
            .as_ref()
            .map_or(&[], |shared| shared.notices.as_slice())
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FlaggedModpack {
    pub explanation: Option<String>,
}

#[tracing::instrument(skip(state, progress))]
pub async fn prepare_modpack(
    state: &Arc<LauncherState>,
    source: &ModpackSource,
    progress: Option<&GroupedProgressSession>,
) -> LauncherResult<PreparedModpack> {
    let content = state.services.content();

    let artifact = match source {
        ModpackSource::File(path) => modpacks::store_modpack_archive(path, &content).await?,
        ModpackSource::Provider {
            provider,
            project_id,
            version_id,
        } => {
            PackageStore::resolve_or_download(*provider, project_id, version_id, progress, &content)
                .await?
        }
    };
    let archive_path = artifact_absolute_path(&artifact.path)?;
    let manifest = modpacks::read_modpack(&archive_path, &content).await?;
    let flagged = screen_modpack(source, &artifact.hash, &content).await;

    let taken: Vec<String> = state
        .clusters
        .list()
        .await?
        .into_iter()
        .map(|cluster| cluster.name)
        .collect();

    let share = match source {
        ModpackSource::File(_) => modpacks::read_cluster_share(&archive_path).await?,
        ModpackSource::Provider { .. } => None,
    };
    let Some(share) = share else {
        let unlisted = match source {
            ModpackSource::File(_) => unlisted_mods(&archive_path, &manifest, &content).await,
            ModpackSource::Provider { .. } => Some(modpacks::UnlistedReport::default()),
        };
        return Ok(PreparedModpack {
            source: source.clone(),
            artifact_hash: artifact.hash,
            archive_path,
            instance_name: unique_name(&instance_name(&manifest.name), &taken),
            manifest,
            flagged,
            mods_unchecked: unlisted.is_none(),
            mods_unconfirmed: unlisted.as_ref().map_or(0, |report| report.unconfirmed),
            unlisted: unlisted.map(|report| report.unlisted).unwrap_or_default(),
            share: None,
            choices: PackChoices::default(),
        });
    };

    let instance_name = unique_name(&instance_name(&share.name), &taken);
    let extras = modpacks::read_share_extras(&archive_path, &share).await?;
    let bundled = planned_bundle_content(state, &share).await;
    let mut checked = manifest.clone();
    checked.contents.loose.extend(
        share
            .downloads
            .iter()
            .filter(|download| modpacks::trusted_download(&download.url))
            .map(|download| modpacks::LooseFile {
                path: download.path.clone(),
                url: download.url.clone(),
                sha1: download.sha1.clone(),
                size: download.size,
            }),
    );
    let unlisted = unlisted_mods(&archive_path, &checked, &content).await;
    let mut shared = SharedCluster {
        archive_path: archive_path.clone(),
        manifest: manifest.clone(),
        share,
        extras,
        bundled,
        notices: Vec::new(),
        substituted: false,
        mods_checked: unlisted.is_some(),
    };
    let (artifact_hash, archive_path, manifest, flagged) = match shared.share.modpack.clone() {
        Some(pack) => {
            let (base, substituted) =
                resolve_base_modpack(&content, &shared.share, &pack, &mut shared.notices).await?;
            shared.substituted = substituted;
            let base_path = artifact_absolute_path(&base.path)?;
            let base_manifest = modpacks::read_modpack(&base_path, &content).await?;
            let flagged = match flagged {
                Some(flagged) => Some(flagged),
                None => {
                    let base_source = ModpackSource::Provider {
                        provider: pack.provider,
                        project_id: pack.project_id.clone(),
                        version_id: pack.version_id.clone(),
                    };
                    screen_modpack(&base_source, &base.hash, &content).await
                }
            };
            (base.hash, base_path, base_manifest, flagged)
        }
        None => (artifact.hash, archive_path, manifest, flagged),
    };

    Ok(PreparedModpack {
        source: source.clone(),
        artifact_hash,
        archive_path,
        manifest,
        flagged,
        mods_unchecked: unlisted.is_none(),
        mods_unconfirmed: unlisted.as_ref().map_or(0, |report| report.unconfirmed),
        unlisted: unlisted.map(|report| report.unlisted).unwrap_or_default(),
        instance_name,
        share: Some(shared),
        choices: PackChoices::default(),
    })
}

async fn unlisted_mods(
    archive_path: &std::path::Path,
    manifest: &ModpackManifest,
    content: &ContentCtx,
) -> Option<modpacks::UnlistedReport> {
    modpacks::find_unlisted_mods(archive_path, manifest, content)
        .await
        .inspect_err(|err| {
            tracing::warn!(error = %err, "could not check whether the modpack's mods are published");
        })
        .ok()
}

async fn screen_modpack(
    source: &ModpackSource,
    hash: &str,
    content: &ContentCtx,
) -> Option<FlaggedModpack> {
    let list = load_bad_modpacks(content).await;
    if list.bad_mods.is_empty() {
        return None;
    }

    let entry = match list.find(hash) {
        Some(entry) => entry,
        None => {
            let (provider, project_id) = pack_project(source, hash, content).await?;
            match list.find_project(provider, &project_id) {
                Some(entry) => entry,
                None if list.has_name_only_entries() => {
                    let project = content
                        .providers
                        .get(provider)
                        .ok()?
                        .get_project(&project_id, content)
                        .await
                        .inspect_err(|err| {
                            tracing::debug!(error = %err, "could not fetch the modpack project for screening");
                        })
                        .ok()?;
                    list.find_by_name_and_author(&project)?
                }
                None => return None,
            }
        }
    };

    tracing::warn!(hash, "modpack is flagged");
    Some(FlaggedModpack {
        explanation: fetch_modpack_explanation(entry, content).await,
    })
}

async fn pack_project(
    source: &ModpackSource,
    hash: &str,
    content: &ContentCtx,
) -> Option<(ProviderId, String)> {
    match source {
        ModpackSource::Provider {
            provider,
            project_id,
            ..
        } => Some((*provider, project_id.clone())),
        ModpackSource::File(_) => match modpacks::identify_modpack(hash, content).await {
            Ok(release) => release.map(|release| (release.provider, release.project_id)),
            Err(err) => {
                tracing::debug!(error = %err, "could not identify the modpack for screening");
                None
            }
        },
    }
}

#[tracing::instrument(skip(state, prepared), fields(pack = %prepared.manifest.name))]
pub async fn create_modpack_instance(
    state: &Arc<LauncherState>,
    prepared: &PreparedModpack,
) -> LauncherResult<Cluster> {
    let manifest = &prepared.manifest;
    let global = state.settings.read().global_game_settings.clone();
    let options = match &prepared.share {
        Some(shared) => shared_options(prepared, shared),
        None => {
            let mut options = CreateClusterOptions::new(
                prepared.instance_name.clone(),
                manifest.mc_version.clone(),
                manifest.loader,
            )
            .kind(kind_for(manifest.loader))
            .user_created(true)
            .modpack(true);
            options.mc_loader_version = manifest.loader_version.clone();
            options.description = manifest.summary.clone();
            options
        }
    };

    let cluster = state.clusters.create(&global, options).await?;
    if prepared
        .share
        .as_ref()
        .is_some_and(|shared| shared.share.dedicated_dir && !cluster.uses_dedicated_dir())
    {
        state
            .clusters
            .set_dir_target(cluster.id, &DirTarget::Dedicated, false)
            .await?;
    }
    if prepared
        .share
        .as_ref()
        .is_some_and(|shared| shared.share.modpack.is_none())
    {
        return Ok(cluster);
    }
    let linked = state
        .clusters
        .update(
            cluster.id,
            ClusterUpdate {
                linked_modpack_hash: Patch::Set(prepared.artifact_hash.clone()),
                ..Default::default()
            },
        )
        .await;

    match linked {
        Ok(cluster) => Ok(cluster),
        Err(err) => {
            if let Err(cleanup) = state.clusters.delete(cluster.id, true).await {
                tracing::warn!(cluster_id = cluster.id, error = %cleanup, "could not remove the unlinked modpack instance");
            }
            Err(err.into())
        }
    }
}

#[tracing::instrument(skip(state, prepared, progress), fields(pack = %prepared.manifest.name))]
pub async fn install_modpack_instance(
    state: &Arc<LauncherState>,
    cluster_id: i64,
    prepared: &PreparedModpack,
    progress: Option<&GroupedProgressSession>,
) -> LauncherResult<ModpackCluster> {
    if let Some(shared) = &prepared.share {
        return install_shared_instance(state, cluster_id, prepared, shared, progress).await;
    }

    let content = state.services.content();
    for package_id in &prepared.choices.skipped {
        bundle_dao::save_override(
            &content.db,
            cluster_id,
            modpacks::MODPACK_BUNDLE_NAME,
            package_id,
            OverrideType::Removed,
        )
        .await?;
    }
    let report = modpacks::install_modpack(
        &prepared.archive_path,
        &prepared.manifest,
        cluster_id,
        modpacks::MODPACK_BUNDLE_NAME,
        progress,
        &content,
    )
    .await?;

    link_project_details(state, cluster_id, &prepared.artifact_hash).await;

    let cluster = state.clusters.get(cluster_id).await?;
    Ok(ModpackCluster { cluster, report })
}

pub(super) async fn link_project_details(
    state: &Arc<LauncherState>,
    cluster_id: i64,
    artifact_hash: &str,
) {
    let content = state.services.content();
    match modpacks::identify_modpack(artifact_hash, &content).await {
        Ok(Some(release)) => {
            if let Err(err) = apply_project_details(state, cluster_id, &release).await {
                tracing::debug!(cluster_id, error = %err, "could not read the modpack's project page");
            }
        }
        Ok(None) => {}
        Err(err) => {
            tracing::debug!(error = %err, "could not identify the modpack on any provider");
        }
    }
}

#[tracing::instrument(skip(state, progress))]
pub async fn update_modpack_cluster(
    state: &Arc<LauncherState>,
    cluster_id: i64,
    version_id: &str,
    progress: Option<&GroupedProgressSession>,
) -> LauncherResult<ModpackCluster> {
    let content = state.services.content();
    let cluster = state.clusters.get(cluster_id).await?;
    let current = modpacks::cluster_modpack(cluster_id, &content)
        .await?
        .ok_or_else(|| ContentError::InvalidData {
            reason: "This instance's modpack is not published on Modrinth or CurseForge."
                .to_string(),
        })?;

    let artifact = PackageStore::resolve_or_download(
        current.provider,
        &current.project_id,
        version_id,
        progress,
        &content,
    )
    .await?;
    let archive_path = artifact_absolute_path(&artifact.path)?;
    let manifest = modpacks::read_modpack(&archive_path, &content).await?;

    if manifest.mc_version != cluster.mc_version || manifest.loader != cluster.mc_loader {
        return Err(ContentError::InvalidData {
            reason: format!(
                "This version needs Minecraft {} with {}. Install it as a new instance instead.",
                manifest.mc_version, manifest.loader
            ),
        }
        .into());
    }

    let report = modpacks::install_modpack(
        &archive_path,
        &manifest,
        cluster_id,
        modpacks::MODPACK_BUNDLE_NAME,
        progress,
        &content,
    )
    .await?;

    let keeps_newer_loader = match (&manifest.loader_version, &cluster.mc_loader_version) {
        (Some(version), Some(current)) => {
            modpacks::is_newer_version(current, version)
                && super::modpack_import::has_imported_packs(&cluster).await
        }
        _ => false,
    };
    let loader_version = match &manifest.loader_version {
        Some(version)
            if cluster.mc_loader_version.as_ref() != Some(version) && !keeps_newer_loader =>
        {
            Patch::Set(version.clone())
        }
        _ => Patch::Unchanged,
    };
    let cluster = state
        .clusters
        .update(
            cluster_id,
            ClusterUpdate {
                linked_modpack_hash: Patch::Set(artifact.hash.clone()),
                mc_loader_version: loader_version,
                ..Default::default()
            },
        )
        .await?;
    restore_missing_icon(state, &cluster).await;

    Ok(ModpackCluster { cluster, report })
}

#[tracing::instrument(skip(state, progress))]
pub async fn repair_modpack_cluster(
    state: &Arc<LauncherState>,
    cluster_id: i64,
    progress: Option<&GroupedProgressSession>,
) -> LauncherResult<ModpackCluster> {
    let content = state.services.content();
    let cluster = state.clusters.get(cluster_id).await?;
    let (archive_path, manifest) = linked_modpack_archive(state, &cluster).await?;

    let report = modpacks::install_modpack(
        &archive_path,
        &manifest,
        cluster_id,
        modpacks::MODPACK_BUNDLE_NAME,
        progress,
        &content,
    )
    .await?;
    restore_missing_icon(state, &cluster).await;

    Ok(ModpackCluster { cluster, report })
}

pub(crate) async fn linked_modpack_archive(
    state: &Arc<LauncherState>,
    cluster: &Cluster,
) -> LauncherResult<(PathBuf, ModpackManifest)> {
    let hash = cluster
        .linked_modpack_hash
        .clone()
        .ok_or_else(|| ContentError::InvalidData {
            reason: "This instance was not installed from a modpack.".to_string(),
        })?;

    let artifact = get_artifact_by_hash(&state.services.db, &hash)
        .await?
        .ok_or_else(|| ContentError::InvalidData {
            reason:
                "The modpack file for this instance is gone. Update the pack to fetch it again."
                    .to_string(),
        })?;
    let archive_path = artifact_absolute_path(&artifact.path)?;
    let manifest = modpacks::read_modpack(&archive_path, &state.services.content()).await?;
    Ok((archive_path, manifest))
}

pub(super) async fn fetch_project(
    state: &Arc<LauncherState>,
    release: &ModpackRelease,
) -> LauncherResult<ProjectDetail> {
    let content = state.services.content();
    Ok(content
        .providers
        .get(release.provider)?
        .get_project(&release.project_id, &content)
        .await?)
}

async fn apply_project_details(
    state: &Arc<LauncherState>,
    cluster_id: i64,
    release: &ModpackRelease,
) -> LauncherResult<()> {
    let project = fetch_project(state, release).await?;
    let cluster = state.clusters.get(cluster_id).await?;

    if let Err(err) = apply_project_description(state, &cluster, &project).await {
        tracing::debug!(cluster_id, error = %err, "could not set the modpack description");
    }
    if let Err(err) = save_project_icon(state, &cluster, &project).await {
        tracing::debug!(cluster_id, error = %err, "no icon for the modpack");
    }
    if let Err(err) = apply_project_cover(state, &cluster, &project).await {
        tracing::debug!(cluster_id, error = %err, "no cover art for the modpack");
    }
    Ok(())
}

async fn save_project_icon(
    state: &Arc<LauncherState>,
    cluster: &Cluster,
    project: &ProjectDetail,
) -> LauncherResult<()> {
    let (Some(url), Some(dest)) = (
        project.icon_url.as_deref().filter(|url| !url.is_empty()),
        cluster.modpack_icon_file(),
    ) else {
        return Ok(());
    };

    let cached = state
        .images
        .ensure_on_disk(&state.services.requester, url, MODPACK_ICON_EDGE)
        .await?;
    if let Some(parent) = dest.parent() {
        polyio::create_dir_all(parent).await?;
    }
    polyio::copy(&cached, &dest).await?;
    Ok(())
}

async fn restore_missing_icon(state: &Arc<LauncherState>, cluster: &Cluster) {
    if cluster
        .modpack_icon_file()
        .is_none_or(|icon| icon.is_file())
    {
        return;
    }

    let content = state.services.content();
    let restored = async {
        let Some(release) = modpacks::cluster_modpack(cluster.id, &content).await? else {
            return Ok(());
        };
        let project = fetch_project(state, &release).await?;
        save_project_icon(state, cluster, &project).await
    };
    let result: LauncherResult<()> = restored.await;
    if let Err(err) = result {
        tracing::debug!(cluster_id = cluster.id, error = %err, "could not restore the modpack icon");
    }
}

async fn apply_project_description(
    state: &Arc<LauncherState>,
    cluster: &Cluster,
    project: &ProjectDetail,
) -> LauncherResult<()> {
    let Some(description) = project_description(cluster.description.as_deref(), project) else {
        return Ok(());
    };

    state
        .clusters
        .update(
            cluster.id,
            ClusterUpdate {
                description: Patch::Set(description),
                ..Default::default()
            },
        )
        .await?;
    Ok(())
}

fn project_description(current: Option<&str>, project: &ProjectDetail) -> Option<String> {
    if current.is_some_and(|current| !current.trim().is_empty()) {
        return None;
    }
    let summary = project.summary.trim();
    (!summary.is_empty()).then(|| summary.to_string())
}

async fn apply_project_cover(
    state: &Arc<LauncherState>,
    cluster: &Cluster,
    project: &ProjectDetail,
) -> LauncherResult<()> {
    let Some(url) = cover_url(project) else {
        return Ok(());
    };

    let cached = state
        .images
        .ensure_on_disk(&state.services.requester, &url, DEFAULT_IMAGE_EDGE)
        .await?;
    state
        .clusters
        .set_cover_from_file(cluster.id, &cached)
        .await?;
    Ok(())
}

fn cover_url(project: &ProjectDetail) -> Option<String> {
    project
        .gallery
        .iter()
        .find(|image| image.featured)
        .or_else(|| project.gallery.first())
        .map(|image| image.url.clone())
        .or_else(|| project.icon_url.clone())
        .filter(|url| !url.is_empty())
}

pub(crate) fn kind_for(loader: GameLoader) -> ClusterKind {
    if loader.is_modded() {
        ClusterKind::Modded
    } else {
        ClusterKind::Vanilla
    }
}

pub(crate) fn unique_name(base: &str, taken: &[String]) -> String {
    let is_taken = |candidate: &str| {
        taken
            .iter()
            .any(|name| name.trim().eq_ignore_ascii_case(candidate))
    };
    if !is_taken(base) {
        return base.to_string();
    }

    (2..)
        .map(|n| format!("{base} ({n})"))
        .find(|candidate| !is_taken(candidate))
        .unwrap_or_else(|| base.to_string())
}

pub(crate) fn instance_name(pack_name: &str) -> String {
    let name = pack_name
        .chars()
        .filter(|c| is_allowed_name_char(*c))
        .collect::<String>()
        .split_whitespace()
        .collect::<Vec<_>>()
        .join(" ");

    if validate_modpack_instance_name(&name).is_ok() {
        name
    } else {
        FALLBACK_NAME.to_string()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn project(summary: &str) -> ProjectDetail {
        ProjectDetail {
            id: "pack".into(),
            slug: "pack".into(),
            provider: ProviderId::Modrinth,
            content_type: oneclient_content::packages::ContentType::Modpack,
            name: "Pack".into(),
            summary: summary.into(),
            author: String::new(),
            members: Vec::new(),
            gallery: Vec::new(),
            body: oneclient_content::packages::PackageBody::Raw(String::new()),
            license: None,
            links: Vec::new(),
            version_ids: Vec::new(),
            game_versions: Vec::new(),
            loaders: Vec::new(),
            icon_url: None,
            created: chrono::Utc::now(),
            updated: chrono::Utc::now(),
            downloads: 0,
        }
    }

    #[test]
    fn the_project_summary_only_fills_an_empty_description() {
        let summary = "  Adventure pack with 300+ mods.  ";

        assert_eq!(
            project_description(None, &project(summary)),
            Some("Adventure pack with 300+ mods.".to_string())
        );
        assert_eq!(
            project_description(Some("   "), &project(summary)),
            Some("Adventure pack with 300+ mods.".to_string())
        );
        assert_eq!(project_description(Some("Mine"), &project(summary)), None);
        assert_eq!(project_description(None, &project("   ")), None);
    }

    #[test]
    fn pack_names_are_cut_down_to_a_valid_instance_name() {
        assert_eq!(
            instance_name("Fabulously Optimized"),
            "Fabulously Optimized"
        );
        assert_eq!(
            instance_name("All the Mods 10: To the Sky"),
            "All the Mods 10: To the Sky"
        );
        assert_eq!(instance_name("Better MC [FORGE]"), "Better MC [FORGE]");
        assert_eq!(instance_name("✨✨✨"), FALLBACK_NAME);
        assert_eq!(instance_name(""), FALLBACK_NAME);
    }

    #[test]
    fn a_second_copy_of_a_pack_gets_a_numbered_name() {
        let taken = vec!["Better MC FABRIC BMC".to_string()];
        assert_eq!(
            unique_name("Better MC FABRIC BMC", &taken),
            "Better MC FABRIC BMC (2)"
        );

        let taken = vec!["Fabulously".to_string(), "fabulously (2)".to_string()];
        assert_eq!(unique_name("Fabulously", &taken), "Fabulously (3)");
        assert_eq!(unique_name("Fresh", &taken), "Fresh");
        assert!(validate_modpack_instance_name(&unique_name("Fabulously", &taken)).is_ok());
    }

    #[test]
    fn a_pack_without_a_loader_makes_a_vanilla_instance() {
        assert_eq!(kind_for(GameLoader::Vanilla), ClusterKind::Vanilla);
        assert_eq!(kind_for(GameLoader::Fabric), ClusterKind::Modded);
    }
}
