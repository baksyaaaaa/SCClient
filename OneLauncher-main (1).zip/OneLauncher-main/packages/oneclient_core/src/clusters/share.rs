use std::collections::{BTreeSet, HashMap, HashSet};
use std::path::{Path, PathBuf};
use std::str::FromStr;
use std::sync::Arc;

use oneclient_cluster::naming::validate_tag;
use oneclient_cluster::profiles::get_profile_or_default;
use oneclient_cluster::{Cluster, ClusterKind, ClusterUpdate, CreateClusterOptions, ProfileUpdate};
use oneclient_common::domain::ContentType;
use oneclient_common::patch::Patch;
use oneclient_content::modpacks::{
    self, ClusterShare, ModpackInstallReport, ModpackManifest, ModpackSummary, SHARE_FORMAT,
    SettingFile, SettingsScan, ShareExportReport, ShareExtras, ShareIcon, ShareScope,
    SharedFileSource, SharedJava, SharedModpack, SharedPlaytime, SharedSession,
};
use oneclient_content::packages::PackageStore;
use oneclient_content::{ContentCtx, ContentError};
use oneclient_db::dao::cluster as cluster_dao;
use oneclient_db::dao::cluster_bundle as bundle_dao;
use oneclient_db::dao::game_session as session_dao;
use oneclient_db::models::{ArtifactRow, NewGameSession, OverrideType};
use oneclient_events::{GroupedProgressSession, TaskCategory, TaskPhase};
use oneclient_java::JavaVendor;
use serde::{Deserialize, Serialize};

use super::modpack::{ModpackCluster, PreparedModpack, kind_for, link_project_details};
use crate::LauncherResult;
use crate::state::LauncherState;

const MAX_ICON_BYTES: u64 = 8 * 1024 * 1024;

#[derive(Debug, Clone)]
pub struct SharedCluster {
    pub archive_path: PathBuf,
    pub manifest: ModpackManifest,
    pub share: ClusterShare,
    pub extras: ShareExtras,
    pub bundled: Vec<(ContentType, u64)>,
    pub notices: Vec<String>,
    pub substituted: bool,
    pub mods_checked: bool,
}

impl SharedCluster {
    #[must_use]
    pub fn summary(&self, base: &ModpackManifest) -> ModpackSummary {
        let own = self.manifest.summary();
        let mut summary = if self.share.modpack.is_none() {
            own
        } else {
            let pack = base.summary();
            ModpackSummary {
                mods: pack.mods + own.mods,
                resource_packs: pack.resource_packs + own.resource_packs,
                shaders: pack.shaders + own.shaders,
                other_files: pack.other_files,
                optional: pack.optional + own.optional,
                manual: pack.manual,
                unresolved: pack.unresolved + own.unresolved,
                unverified: 0,
                download_bytes: pack.download_bytes + own.download_bytes,
            }
        };

        for content_type in &self.extras.embedded {
            count_content(&mut summary, *content_type);
        }
        summary.unverified = self
            .extras
            .embedded
            .iter()
            .filter(|content_type| !self.mods_checked || **content_type != ContentType::Mod)
            .count();
        if self.share.kind.is_isolated() || self.share.dedicated_dir {
            summary.other_files += self.extras.other_files;
        }
        for (content_type, size) in self.extras.downloads.iter().chain(&self.bundled) {
            count_content(&mut summary, *content_type);
            summary.download_bytes += size;
        }
        summary
    }
}

pub(super) async fn planned_bundle_content(
    state: &Arc<LauncherState>,
    share: &ClusterShare,
) -> Vec<(ContentType, u64)> {
    if share.kind != ClusterKind::OneClient || share.modpack.is_some() {
        return Vec::new();
    }
    let archives = match state
        .bundles
        .archives_for(
            &state.services.content(),
            &share.mc_version,
            share.mc_loader,
        )
        .await
    {
        Ok(archives) => archives,
        Err(err) => {
            tracing::debug!(mc_version = %share.mc_version, error = %err, "could not read the bundles a shared instance takes");
            return Vec::new();
        }
    };

    let accepted: HashSet<String> = share
        .bundles
        .iter()
        .filter(|choice| choice.accepted)
        .map(|choice| choice.name.clone())
        .collect();
    let overrides: HashMap<(&str, &str), OverrideType> = share
        .overrides
        .iter()
        .filter_map(|o| {
            Some((
                (o.bundle.as_str(), o.package_id.as_str()),
                o.override_type()?,
            ))
        })
        .collect();

    oneclient_content::bundles::wanted_bundle_files(
        archives.iter().map(|archive| &archive.manifest),
        &accepted,
        |bundle, package| overrides.get(&(bundle, package)).copied(),
    )
    .into_iter()
    .map(|file| (file.content_type(), file.size))
    .collect()
}

fn count_content(summary: &mut ModpackSummary, content_type: ContentType) {
    match content_type {
        ContentType::ResourcePack => summary.resource_packs += 1,
        ContentType::Shader => summary.shaders += 1,
        _ => summary.mods += 1,
    }
}

pub(super) async fn resolve_base_modpack(
    content: &ContentCtx,
    share: &ClusterShare,
    pack: &SharedModpack,
    notices: &mut Vec<String>,
) -> LauncherResult<(ArtifactRow, bool)> {
    match PackageStore::resolve_or_download(
        pack.provider,
        &pack.project_id,
        &pack.version_id,
        None,
        content,
    )
    .await
    {
        Ok(artifact) => return Ok((artifact, false)),
        Err(err) => {
            tracing::warn!(project_id = %pack.project_id, version_id = %pack.version_id, error = %err, "the shared modpack version is unavailable; looking for another");
        }
    }

    let Some(version) = modpacks::latest_modpack_version(
        pack.provider,
        &pack.project_id,
        &share.mc_version,
        share.mc_loader,
        content,
    )
    .await?
    else {
        return Err(ContentError::InvalidData {
            reason: format!(
                "The modpack this instance is built on is no longer available on {} for Minecraft {}.",
                pack.provider, share.mc_version
            ),
        }
        .into());
    };

    let artifact = PackageStore::resolve_or_download(
        pack.provider,
        &pack.project_id,
        &version.version_id,
        None,
        content,
    )
    .await?;
    notices.push(format!(
        "The modpack version this instance was made with is no longer available, so {} is installed instead.",
        version.version_number
    ));
    Ok((artifact, true))
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ExportMode {
    OneClient,
    Compatibility,
}

#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "kind", content = "paths", rename_all = "snake_case")]
pub enum SettingsChoice {
    #[default]
    None,
    All,
    Only(BTreeSet<String>),
    AllExcept(BTreeSet<String>),
}

impl SettingsChoice {
    #[must_use]
    pub fn includes_any(&self) -> bool {
        match self {
            Self::None => false,
            Self::All | Self::AllExcept(_) => true,
            Self::Only(paths) => !paths.is_empty(),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ExportOptions {
    pub mode: ExportMode,
    #[serde(default)]
    pub settings: SettingsChoice,
    #[serde(default)]
    pub skip_types: Vec<ContentType>,
    #[serde(default, skip_serializing_if = "BTreeSet::is_empty")]
    pub left_out_files: BTreeSet<String>,
    #[serde(default, skip_serializing_if = "std::ops::Not::not")]
    pub playtime: bool,
}

impl ExportOptions {
    #[must_use]
    pub fn new(mode: ExportMode) -> Self {
        Self {
            mode,
            settings: SettingsChoice::None,
            skip_types: Vec::new(),
            left_out_files: BTreeSet::new(),
            playtime: false,
        }
    }

    #[must_use]
    pub fn without_types(mut self, skip_types: Vec<ContentType>) -> Self {
        self.skip_types = skip_types;
        self
    }

    #[must_use]
    pub fn with_settings(mut self, include: bool) -> Self {
        self.settings = if include {
            SettingsChoice::All
        } else {
            SettingsChoice::None
        };
        self
    }

    #[must_use]
    pub fn with_setting_choice(mut self, settings: SettingsChoice) -> Self {
        self.settings = settings;
        self
    }

    #[must_use]
    pub fn with_left_out_files(mut self, paths: BTreeSet<String>) -> Self {
        self.left_out_files = paths;
        self
    }

    #[must_use]
    pub fn with_playtime(mut self, include: bool) -> Self {
        self.playtime = include;
        self
    }
}

pub async fn collect_chosen_settings(
    game_dir: &Path,
    choice: &SettingsChoice,
) -> LauncherResult<SettingsScan> {
    let mut scan = match choice {
        SettingsChoice::None => return Ok(SettingsScan::default()),
        SettingsChoice::All | SettingsChoice::Only(_) | SettingsChoice::AllExcept(_) => {
            modpacks::collect_settings(game_dir).await?
        }
    };
    let keep = |path: &str| match choice {
        SettingsChoice::Only(paths) => paths.contains(path),
        SettingsChoice::AllExcept(paths) => !paths.contains(path),
        SettingsChoice::None | SettingsChoice::All => true,
    };
    scan.files.retain(|file| keep(&file.path));
    scan.skipped.retain(|path| keep(path));
    scan.bytes = scan.files.iter().map(|file| file.size).sum();
    Ok(scan)
}

pub async fn list_setting_files(
    state: &Arc<LauncherState>,
    cluster_id: i64,
) -> LauncherResult<Vec<SettingFile>> {
    let cluster = state.clusters.get(cluster_id).await?;
    Ok(modpacks::collect_settings(&cluster.game_dir()?)
        .await?
        .files)
}

pub async fn list_embedded_files(
    state: &Arc<LauncherState>,
    cluster_id: i64,
    mode: ExportMode,
) -> LauncherResult<Vec<SettingFile>> {
    let content = state.services.content();
    let cluster = state.clusters.get(cluster_id).await?;
    let (_, scope) = share_scope(
        &cluster,
        mode == ExportMode::Compatibility,
        Vec::new(),
        &content,
    )
    .await;
    let shared = modpacks::collect_share_content(cluster_id, scope, None, &content).await?;
    Ok(shared
        .files
        .into_iter()
        .filter_map(|file| match file.source {
            SharedFileSource::Embed(source) => Some(SettingFile {
                path: file.path,
                source,
                size: file.size,
            }),
            SharedFileSource::Download { .. } => None,
        })
        .collect())
}

async fn share_scope(
    cluster: &Cluster,
    compatible: bool,
    skip_types: Vec<ContentType>,
    content: &ContentCtx,
) -> (Option<SharedModpack>, ShareScope) {
    let modpack = match cluster.linked_modpack_hash {
        Some(_) if compatible => None,
        Some(_) => modpacks::cluster_modpack(cluster.id, content)
            .await
            .inspect_err(|err| {
                tracing::debug!(cluster_id = cluster.id, error = %err, "could not identify the linked modpack; exporting every file");
            })
            .ok()
            .flatten()
            .map(|release| SharedModpack {
                provider: release.provider,
                project_id: release.project_id,
                version_id: release.version_id,
            }),
        None => None,
    };
    let scope = ShareScope {
        skip_bundles: cluster.kind == ClusterKind::OneClient && !compatible,
        skip_modpack: modpack.is_some(),
        skip_types,
    };
    (modpack, scope)
}

pub async fn export_cluster(
    state: &Arc<LauncherState>,
    cluster_id: i64,
    dest: &Path,
    mode: ExportMode,
    progress: Option<&GroupedProgressSession>,
) -> LauncherResult<ShareExportReport> {
    export_cluster_with(state, cluster_id, dest, ExportOptions::new(mode), progress).await
}

#[tracing::instrument(skip(state, progress))]
pub async fn export_cluster_with(
    state: &Arc<LauncherState>,
    cluster_id: i64,
    dest: &Path,
    options: ExportOptions,
    progress: Option<&GroupedProgressSession>,
) -> LauncherResult<ShareExportReport> {
    let mode = options.mode;
    let content = state.services.content();
    let cluster = state.clusters.get(cluster_id).await?;
    let child = progress.map(|session| {
        let child = session.child(cluster.name.clone(), 1, TaskCategory::Packages);
        child.set_phase(TaskPhase::Exporting);
        child
    });

    let compatible =
        mode == ExportMode::Compatibility || options.skip_types.contains(&ContentType::Mod);
    let (modpack, scope) =
        share_scope(&cluster, compatible, options.skip_types.clone(), &content).await;
    let kind = if compatible && cluster.kind == ClusterKind::OneClient {
        kind_for(cluster.mc_loader)
    } else {
        cluster.kind
    };
    let mut shared =
        modpacks::collect_share_content(cluster_id, scope, child.as_ref(), &content).await?;
    shared
        .files
        .retain(|file| !options.left_out_files.contains(&file.path));
    shared.settings = collect_chosen_settings(&cluster.game_dir()?, &options.settings).await?;
    let with_settings = !shared.settings.files.is_empty();

    let share = ClusterShare {
        format: SHARE_FORMAT,
        name: cluster.name.clone(),
        description: cluster.description.clone(),
        tags: cluster.tags.clone(),
        kind,
        mc_version: cluster.mc_version.clone(),
        mc_loader: cluster.mc_loader,
        mc_loader_version: exported_loader_version(state, &cluster).await?,
        dedicated_dir: cluster.uses_dedicated_dir() || kind.is_isolated() || with_settings,
        java: exported_java(state, &cluster).await,
        modpack,
        bundles: Vec::new(),
        overrides: Vec::new(),
        disabled: Vec::new(),
        downloads: Vec::new(),
        icon: None,
        settings: Vec::new(),
        left_out_settings: match &options.settings {
            SettingsChoice::AllExcept(paths) => paths.iter().cloned().collect(),
            _ => Vec::new(),
        },
        playtime: if options.playtime && !compatible {
            Some(exported_playtime(state, &cluster).await?)
        } else {
            None
        },
    };
    let icon = exported_icon(&cluster).await;

    let report =
        modpacks::write_share_archive(dest, &share, &shared, icon.as_ref(), child.as_ref()).await?;
    if let Some(child) = child {
        child.finish();
    }
    Ok(report)
}

async fn exported_playtime(
    state: &Arc<LauncherState>,
    cluster: &Cluster,
) -> LauncherResult<SharedPlaytime> {
    let sessions = session_dao::list_sessions_for_cluster(&state.services.db, cluster.id)
        .await?
        .into_iter()
        .filter_map(|row| {
            Some(SharedSession {
                ended_at: row.ended_at?,
                started_at: row.started_at,
                exit_code: row.exit_code,
                ram_allocated_mb: row.ram_allocated_mb,
                mods_enabled: row.mods_enabled,
                java_vendor: row.java_vendor,
                java_version: row.java_version,
            })
        })
        .collect();
    Ok(SharedPlaytime {
        played_secs: cluster.overall_played.as_secs(),
        last_played: cluster.last_played.map(|at| at.to_rfc3339()),
        sessions,
    })
}

const MAX_IMPORTED_PLAYED_SECS: u64 = 100 * 365 * 24 * 60 * 60;
const MAX_IMPORTED_SESSIONS: usize = 10_000;

async fn import_playtime(
    db: &oneclient_db::DbPool,
    cluster_id: i64,
    playtime: &SharedPlaytime,
) -> Result<(), sqlx::Error> {
    let mut tx = db.begin().await?;
    if playtime.played_secs > 0 {
        let secs =
            i64::try_from(playtime.played_secs.min(MAX_IMPORTED_PLAYED_SECS)).unwrap_or(i64::MAX);
        cluster_dao::add_playtime(&mut *tx, cluster_id, secs).await?;
    }
    let last_played = playtime
        .last_played
        .as_deref()
        .and_then(|at| chrono::DateTime::parse_from_rfc3339(at).ok())
        .map(|at| at.to_rfc3339());
    cluster_dao::set_last_played(&mut *tx, cluster_id, last_played.as_deref()).await?;
    for session in playtime.sessions.iter().take(MAX_IMPORTED_SESSIONS) {
        if let Some((started_at, ended_at)) =
            insert_imported_session(&mut tx, cluster_id, session).await?
        {
            session_dao::finish_session_at(&mut *tx, &started_at, &ended_at, session.exit_code)
                .await?;
        }
    }
    tx.commit().await
}

async fn insert_imported_session(
    tx: &mut sqlx::Transaction<'_, sqlx::Sqlite>,
    cluster_id: i64,
    session: &SharedSession,
) -> Result<Option<(String, String)>, sqlx::Error> {
    let (Ok(started), Ok(ended)) = (
        chrono::DateTime::parse_from_rfc3339(&session.started_at),
        chrono::DateTime::parse_from_rfc3339(&session.ended_at),
    ) else {
        return Ok(None);
    };
    if ended <= started || ended - started > chrono::Duration::days(31) {
        return Ok(None);
    }
    for step in 0..5 {
        let shift = chrono::Duration::milliseconds(step);
        let started_at = (started + shift).to_rfc3339();
        let new = NewGameSession {
            cluster_id,
            started_at: &started_at,
            ram_allocated_mb: session.ram_allocated_mb,
            mods_enabled: session.mods_enabled,
            java_vendor: session.java_vendor.as_deref(),
            java_version: session.java_version.as_deref(),
        };
        match session_dao::insert_session(&mut **tx, &new).await {
            Ok(_) => return Ok(Some((started_at, (ended + shift).to_rfc3339()))),
            Err(err)
                if err
                    .as_database_error()
                    .is_some_and(|err| err.is_unique_violation()) => {}
            Err(err) => return Err(err),
        }
    }
    Ok(None)
}

async fn exported_loader_version(
    state: &Arc<LauncherState>,
    cluster: &Cluster,
) -> LauncherResult<Option<String>> {
    if !cluster.mc_loader.is_modded() {
        return Ok(None);
    }
    let resolved = super::prepare::resolved_loader_version(state, cluster)
        .await
        .inspect_err(|err| {
            tracing::warn!(cluster_id = cluster.id, error = %err, "could not work out the loader version to export");
        })
        .ok()
        .flatten();
    match resolved {
        Some(version) => Ok(Some(version)),
        None => Err(ContentError::InvalidData {
            reason: format!(
                "Couldn't work out which {} version this instance uses. Check your connection and try again.",
                cluster.mc_loader
            ),
        }
        .into()),
    }
}

async fn exported_java(state: &Arc<LauncherState>, cluster: &Cluster) -> Option<SharedJava> {
    let global = state.settings.read().global_game_settings.clone();
    let profile = get_profile_or_default(
        &state.services.db,
        &global,
        cluster.setting_profile_name.as_deref(),
    )
    .await
    .ok()?;
    let java_path = profile
        .java_path
        .filter(|path| global.java_path.as_ref() != Some(path))?;
    let runtime = state
        .java
        .runtime_for_profile(Some(&java_path))
        .await
        .ok()
        .flatten()?;
    let required = super::required_java_major(state, cluster.id)
        .await
        .inspect_err(|err| {
            tracing::debug!(cluster_id = cluster.id, error = %err, "could not tell which java the version needs");
        })
        .ok()
        .flatten();
    if required == Some(runtime.major) {
        return None;
    }
    Some(SharedJava {
        major: runtime.major,
        vendor: Some(runtime.vendor.to_string()),
    })
}

async fn exported_icon(cluster: &Cluster) -> Option<ShareIcon> {
    for path in [cluster.cover_file(), cluster.modpack_icon_file()]
        .into_iter()
        .flatten()
    {
        let Some(entry) = path
            .extension()
            .and_then(|ext| ext.to_str())
            .and_then(modpacks::icon_entry)
        else {
            continue;
        };
        let Ok(meta) = polyio::stat(&path).await else {
            continue;
        };
        if !meta.is_file() || meta.len() > MAX_ICON_BYTES {
            continue;
        }
        if let Ok(bytes) = polyio::read(&path).await {
            let extension = entry
                .rsplit_once('.')
                .map(|(_, ext)| ext.to_string())
                .unwrap_or_default();
            if extension == "png" {
                return Some(ShareIcon { extension, bytes });
            }
            let converted = tokio::task::spawn_blocking(move || as_png(&bytes))
                .await
                .ok()
                .flatten();
            if let Some(bytes) = converted {
                return Some(ShareIcon {
                    extension: "png".to_string(),
                    bytes,
                });
            }
        }
    }
    None
}

fn as_png(bytes: &[u8]) -> Option<Vec<u8>> {
    let image = image::load_from_memory(bytes).ok()?;
    let mut out = std::io::Cursor::new(Vec::new());
    image.write_to(&mut out, image::ImageFormat::Png).ok()?;
    Some(out.into_inner())
}

pub(super) fn shared_options(
    prepared: &PreparedModpack,
    shared: &SharedCluster,
) -> CreateClusterOptions {
    let share = &shared.share;
    let kind = if share.modpack.is_some() {
        kind_for(share.mc_loader)
    } else {
        share.kind
    };
    let tags = share
        .tags
        .iter()
        .filter(|tag| validate_tag(tag).is_ok())
        .cloned()
        .collect();

    let mut options = CreateClusterOptions::new(
        prepared.instance_name.clone(),
        share.mc_version.clone(),
        share.mc_loader,
    )
    .kind(kind)
    .user_created(true)
    .modpack(true)
    .tags(tags);
    options.mc_loader_version = if shared.substituted {
        prepared.manifest.loader_version.clone()
    } else {
        share.mc_loader_version.clone()
    };
    options.description = share
        .description
        .clone()
        .filter(|text| !text.trim().is_empty());
    options
}

#[tracing::instrument(skip(state, prepared, shared, progress), fields(name = %shared.share.name))]
pub(super) async fn install_shared_instance(
    state: &Arc<LauncherState>,
    cluster_id: i64,
    prepared: &PreparedModpack,
    shared: &SharedCluster,
    progress: Option<&GroupedProgressSession>,
) -> LauncherResult<ModpackCluster> {
    let content = state.services.content();
    let share = &shared.share;

    let overrides: Vec<_> = share
        .overrides
        .iter()
        .filter_map(|o| Some((o.bundle.clone(), o.package_id.clone(), o.override_type()?)))
        .collect();
    bundle_dao::save_overrides(&state.services.db, cluster_id, &overrides).await?;

    let mut report = ModpackInstallReport::default();
    if share.modpack.is_some() {
        report = modpacks::install_modpack(
            &prepared.archive_path,
            &prepared.manifest,
            cluster_id,
            modpacks::MODPACK_BUNDLE_NAME,
            progress,
            &content,
        )
        .await?;
        link_project_details(state, cluster_id, &prepared.artifact_hash).await;
    }

    let cluster = state.clusters.get(cluster_id).await?;
    if cluster.uses_bundles() {
        report
            .failed
            .extend(install_shared_bundles(state, &cluster, share, progress).await);
    }

    let extra = modpacks::install_shared_content(
        &shared.archive_path,
        &shared.manifest,
        share,
        cluster_id,
        progress,
        &content,
    )
    .await?;
    report.installed += extra.installed;
    report.failed.extend(extra.failed);
    report.blocked.extend(extra.blocked);

    report
        .failed
        .extend(apply_shared_settings(state, &cluster, shared, progress).await);

    if let Some(playtime) = &share.playtime
        && let Err(err) = import_playtime(&state.services.db, cluster_id, playtime).await
    {
        tracing::warn!(cluster_id, error = %err, "could not carry over play stats");
    }

    let cluster = state.clusters.get(cluster_id).await?;
    Ok(ModpackCluster { cluster, report })
}

async fn install_shared_bundles(
    state: &Arc<LauncherState>,
    cluster: &Cluster,
    share: &ClusterShare,
    progress: Option<&GroupedProgressSession>,
) -> Vec<String> {
    let mut problems = Vec::new();
    let content = state.services.content();
    let choices: Vec<(String, bool)> = share
        .bundles
        .iter()
        .map(|choice| (choice.name.clone(), choice.accepted))
        .collect();
    if let Err(err) =
        oneclient_content::bundles::set_bundle_choices(cluster.id, &choices, &content).await
    {
        tracing::warn!(cluster_id = cluster.id, error = %err, "could not record the shared bundle choices");
        problems.push("its bundle choices".to_string());
    }
    if let Err(err) = oneclient_content::bundles::install_cluster_bundles(
        cluster.id,
        state.bundles.as_ref(),
        progress,
        &content,
        None,
    )
    .await
    {
        tracing::warn!(cluster_id = cluster.id, error = %err, "could not install bundle content for the shared instance");
        problems.push("its bundle mods".to_string());
    }
    problems
}

async fn apply_shared_settings(
    state: &Arc<LauncherState>,
    cluster: &Cluster,
    shared: &SharedCluster,
    progress: Option<&GroupedProgressSession>,
) -> Vec<String> {
    let mut problems = Vec::new();
    let share = &shared.share;

    if let Some(description) = share
        .description
        .as_ref()
        .filter(|text| !text.trim().is_empty())
        && cluster.description.as_ref() != Some(description)
        && let Err(err) = state
            .clusters
            .update(
                cluster.id,
                ClusterUpdate {
                    description: Patch::Set(description.clone()),
                    ..Default::default()
                },
            )
            .await
    {
        tracing::warn!(cluster_id = cluster.id, error = %err, "could not set the shared description");
        problems.push("its description".to_string());
    }

    if let Err(err) = apply_shared_icon(state, cluster.id, shared).await {
        tracing::warn!(cluster_id = cluster.id, error = %err, "could not set the shared cover");
        problems.push("its cover image".to_string());
    }

    if !cluster.is_isolated()
        && share.dedicated_dir != cluster.uses_dedicated_dir()
        && cluster.shared_group().is_none()
        && let Err(err) = state
            .clusters
            .set_dedicated_dir(cluster.id, share.dedicated_dir, false)
            .await
    {
        tracing::warn!(cluster_id = cluster.id, error = %err, "could not apply the shared game folder setting");
        problems.push("its game folder setting".to_string());
    }

    if let Some(java) = &share.java
        && let Err(err) = apply_shared_java(state, cluster.id, java).await
    {
        tracing::warn!(cluster_id = cluster.id, major = java.major, error = %err, "could not set up the shared java runtime");
        problems.push(format!("its Java {} setting", java.major));
    }

    if cluster.kind == ClusterKind::OneClient
        && let Err(err) =
            super::apply_bundle_java_override(state, cluster.id, true, true, progress).await
    {
        tracing::warn!(cluster_id = cluster.id, error = %err, "could not apply the bundle java override");
        problems.push("the Java version its bundles ask for".to_string());
    }
    problems
}

async fn apply_shared_icon(
    state: &Arc<LauncherState>,
    cluster_id: i64,
    shared: &SharedCluster,
) -> LauncherResult<()> {
    let Some(icon) = modpacks::read_share_icon(&shared.archive_path, &shared.share).await else {
        return Ok(());
    };
    let staging = polyio::tempdir().await?;
    let path = staging.dir_path().join(format!("cover.{}", icon.extension));
    polyio::write(&path, &icon.bytes).await?;
    state
        .clusters
        .set_cover_from_file(cluster_id, &path)
        .await?;
    Ok(())
}

async fn apply_shared_java(
    state: &Arc<LauncherState>,
    cluster_id: i64,
    java: &SharedJava,
) -> LauncherResult<()> {
    let vendor = java
        .vendor
        .as_deref()
        .and_then(|vendor| JavaVendor::from_str(vendor).ok());
    let installed = state
        .java
        .list_runtimes()
        .await?
        .into_iter()
        .filter(|runtime| {
            runtime.major == java.major && Path::new(&runtime.absolute_path).is_file()
        })
        .max_by_key(|runtime| vendor.as_ref() == Some(&runtime.vendor));
    let Some(runtime) = installed else {
        tracing::info!(
            cluster_id,
            major = java.major,
            "no installed java matches the shared one; leaving the instance on its default"
        );
        return Ok(());
    };

    state
        .clusters
        .update_profile(
            cluster_id,
            ProfileUpdate {
                java_path: Patch::Set(runtime.absolute_path.clone()),
                ..Default::default()
            },
        )
        .await?;
    tracing::info!(cluster_id, major = java.major, java_path = %runtime.absolute_path, "applied the shared java runtime");
    Ok(())
}
