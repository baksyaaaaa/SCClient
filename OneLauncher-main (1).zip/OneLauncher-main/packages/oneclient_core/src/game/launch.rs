use std::fmt::Write as _;
use std::path::Path;
use std::process::Stdio;
use std::sync::Arc;
use std::time::{Duration, Instant};

use chrono::{DateTime, Utc};
use interfrost::api::minecraft::ArgumentType;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::process::Command;

use crate::ClusterStage;
use crate::LauncherResult;
use crate::clusters::Cluster;
use crate::game::diagnosis::{CrashDiagnosis, CrashWatch};
use crate::game::mod_problems::{
    InstalledJar, attach_bundled, attach_jar, has_unmatched, has_unmatched_missing,
};
use crate::game::session::SessionRecorder;
use crate::game::shared_dir::{cluster_mods, jar_bundled_mod_ids, jar_mod_id};
use crate::game::tail::spawn_log_tail;
use crate::game::{DirBusy, GameError};
use crate::settings::GameSettingsProfile;
use crate::state::{LauncherServices, LauncherState};
use oneclient_auth::MinecraftAccount;
use oneclient_common::domain::GameLoader;
use oneclient_common::paths;
use oneclient_content::bundles::BUNDLE_APPLY_BUDGET;
use oneclient_discord::Presence;
use oneclient_events::{CrashModIssue, CrashRemedy, GroupedProgressSession, LaunchStage};
use oneclient_mc::{
    self as arguments, download_minecraft, download_version_info, game_files_missing,
    get_loader_version, resolve_minecraft_version,
};

pub fn is_running(state: &LauncherState, cluster_id: i64) -> bool {
    state.games.is_running(cluster_id)
}

#[derive(Debug, Clone)]
pub struct LaunchedGame {
    pub cluster_id: i64,
    pub pid: Option<u32>,
}

#[tracing::instrument(skip(state, account))]
pub async fn launch_cluster(
    state: &Arc<LauncherState>,
    cluster_id: i64,
    account: &MinecraftAccount,
    search_for_java: bool,
) -> LauncherResult<LaunchedGame> {
    launch_cluster_with(state, cluster_id, account, search_for_java, None, None).await
}

#[tracing::instrument(skip(state, account))]
pub async fn launch_cluster_with(
    state: &Arc<LauncherState>,
    cluster_id: i64,
    account: &MinecraftAccount,
    search_for_java: bool,
    extra_jvm_arg: Option<&str>,
    bundle_budget: Option<Duration>,
) -> LauncherResult<LaunchedGame> {
    tracing::info!(cluster_id, search_for_java, "launching cluster");

    // Parallel clusters or not a cluster runs only once a second game would
    // share its directory and its slot in the process manager
    if state.games.is_active(cluster_id) {
        tracing::warn!(
            cluster_id,
            "cluster already launching or running; refusing launch"
        );
        return Err(GameError::AlreadyRunning(cluster_id).into());
    }

    let result = start(
        state,
        cluster_id,
        account,
        search_for_java,
        extra_jvm_arg,
        bundle_budget,
    )
    .await;

    if result.is_err() {
        state.games.remove(cluster_id);
        state
            .services
            .events
            .game_stage(cluster_id, LaunchStage::Exited);
    }

    result
}

fn jvm_args_with(profile_args: Option<&str>, extra: Option<&str>) -> String {
    match (profile_args.unwrap_or_default(), extra) {
        ("", Some(extra)) => extra.to_string(),
        (args, Some(extra)) => format!("{args} {extra}"),
        (args, None) => args.to_string(),
    }
}

async fn start(
    state: &Arc<LauncherState>,
    cluster_id: i64,
    account: &MinecraftAccount,
    search_for_java: bool,
    extra_jvm_arg: Option<&str>,
    bundle_budget: Option<Duration>,
) -> LauncherResult<LaunchedGame> {
    let events = state.services.events.clone();
    let stage = |s: LaunchStage| {
        state.games.set_stage(cluster_id, s);
        events.game_stage(cluster_id, s);
    };

    // The stage goes first so a click while this waits is refused as already
    // active rather than queued behind it
    stage(LaunchStage::Checking);
    let launch_slot = match state.games.try_launch_slot() {
        Some(slot) => slot,
        None => {
            tracing::debug!(cluster_id, "another launch is preparing; waiting for it");
            stage(LaunchStage::Waiting);
            let slot = state.games.launch_slot().await;
            stage(LaunchStage::Checking);
            slot
        }
    };

    // Checked only once this launch counts as active, a reset claims itself before checking
    // for that, so the two can't both go ahead
    if crate::clusters::is_resetting(cluster_id) {
        return Err(GameError::Resetting.into());
    }
    if crate::bisect::is_switching(cluster_id) {
        return Err(GameError::Diagnosing.into());
    }
    match crate::clusters::reset_unfinished(state, cluster_id).await {
        Ok(true) => return Err(GameError::ResetUnfinished.into()),
        Ok(false) => {}
        // Only a guard against launching a half-reset cluster, not worth failing every launch over
        Err(err) => {
            tracing::warn!(cluster_id, error = %err, "could not check for an unfinished reset; launching anyway");
        }
    }

    let existing = state.clusters.get(cluster_id).await?;
    if let Some(group) = existing.missing_shared_group() {
        return Err(GameError::SharedFolderMissing(group).into());
    }

    let game_dir = existing.game_dir()?;
    let dedicated = existing.uses_dedicated_dir();

    // Non-dedicated clusters share one directory so a second game there would
    // materialize over the running one's
    match state.games.claim_dir(cluster_id, &game_dir, !dedicated) {
        Ok(()) => {}
        Err(DirBusy::Syncing(syncing)) if syncing == cluster_id => {
            return Err(GameError::Syncing.into());
        }
        Err(DirBusy::Syncing(syncing)) => {
            tracing::warn!(
                cluster_id,
                syncing,
                "shared game dir is being synced from; refusing launch"
            );
            let name = running_cluster_name(state, syncing).await;
            return Err(GameError::SharedDirectorySyncing(name).into());
        }
        Err(DirBusy::Game(other)) if dedicated => {
            return Err(GameError::DirectoryInUse(other).into());
        }
        Err(DirBusy::Game(other)) => {
            tracing::warn!(cluster_id, other, "shared game dir busy; refusing launch");
            let name = running_cluster_name(state, other).await;
            return Err(GameError::SharedDirectoryBusy(name).into());
        }
    }

    match state.clusters.mark_played(cluster_id).await {
        Ok(()) => events.signal(oneclient_events::Signal::ClustersChanged),
        Err(err) => tracing::debug!(cluster_id, error = %err, "could not record the launch time"),
    }

    let progress = GroupedProgressSession::start(
        &state.services.events,
        format!("Launching {}", existing.name),
    );

    if existing.uses_bundles()
        && let Err(err) = crate::clusters::apply_bundle_java_override(
            state,
            cluster_id,
            search_for_java,
            false,
            Some(&progress),
        )
        .await
    {
        tracing::warn!(cluster_id, error = %err, "failed to apply bundle java override");
    }

    let cluster = if existing.stage == ClusterStage::Ready {
        existing
    } else {
        stage(LaunchStage::Downloading);
        match crate::clusters::prepare_cluster_locked(
            state,
            cluster_id,
            false,
            search_for_java,
            false,
            Some(&progress),
        )
        .await
        {
            Ok(cluster) => cluster,
            Err(err) => {
                progress.finish();
                stage(LaunchStage::Exited);
                return Err(err);
            }
        }
    };
    if cluster.uses_bundles()
        && let Err(err) = oneclient_content::bundles::install_cluster_bundles(
            cluster_id,
            state.bundles.as_ref(),
            Some(&progress),
            &state.services.content(),
            Some(Instant::now() + bundle_budget.unwrap_or(BUNDLE_APPLY_BUDGET)),
        )
        .await
    {
        tracing::warn!(cluster_id, error = %err, "failed to install bundle content");
    }
    let cluster = match crate::clusters::auto_update_loader(state, &cluster).await {
        Ok(updated) => updated.unwrap_or(cluster),
        Err(err) => {
            tracing::warn!(cluster_id, error = %err, "failed to update the loader");
            cluster
        }
    };

    let global = state.settings.read().global_game_settings.clone();
    let profile = state.clusters.resolve_settings(&global, &cluster).await?;

    let mc_version = oneclient_common::version::normalize_mc_version_input(&cluster.mc_version);

    let (version, updated, loader_version, version_info) = {
        let mut metadata = state.metadata.lock().await;

        let (version, _index, updated) =
            resolve_minecraft_version(&mut metadata, &state.services.mc(), &mc_version).await?;

        let loader_version = get_loader_version(
            &mut metadata,
            &state.services.mc(),
            &mc_version,
            cluster.mc_loader,
            cluster.mc_loader_version.as_deref(),
        )
        .await?;

        let version_info = download_version_info(
            &state.services.mc(),
            Some(&progress),
            &version,
            cluster.mc_loader,
            loader_version.as_ref(),
            false,
        )
        .await;

        (version, updated, loader_version, version_info)
    };

    let version_info = match version_info {
        Ok(info) => info,
        Err(err) => {
            progress.finish();
            stage(LaunchStage::Exited);
            return Err(err.into());
        }
    };

    let version_name = loader_version.as_ref().map_or_else(
        || version.id.clone(),
        |lv| format!("{}-{}", version.id, lv.id),
    );

    tracing::info!(
        cluster_id,
        mc_version = %version.id,
        loader = %cluster.mc_loader,
        loader_version = loader_version.as_ref().map(|lv| lv.id.as_str()).unwrap_or("none"),
        version_name = %version_name,
        libraries = version_info.libraries.len(),
        main_class = %version_info.main_class,
        "resolved launch metadata"
    );

    if let Some(dir) = crate::game::natives::natives_dir(&version_name) {
        state.games.set_natives(cluster_id, dir);
    }

    let native_ok = crate::game::natives::native_java_ok(&version_info);
    let required_major = version_info.java_version.as_ref().map(|v| v.major_version);
    let pinned = state
        .java
        .runtime_for_profile(profile.java_path.as_deref())
        .await?;
    let java = match pinned {
        Some(runtime) if !oneclient_java::wrong_arch_for_game(&runtime.os_arch, native_ok) => {
            runtime
        }
        pinned => {
            let major = match &pinned {
                Some(runtime) => {
                    tracing::info!(
                        cluster_id,
                        path = %runtime.absolute_path,
                        os_arch = %runtime.os_arch,
                        native_ok,
                        "pinned Java has the wrong architecture for this version"
                    );
                    runtime.major
                }
                None => required_major.ok_or(GameError::MissingJavaVersion)?,
            };

            state
                .java
                .prepare(major, native_ok, search_for_java, false, None)
                .await?
        }
    };
    let java = state
        .java
        .check_legacy_macos(java, required_major, native_ok, search_for_java)
        .await?;

    // Stats every library and the asset tree, the same work `plan_downloads`
    // already keeps off the runtime threads. `block_in_place` because
    // `VersionInfo` is not `Clone` and the sweep only reads it
    let missing =
        tokio::task::block_in_place(|| game_files_missing(&version_info, &java.os_arch, updated));
    match missing {
        Ok(true) => {
            tracing::info!(cluster_id, "missing game files; repairing");
            let _ = state
                .clusters
                .set_stage(cluster_id, ClusterStage::Repairing)
                .await;
            stage(LaunchStage::Downloading);
            let natives_mode =
                crate::game::natives::natives_mode(state, &version_name, Some(cluster_id));
            if let Err(err) = download_minecraft(
                &state.services.mc(),
                &progress,
                &version_info,
                &java.os_arch,
                updated,
                false,
                natives_mode,
            )
            .await
            {
                progress.finish();
                stage(LaunchStage::Exited);
                return Err(err.into());
            }
            let _ = state
                .clusters
                .set_stage(cluster_id, ClusterStage::Ready)
                .await;
        }
        Ok(false) => {}
        Err(err @ oneclient_mc::McError::NoNativesForPlatform { .. }) => {
            progress.finish();
            stage(LaunchStage::Exited);
            return Err(err.into());
        }
        Err(err) => tracing::warn!(cluster_id, error = %err, "repair check failed"),
    }

    progress.finish();

    stage(LaunchStage::Launching);

    let cwd = game_dir;
    polyio::create_dir_all(&cwd).await.ok();

    if let Err(err) = crate::game::write_allowed_symlinks(&cwd).await {
        tracing::warn!(cluster_id, error = %err, "failed to write allowed_symlinks.txt");
    }

    let custom_args = profile.launch_args.clone().unwrap_or_default();
    let loader_version_id = loader_version.as_ref().map(|lv| lv.id.as_str());

    let mods_in_cluster =
        crate::game::uses_cluster_mods_folder(cluster.mc_loader, loader_version_id, &custom_args);

    match crate::game::materialize_content(
        &state.services,
        &cluster,
        &cwd,
        mods_in_cluster,
        profile.copy_mod_files.unwrap_or(false),
    )
    .await
    {
        Ok(()) => {}
        Err(err @ crate::LauncherError::GameError(GameError::ModCopyFailed(_))) => {
            return Err(err);
        }
        Err(err) => {
            tracing::warn!(cluster_id, error = %err, "failed to materialize cluster content");
        }
    }

    if !dedicated {
        crate::game::link_cluster_logs(&cluster, &cwd).await;
    }

    if matches!(cluster.mc_loader, GameLoader::Fabric | GameLoader::Ornithe) {
        crate::game::fabric::drop_stale_remapped_jars(
            &cwd,
            &cluster.mc_version,
            version_info.libraries.iter().map(|lib| lib.name.as_str()),
        )
        .await;
    }

    let client_jar = paths::versions_dir()?
        .join(&version_name)
        .join(format!("{version_name}.jar"));
    let natives = paths::natives_dir()?.join(&version_name);
    polyio::create_dir_all(&natives).await?;
    let libraries = paths::libraries_dir()?;
    let assets = paths::assets_dir()?;

    let arg_map = version_info.arguments.clone().unwrap_or_default();

    let classpaths = arguments::classpaths(
        &libraries,
        &version_info.libraries,
        &client_jar,
        &java.os_arch,
        updated,
    )?;

    let mut jvm_args = arguments::java_arguments(
        arg_map.get(&ArgumentType::Jvm).map(Vec::as_slice),
        &natives,
        &libraries,
        &classpaths,
        &version_name,
        profile
            .mem_max
            .unwrap_or_else(oneclient_common::default_mem_max),
        jvm_args_with(profile.launch_args.as_deref(), extra_jvm_arg),
        &java.os_arch,
        java.major,
    )?;

    let mods_dir = paths::cluster_mods_dir(&cluster.folder_name)?;
    if let Some(arg) = crate::game::mods_folder_argument(
        cluster.mc_loader,
        loader_version_id,
        &custom_args,
        &mods_dir,
    ) {
        tracing::debug!(cluster_id, mods_dir = %mods_dir.display(), "redirecting fabric mods folder");
        jvm_args.push(arg);
    }

    let crash_dir = cluster.dir()?.join("crash-reports");
    polyio::create_dir_all(&crash_dir).await.ok();
    let error_file = crash_dir.join("hs_err_pid").display().to_string();
    jvm_args.insert(
        0,
        format!("-XX:ErrorFile={}%p.log", error_file.replace('%', "%%")),
    );

    oneclient_cluster::logs::censor_username(&account.username);

    let mut mc_args = arguments::minecraft_arguments(
        arg_map.get(&ArgumentType::Game).map(Vec::as_slice),
        version_info.minecraft_arguments.as_deref(),
        &account.access_token,
        &account.username,
        account.id,
        &version.id,
        &version_info.asset_index.id,
        &cwd,
        &assets,
        version.type_,
        profile.resolution.unwrap_or_default(),
        &java.os_arch,
    )?;
    arguments::append_profile_game_arguments(
        &mut mc_args,
        profile.force_fullscreen,
        profile.game_args.as_deref(),
    );

    drop(launch_slot);

    if let Some(reason) = run_hook(profile.hook_pre.as_deref(), &cwd).await {
        events
            .notify("Pre-launch command failed")
            .body(reason)
            .error()
            .send();
    }

    tracing::info!(
        cluster_id,
        java = %java.absolute_path,
        jvm_args = jvm_args.len(),
        mc_args = mc_args.len(),
        cwd = %cwd.display(),
        "spawning minecraft process"
    );
    tracing::debug!(cluster_id, ?jvm_args, main_class = %version_info.main_class, "jvm arguments");

    let (mut command, wrapper) = base_command(&profile, &java.absolute_path);

    if let Some(gpu) = profile.gpu().or(crate::game::gpu::DEFAULT) {
        crate::game::gpu::select(&mut command, &java.absolute_path, gpu).await;
    }

    apply_env(&mut command, &profile);

    command
        .args(jvm_args)
        .arg(&version_info.main_class)
        .args(mc_args)
        .current_dir(&cwd);

    // The folder name under metadata/java names the exact build we installed
    let java_name = paths::java_dir()
        .ok()
        .and_then(|dir| {
            Path::new(&java.absolute_path)
                .strip_prefix(dir)
                .ok()?
                .components()
                .next()
                .map(|c| c.as_os_str().to_string_lossy().into_owned())
        })
        .unwrap_or_else(|| format!("{} {}", java.vendor, java.version));
    let loader = match loader_version_id {
        Some(id) => format!("{} {id}", cluster.mc_loader),
        None => cluster.mc_loader.to_string(),
    };
    let header = format!(
        "OneClient {} ({})\nOS: {} {}\nGame Version: {}\nGame Loader: {loader}\nJava: {} ({java_name})\nPWD: {}\nCommand: {}\n\n",
        env!("CARGO_PKG_VERSION"),
        if cfg!(debug_assertions) { "debug" } else { "release" },
        sysinfo::System::kernel_long_version(),
        std::env::consts::ARCH,
        cluster.mc_version,
        java.major,
        shell_quote(&cwd.to_string_lossy()),
        command_line(command.as_std()),
    );

    let log_path = oneclient_cluster::logs::cluster_output_log(&cluster)?;
    if let Some(parent) = log_path.parent() {
        polyio::create_dir_all(parent).await.ok();
    }

    // A file not a pipe a pipe would die with the launcher and take the game's
    // next stdout write down with it
    // The cloned handle shares the file offset
    // so stdout and stderr interleave instead of overwriting
    let handles = match tokio::fs::File::create(&log_path).await {
        Ok(mut out) => {
            if let Err(err) = out.write_all(header.as_bytes()).await {
                tracing::warn!(cluster_id, error = %err, "failed to write the launch header");
            }
            match out.try_clone().await {
                Ok(err) => Ok((out.into_std().await, err.into_std().await)),
                Err(err) => Err(err),
            }
        }
        Err(err) => Err(err),
    };

    match handles {
        Ok((out, err)) => {
            command.stdout(Stdio::from(out)).stderr(Stdio::from(err));
        }
        Err(err) => {
            tracing::warn!(cluster_id, error = %err, "failed to open game log; discarding output");
            command.stdout(Stdio::null()).stderr(Stdio::null());
        }
    }
    command.stdin(Stdio::null());
    detach(&mut command);

    let mut child = command.spawn().map_err(|err| match &wrapper {
        Some(program) => GameError::wrapper_spawn(program, &err),
        None => GameError::Spawn(err.to_string()),
    })?;
    let pid = child.id();

    stage(LaunchStage::Running);
    state.games.set_pid(cluster_id, pid);
    state.discord.set_presence(Presence::Playing {
        cluster: cluster.name.clone(),
        mc_version: cluster.mc_version.clone(),
    });

    let recorder = SessionRecorder::start(
        state,
        cluster_id,
        profile
            .mem_max
            .unwrap_or_else(oneclient_common::default_mem_max),
        &java,
    )
    .await;

    // Pinned to the session row so that if the launcher exits first the next
    // start can tell whether the game is still playing
    if let (Some(recorder), Some(pid)) = (recorder.as_ref(), pid) {
        recorder
            .record_process(pid, crate::game::process_start_time(pid))
            .await;
    }

    let started_at = recorder
        .as_ref()
        .and_then(SessionRecorder::started_at)
        .unwrap_or_else(Utc::now);
    let crash_watch = CrashWatch::new();
    let tail = spawn_log_tail(
        cluster_id,
        log_path,
        events.clone(),
        recorder.clone(),
        crash_watch.clone(),
    );

    let (kill_tx, kill_rx) = tokio::sync::oneshot::channel::<()>();
    state.games.register_kill(cluster_id, kill_tx);

    let state = Arc::clone(state);
    let post_hook = profile.hook_post.clone();
    tokio::spawn(async move {
        let cluster = cluster;
        let (status, stopped) = tokio::select! {
            status = child.wait() => (status, false),
            _ = kill_rx => (stop_child(&mut child).await, true),
        };

        tail.stop().await;

        let outcome = match status {
            Ok(_) if stopped => Exit::Killed,
            Ok(status) => Exit::Observed {
                code: status.code().map(i64::from),
                success: status.success() || killed(&status),
                display: status.to_string(),
            },
            Err(err) => Exit::Failed(err.to_string()),
        };

        finalize_session(
            &state,
            &cluster,
            &cwd,
            dedicated,
            post_hook.as_deref(),
            recorder,
            SessionEnd {
                started_at,
                ended_at: Utc::now(),
                outcome,
                owns_slot: true,
                diagnosis: crash_watch.take(),
                watch: Some(crash_watch),
            },
        )
        .await;
    });

    Ok(LaunchedGame { cluster_id, pid })
}

async fn running_cluster_name(state: &Arc<LauncherState>, cluster_id: i64) -> String {
    state
        .clusters
        .get(cluster_id)
        .await
        .map_or_else(|_| format!("Cluster {cluster_id}"), |cluster| cluster.name)
}

/// Cuts the game loose from the launcher's process group/console so signals
/// aimed at the launcher (Ctrl-C console close) don't reach the game
fn detach(command: &mut Command) {
    #[cfg(unix)]
    {
        use std::os::unix::process::CommandExt;
        command.as_std_mut().process_group(0);
    }

    #[cfg(windows)]
    {
        use std::os::windows::process::CommandExt;
        const DETACHED_PROCESS: u32 = 0x0000_0008;
        const CREATE_NEW_PROCESS_GROUP: u32 = 0x0000_0200;
        command
            .as_std_mut()
            .creation_flags(DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP);
    }
}

#[cfg(unix)]
fn killed(status: &std::process::ExitStatus) -> bool {
    use std::os::unix::process::ExitStatusExt;
    const SIGKILL: i32 = 9;
    const JVM_SIGTERM_EXIT: i32 = 143;
    status.signal() == Some(SIGKILL) || status.code() == Some(JVM_SIGTERM_EXIT)
}

#[cfg(not(unix))]
fn killed(_status: &std::process::ExitStatus) -> bool {
    false
}

fn counts_as_crash(outcome: &Exit, diagnosis: Option<&CrashDiagnosis>, reported: bool) -> bool {
    let broken = diagnosis.is_some_and(CrashDiagnosis::leaves_game_broken);

    match outcome {
        Exit::Observed { success, .. } => {
            !success || broken || diagnosis.is_some_and(CrashDiagnosis::is_fatal)
        }
        Exit::Failed(_) => true,
        Exit::Inferred => diagnosis.is_some() || reported,
        Exit::Killed => broken,
    }
}

/// What the game gets to save and shut down in before it is killed outright
///
/// Short on purpose: someone reaching for the launcher's stop button usually
/// has a game that is already stuck, and should not wait long to find out
const GRACEFUL_STOP_TIMEOUT: Duration = Duration::from_secs(7);

/// Asks the game to close before killing it
///
/// `start_kill` is SIGKILL, so the game gets no chance to save. A terminate
/// runs its shutdown hooks, and the kill is only the fallback for a game that
/// will not go.
async fn stop_child(
    child: &mut tokio::process::Child,
) -> std::io::Result<std::process::ExitStatus> {
    if let Some(pid) = child.id()
        && crate::game::kill_process(pid)
    {
        match tokio::time::timeout(GRACEFUL_STOP_TIMEOUT, child.wait()).await {
            Ok(status) => return status,
            Err(_elapsed) => tracing::warn!(pid, "game ignored the request to close; killing it"),
        }
    }

    let _ = child.start_kill();
    child.wait().await
}

pub(crate) enum Exit {
    Observed {
        code: Option<i64>,
        success: bool,
        display: String,
    },
    Failed(String),
    Inferred,
    Killed,
}

pub(crate) struct SessionEnd {
    pub started_at: DateTime<Utc>,
    pub ended_at: DateTime<Utc>,
    pub outcome: Exit,
    pub owns_slot: bool,
    pub diagnosis: Option<CrashDiagnosis>,
    pub watch: Option<CrashWatch>,
}

/// Shared by the live exit path and by recovery of sessions that outlived the
/// launcher
pub(crate) async fn finalize_session(
    state: &Arc<LauncherState>,
    cluster: &Cluster,
    cwd: &Path,
    dedicated: bool,
    post_hook: Option<&str>,
    recorder: Option<SessionRecorder>,
    end: SessionEnd,
) {
    let cluster_id = cluster.id;
    let played = (end.ended_at - end.started_at).to_std().unwrap_or_default();

    if end.owns_slot {
        state.games.remove(cluster_id);
        state
            .services
            .events
            .game_stage(cluster_id, LaunchStage::Exited);

        if state.games.running_ids().is_empty() {
            state.discord.set_presence(Presence::Idle);
        }
    }

    if played > Duration::from_secs(1) {
        let _ = state.clusters.add_playtime(cluster_id, played).await;
    }

    if let Some(recorder) = recorder {
        let code = match &end.outcome {
            Exit::Observed { code, .. } => *code,
            Exit::Failed(_) | Exit::Inferred | Exit::Killed => None,
        };
        recorder.finish_at(&end.ended_at.to_rfc3339(), code).await;
    }

    if let Some(reason) = run_hook(post_hook, cwd).await {
        state
            .services
            .events
            .notify("Post-exit command failed")
            .body(reason)
            .error()
            .send();
    }

    if dedicated {
        // The folder stays materialized so it remains a real Minecraft directory
        // for external tools adopting drop-ins now keeps the UI right on close
        crate::game::import_manual_content(&state.services, cluster, cwd).await;
    } else {
        if let Err(err) = crate::game::dematerialize_content(&state.services, cluster, cwd).await {
            tracing::warn!(cluster_id, error = %err, "failed to clear shared content on exit");
        }
        crate::game::unlink_cluster_logs(cwd).await;
    }

    let name = &cluster.name;
    let reported = end.watch.as_ref().is_some_and(CrashWatch::reported_crash);
    let crashed = counts_as_crash(&end.outcome, end.diagnosis.as_ref(), reported);

    crate::bisect::record_bisect_exit(
        state,
        cluster_id,
        match end.outcome {
            Exit::Failed(_) | Exit::Inferred => crate::bisect::GameExit::Unknown,
            _ if crashed => crate::bisect::GameExit::Crashed,
            Exit::Observed { .. } | Exit::Killed => crate::bisect::GameExit::Clean,
        },
        end.watch
            .as_ref()
            .map(CrashWatch::take_missing)
            .unwrap_or_default(),
        cwd,
        std::time::SystemTime::from(end.started_at),
    )
    .await;

    let display = match &end.outcome {
        Exit::Observed {
            success: false,
            display,
            ..
        } => display.clone(),
        Exit::Failed(err) => err.clone(),
        Exit::Observed { .. } | Exit::Inferred | Exit::Killed => String::new(),
    };

    match &end.outcome {
        Exit::Observed { success: true, .. } => {}
        Exit::Observed { .. } => state
            .services
            .events
            .notify("Game crashed")
            .body(format!("{name} exited with {display}"))
            .error()
            .send(),
        Exit::Failed(err) => state
            .services
            .events
            .notify("Game error")
            .body(format!("{name}: {err}"))
            .error()
            .send(),
        Exit::Killed => {}
        Exit::Inferred => {}
    }

    if crashed {
        report_crash(state, cluster, cwd, &display, played, &end).await;
    }
}

async fn report_crash(
    state: &Arc<LauncherState>,
    cluster: &Cluster,
    cwd: &Path,
    display: &str,
    played: Duration,
    end: &SessionEnd,
) {
    let watch = end.watch.as_ref();
    let diagnosis = end.diagnosis.as_ref();

    let reported = watch.is_some_and(CrashWatch::reported_crash);
    let suspects = watch.map(CrashWatch::suspects).unwrap_or_default();
    let excerpt = watch.map(CrashWatch::excerpt).unwrap_or_default();
    let document = watch.map(CrashWatch::document).unwrap_or_default();
    let fixes = crate::game::crashdata::fixes_for(&document);

    if diagnosis.is_none()
        && !reported
        && suspects.is_empty()
        && !crate::game::crashdata::has_solution(&fixes)
    {
        tracing::debug!(
            cluster_id = cluster.id,
            suggestions = fixes.len(),
            "no recognised cause, leaving it to the toast"
        );
        return;
    }

    let mod_issues = match diagnosis {
        Some(diagnosis) => crash_mod_issues(&state.services, cluster.id, diagnosis).await,
        None => Vec::new(),
    };

    state
        .services
        .events
        .game_crashed(oneclient_events::GameCrash {
            cluster_id: cluster.id,
            cluster_name: cluster.name.clone(),
            title: diagnosis.map_or_else(
                || format!("{} crashed", cluster.name),
                CrashDiagnosis::title,
            ),
            exit: display.to_string(),
            played_secs: played.as_secs(),
            cause: diagnosis.map(CrashDiagnosis::body),
            remedy: diagnosis
                .and_then(CrashDiagnosis::remedy)
                .or_else(|| (!suspects.is_empty()).then_some(CrashRemedy::OpenMods)),
            suspects,
            fixes,
            excerpt,
            game_dir: Some(cwd.to_string_lossy().to_string()),
            mod_issues,
        });
}

pub async fn crash_mod_issues(
    services: &LauncherServices,
    cluster_id: i64,
    diagnosis: &CrashDiagnosis,
) -> Vec<CrashModIssue> {
    let mut mod_issues = diagnosis.mod_issues();
    if mod_issues.is_empty() {
        return mod_issues;
    }

    let jars: Vec<InstalledJar> = cluster_mods(services, cluster_id)
        .await
        .into_iter()
        .map(|jar| InstalledJar {
            hash: jar.hash,
            enabled: jar.enabled,
            name: jar.name,
            id: None,
            version: jar.version,
        })
        .collect();

    for jar in &jars {
        attach_jar(&mut mod_issues, jar);
    }

    for jar in &jars {
        if !has_unmatched(&mod_issues) {
            return mod_issues;
        }

        if let Some(found) = jar_mod_id(services, &jar.hash).await {
            attach_jar(
                &mut mod_issues,
                &InstalledJar {
                    id: Some(found.id),
                    version: found.version.or_else(|| jar.version.clone()),
                    ..jar.clone()
                },
            );
        }
    }

    for jar in jars.iter().filter(|jar| !jar.enabled) {
        if !has_unmatched_missing(&mod_issues) {
            break;
        }

        for found in jar_bundled_mod_ids(services, &jar.hash).await {
            attach_bundled(
                &mut mod_issues,
                jar,
                &InstalledJar {
                    hash: jar.hash.clone(),
                    enabled: jar.enabled,
                    name: None,
                    id: Some(found.id),
                    version: found.version,
                },
            );
        }
    }

    mod_issues
}

#[tracing::instrument(skip(state), level = "debug")]
pub async fn repair_cluster(state: &Arc<LauncherState>, cluster_id: i64) {
    match crate::verify::verify_cluster_files(state, cluster_id).await {
        Ok(report) => {
            state
                .services
                .events
                .notify("Repair complete")
                .body(report.summary())
                .send();
        }
        Err(err) => {
            tracing::error!(cluster_id, "post-crash repair failed: {err:#}");
            state
                .services
                .events
                .notify("Repair failed")
                .body(err.to_string())
                .error()
                .send();
        }
    }
}

fn base_command(profile: &GameSettingsProfile, java_path: &str) -> (Command, Option<String>) {
    let wrapper = profile
        .hook_wrapper
        .as_deref()
        .map(str::trim)
        .filter(|hook| !hook.is_empty());
    #[cfg(target_os = "linux")]
    let gamemode = gamemode_wrapper(profile, wrapper);
    #[cfg(target_os = "linux")]
    let wrapper = gamemode.as_deref().or(wrapper);
    let Some(wrapper) = wrapper else {
        return (Command::new(java_path), None);
    };

    let mut split = wrapper.split_whitespace();
    let Some(program) = split.next() else {
        return (Command::new(java_path), None);
    };

    let mut command = Command::new(program);
    command.args(split);
    command.arg(java_path);
    (command, Some(program.to_string()))
}

#[cfg(target_os = "linux")]
fn gamemode_wrapper(profile: &GameSettingsProfile, wrapper: Option<&str>) -> Option<String> {
    let enabled = profile
        .os_extra
        .as_ref()
        .is_none_or(|extra| extra.enable_gamemode != Some(false));
    if !enabled || wrapper.is_some_and(|w| w.split_whitespace().any(|p| p.ends_with("gamemoderun")))
    {
        return None;
    }
    let path = std::env::var_os("PATH")?;
    std::env::split_paths(&path)
        .any(|dir| dir.join("gamemoderun").is_file())
        .then_some(())?;
    Some(match wrapper {
        Some(wrapper) => format!("gamemoderun {wrapper}"),
        None => "gamemoderun".to_string(),
    })
}

fn command_line(command: &std::process::Command) -> String {
    let mut out = String::new();
    for (key, value) in command.get_envs() {
        let (key, Some(value)) = (key.to_string_lossy(), value) else {
            continue;
        };
        let value = shell_quote(&value.to_string_lossy());
        #[cfg(not(windows))]
        let _ = write!(out, "{key}={value} ");
        #[cfg(windows)]
        let _ = write!(out, "$env:{key} = {value}; ");
    }

    #[cfg(windows)]
    {
        out += "& ";
    }
    out += &shell_quote(&command.get_program().to_string_lossy());

    for arg in command.get_args() {
        out += " ";
        out += &shell_quote(&oneclient_cluster::logs::censor(&arg.to_string_lossy()));
    }

    out
}

#[cfg(not(windows))]
fn shell_quote(arg: &str) -> String {
    let plain = !arg.is_empty()
        && arg
            .bytes()
            .all(|b| b.is_ascii_alphanumeric() || b"_-./=:,+@%".contains(&b));
    if plain {
        arg.to_string()
    } else {
        format!("'{}'", arg.replace('\'', r"'\''"))
    }
}

#[cfg(windows)]
fn shell_quote(arg: &str) -> String {
    format!("'{}'", arg.replace('\'', "''"))
}

fn apply_env(command: &mut Command, profile: &GameSettingsProfile) {
    command.env_remove("_JAVA_OPTIONS");
    oneclient_common::process::strip_appimage_env(command.as_std_mut());
    #[cfg(all(unix, not(target_os = "macos")))]
    command.env("LC_ALL", "C.UTF-8");

    if let Some(env) = &profile.launch_env {
        for pair in env.split_whitespace() {
            if let Some((key, value)) = pair.split_once('=') {
                command.env(key, value);
            }
        }
    }
}

#[tracing::instrument(skip(cwd), fields(hook), level = "debug")]
async fn run_hook(hook: Option<&str>, cwd: &Path) -> Option<String> {
    let hook = hook.map(str::trim).filter(|h| !h.is_empty())?;

    #[cfg(windows)]
    let mut command = {
        let mut c = Command::new("cmd");
        c.args(["/C", hook]);
        c
    };
    #[cfg(not(windows))]
    let mut command = {
        let mut c = Command::new("sh");
        c.args(["-c", hook]);
        c
    };

    command.current_dir(cwd);
    command.stderr(Stdio::piped());
    command.stdin(Stdio::null());
    oneclient_common::process::no_window(command.as_std_mut());
    oneclient_common::process::strip_appimage_env(command.as_std_mut());

    let mut child = match command.spawn() {
        Ok(child) => child,
        Err(err) => {
            tracing::warn!("hook '{hook}' could not start: {err}");
            return Some(format!("The command shell could not be started: {err}"));
        }
    };

    let collector = child.stderr.take().map(|mut pipe| {
        tokio::spawn(async move {
            let mut buf = Vec::new();
            let _ = pipe.read_to_end(&mut buf).await;
            buf
        })
    });

    let status = match child.wait().await {
        Ok(status) => status,
        Err(err) => {
            if let Some(collector) = collector {
                collector.abort();
            }
            tracing::warn!("hook '{hook}' could not be waited on: {err}");
            return Some(format!("The command could not be waited on: {err}"));
        }
    };

    if status.success() {
        if let Some(collector) = collector {
            collector.abort();
        }
        return None;
    }

    let detail = match collector {
        Some(mut collector) => {
            match tokio::time::timeout(Duration::from_millis(200), &mut collector).await {
                Ok(Ok(buf)) => stderr_detail(&buf),
                _ => {
                    collector.abort();
                    None
                }
            }
        }
        None => None,
    };

    let message = match (detail, status.code()) {
        (Some(detail), _) => detail,
        (None, Some(code)) => format!("The command exited with code {code}"),
        (None, None) => "The command was stopped before it finished".to_string(),
    };

    tracing::warn!("hook '{hook}' failed: {message}");
    Some(message)
}

fn stderr_detail(bytes: &[u8]) -> Option<String> {
    let text = String::from_utf8_lossy(bytes);
    let line = text
        .lines()
        .rev()
        .map(str::trim)
        .find(|line| !line.is_empty())?;

    const MAX: usize = 300;
    if line.chars().count() <= MAX {
        return Some(line.to_string());
    }

    let mut clipped: String = line.chars().take(MAX).collect();
    clipped.push('…');
    Some(clipped)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn clean() -> Exit {
        Exit::Observed {
            code: Some(0),
            success: true,
            display: "exit code: 0".to_string(),
        }
    }

    #[test]
    fn a_clean_exit_after_running_out_of_memory_is_a_crash() {
        assert!(counts_as_crash(
            &clean(),
            Some(&CrashDiagnosis::OutOfMemory),
            false
        ));
    }

    #[test]
    fn stopping_a_game_that_ran_out_of_memory_is_a_crash() {
        assert!(counts_as_crash(
            &Exit::Killed,
            Some(&CrashDiagnosis::OutOfMemory),
            false
        ));
        assert!(!counts_as_crash(&Exit::Killed, None, false));
    }

    #[test]
    fn a_clean_exit_with_nothing_wrong_is_not_a_crash() {
        assert!(!counts_as_crash(&clean(), None, false));
        assert!(!counts_as_crash(
            &clean(),
            Some(&CrashDiagnosis::ModLinkage),
            false
        ));
    }

    #[test]
    fn a_failing_exit_code_is_always_a_crash() {
        let failed = Exit::Observed {
            code: Some(1),
            success: false,
            display: "exit code: 1".to_string(),
        };
        assert!(counts_as_crash(&failed, None, false));
    }

    #[test]
    fn a_load_failure_counts_on_a_clean_exit_however_long_loading_took() {
        let load_failure = CrashDiagnosis::ModLoadFailure {
            problems: Vec::new(),
        };
        assert!(counts_as_crash(&clean(), Some(&load_failure), false));
    }

    #[test]
    fn an_unobserved_exit_counts_when_the_game_wrote_a_crash_report() {
        assert!(counts_as_crash(&Exit::Inferred, None, true));
        assert!(!counts_as_crash(&Exit::Inferred, None, false));
    }
}

#[cfg(test)]
mod jvm_arg_tests {
    use super::jvm_args_with;

    #[test]
    fn the_extra_argument_lands_after_the_profile() {
        assert_eq!(jvm_args_with(Some("-Xss2m"), Some("-Da=1")), "-Xss2m -Da=1");
        assert_eq!(jvm_args_with(None, Some("-Da=1")), "-Da=1");
        assert_eq!(jvm_args_with(Some("-Xss2m"), None), "-Xss2m");
        assert_eq!(jvm_args_with(None, None), "");
    }
}
