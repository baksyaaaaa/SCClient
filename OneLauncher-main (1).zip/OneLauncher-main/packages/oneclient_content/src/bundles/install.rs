use std::time::Instant;

use chrono::DateTime;
use futures_util::StreamExt;
use oneclient_db::dao::applied_migration as migration_dao;
use oneclient_db::dao::artifact as artifact_dao;
use oneclient_db::dao::cluster_bisect as bisect_dao;
use oneclient_db::dao::cluster_bundle as bundle_dao;
use oneclient_db::models::{ClusterArtifactRow, ClusterRow};
use oneclient_db::models::OverrideType;

use crate::bundles::error::BundleError;
use crate::bundles::manager::BundlesManager;
use crate::bundles::overrides;
use crate::bundles::types::{BundleArchive, BundleFile, BundleFileKind, BundleManifest};
use crate::bundles::updates::prefetch_until;
use crate::ctx::ContentCtx;
use crate::error::ContentError;
use crate::error::ContentResult;
use crate::packages::store::{
    LiveSync, PackageStore, artifact_absolute_path, drop_unmanaged_mod, evict_if_unused,
    try_unlink_materialized,
};
use crate::packages::types::{ExternalFile, LinkedArtifactInfo, VersionDetail};
use oneclient_common::domain::{ContentType, GameLoader, ProviderId};
use oneclient_events::{GroupedProgressChild, GroupedProgressSession, TaskCategory, TaskPhase};

fn is_base62(s: &str) -> bool {
    !s.is_empty() && s.chars().all(|c| c.is_ascii_alphanumeric())
}

pub(crate) fn takes_bundle(
    archive: &BundleArchive,
    accepted: &std::collections::HashSet<String>,
) -> bool {
    takes_manifest(&archive.manifest, accepted)
}

fn takes_manifest(manifest: &BundleManifest, accepted: &std::collections::HashSet<String>) -> bool {
    manifest.enabled || accepted.contains(&manifest.name)
}

pub fn wanted_bundle_files<'a>(
    manifests: impl IntoIterator<Item = &'a BundleManifest>,
    accepted: &std::collections::HashSet<String>,
    override_for: impl Fn(&str, &str) -> Option<OverrideType>,
) -> Vec<&'a BundleFile> {
    manifests
        .into_iter()
        .flat_map(|manifest| {
            let taken = takes_manifest(manifest, accepted);
            let override_for = &override_for;
            manifest.files.iter().filter(move |file| {
                let user_override = override_for(&manifest.name, &file.kind.package_id());
                wants_file(file, user_override, taken)
            })
        })
        .collect()
}

fn wants_file(file: &BundleFile, user_override: Option<OverrideType>, taken: bool) -> bool {
    if taken {
        effective_enabled(file, user_override)
    } else {
        user_override == Some(OverrideType::Enabled)
    }
}

pub(crate) async fn accepted_bundles(
    cluster_id: i64,
    ctx: &ContentCtx,
) -> ContentResult<std::collections::HashSet<String>> {
    Ok(bundle_dao::list_bundle_choices(&ctx.db, cluster_id)
        .await?
        .into_iter()
        .filter_map(|(name, accepted)| accepted.then_some(name))
        .collect())
}

pub async fn taken_bundle_names(
    cluster_id: i64,
    archives: &[BundleArchive],
    ctx: &ContentCtx,
) -> ContentResult<std::collections::HashSet<String>> {
    let accepted = accepted_bundles(cluster_id, ctx).await?;
    Ok(archives
        .iter()
        .filter(|archive| takes_bundle(archive, &accepted))
        .map(|archive| archive.manifest.name.clone())
        .collect())
}

pub(crate) async fn overrides_outside_declined(
    cluster_id: i64,
    archives: &[BundleArchive],
    mut overrides: Vec<oneclient_db::models::ClusterBundleOverrideRow>,
    ctx: &ContentCtx,
) -> ContentResult<Vec<oneclient_db::models::ClusterBundleOverrideRow>> {
    let taken = taken_bundle_names(cluster_id, archives, ctx).await?;
    let declined: std::collections::HashSet<&str> = archives
        .iter()
        .map(|archive| archive.manifest.name.as_str())
        .filter(|name| !taken.contains(*name))
        .collect();
    let tracked: std::collections::HashSet<(String, String)> =
        bundle_dao::list_bundle_tracked(&ctx.db, cluster_id)
            .await?
            .into_iter()
            .filter_map(|row| Some((row.bundle_name?, row.package_id?)))
            .collect();

    overrides.retain(|o| survives_decline(o, &declined, &tracked));
    Ok(overrides)
}

fn survives_decline(
    o: &oneclient_db::models::ClusterBundleOverrideRow,
    declined: &std::collections::HashSet<&str>,
    tracked: &std::collections::HashSet<(String, String)>,
) -> bool {
    if !declined.contains(o.bundle_name.as_str()) {
        return true;
    }

    OverrideType::parse(&o.override_type) == Some(OverrideType::Disabled)
        && tracked.contains(&(o.bundle_name.clone(), o.package_id.clone()))
}

#[tracing::instrument(level = "debug", skip(bundles, ctx))]
pub async fn pending_bundle_choices(
    cluster_id: i64,
    bundles: &BundlesManager,
    ctx: &ContentCtx,
) -> ContentResult<Vec<BundleArchive>> {
    let Some(cluster) = bundle_cluster(cluster_id, ctx).await? else {
        return Ok(Vec::new());
    };
    let loader = GameLoader::from_repr(cluster.mc_loader as u8).unwrap_or(GameLoader::Fabric);
    let decided: std::collections::HashSet<String> =
        bundle_dao::list_bundle_choices(&ctx.db, cluster_id)
            .await?
            .into_iter()
            .map(|(name, _)| name)
            .collect();
    Ok(bundles
        .archives_for(ctx, &cluster.mc_version, loader)
        .await?
        .into_iter()
        .filter(|archive| {
            !archive.manifest.enabled
                && !archive.bundle.hidden
                && !decided.contains(&archive.manifest.name)
        })
        .collect())
}

#[tracing::instrument(level = "debug", skip(ctx))]
pub async fn set_bundle_choices(
    cluster_id: i64,
    choices: &[(String, bool)],
    ctx: &ContentCtx,
) -> ContentResult<()> {
    bundle_dao::save_bundle_choices(&ctx.db, cluster_id, choices).await?;

    let cluster = PackageStore::get_cluster(cluster_id, ctx).await?;
    let wants = crate::modpacks::imported_wants(&cluster).await;
    for row in bundle_dao::list_bundle_tracked(&ctx.db, cluster_id).await? {
        let declined = row.bundle_name.as_ref().is_some_and(|name| {
            choices
                .iter()
                .any(|(choice, accepted)| choice == name && !accepted)
        });
        if declined
            && !crate::modpacks::hand_to_wanting_pack(cluster_id, &row.hash, &wants, ctx).await?
        {
            detach_artifact(cluster_id, &row.hash, ctx).await?;
        }
    }
    Ok(())
}

const UNASKED_SKYBLOCK: &str = "decline_unasked_skyblock";

#[tracing::instrument(level = "debug", skip_all, fields(cluster_id = cluster.id))]
pub(crate) async fn decline_unasked_skyblock(
    cluster: &ClusterRow,
    archives: &[BundleArchive],
    ctx: &ContentCtx,
) -> ContentResult<()> {
    let marker = format!("{UNASKED_SKYBLOCK}:{}", cluster.id);
    if migration_dao::is_applied(&ctx.db, &marker).await? {
        return Ok(());
    }

    let unasked = cluster.mc_version == "26.3"
        && bundle_dao::predates_bundle_choices(&ctx.db, cluster.id).await?;
    if unasked {
        let declined: Vec<(String, bool)> = archives
            .iter()
            .filter(|archive| {
                !archive.manifest.enabled
                    && archive
                        .manifest
                        .category
                        .trim()
                        .eq_ignore_ascii_case("SkyBlock")
            })
            .map(|archive| (archive.manifest.name.clone(), false))
            .collect();
        set_bundle_choices(cluster.id, &declined, ctx).await?;
    }

    migration_dao::mark_applied(&ctx.db, &marker).await?;
    Ok(())
}

#[tracing::instrument(level = "debug", skip(ctx))]
pub async fn inherit_bundle_choices(
    source_cluster_id: i64,
    target_cluster_id: i64,
    ctx: &ContentCtx,
) -> ContentResult<()> {
    bundle_dao::copy_bundle_choices(&ctx.db, source_cluster_id, target_cluster_id).await?;
    Ok(())
}

pub fn effective_enabled(file: &BundleFile, user_override: Option<OverrideType>) -> bool {
    match user_override {
        Some(OverrideType::Removed | OverrideType::Disabled) => false,
        Some(OverrideType::Enabled) => true,
        None => file.enabled,
    }
}

pub(crate) fn find_override(
    overrides: &[oneclient_db::models::ClusterBundleOverrideRow],
    bundle_name: &str,
    package_id: &str,
) -> Option<OverrideType> {
    overrides
        .iter()
        .find(|o| o.bundle_name == bundle_name && o.package_id == package_id)
        .and_then(|o| OverrideType::parse(&o.override_type))
}

/// Searches all bundles
/// a package's `bundle_name` is rewritten on every install so a choice filed
/// under its old bundle still counts
/// `Removed` outranks `Disabled`
/// `Enabled` never suppresses
pub(crate) fn find_user_suppression(
    overrides: &[oneclient_db::models::ClusterBundleOverrideRow],
    package_id: &str,
) -> Option<OverrideType> {
    let mut found = None;

    for row in overrides.iter().filter(|o| o.package_id == package_id) {
        match OverrideType::parse(&row.override_type) {
            Some(OverrideType::Removed) => return Some(OverrideType::Removed),
            Some(OverrideType::Disabled) => found = Some(OverrideType::Disabled),
            Some(OverrideType::Enabled) | None => {}
        }
    }

    found
}

/// Clears across all bundles
/// a row left behind under another bundle would keep answering "off" forever
async fn clear_suppressing_overrides(
    cluster_id: i64,
    package_id: &str,
    ctx: &ContentCtx,
) -> ContentResult<()> {
    bundle_dao::clear_suppressing_overrides(&ctx.db, cluster_id, package_id).await?;
    Ok(())
}

async fn opted_in_bundles(
    cluster_id: i64,
    package_id: &str,
    ctx: &ContentCtx,
) -> ContentResult<Vec<String>> {
    Ok(bundle_dao::list_overrides(&ctx.db, cluster_id)
        .await?
        .into_iter()
        .filter(|row| {
            row.package_id == package_id
                && OverrideType::parse(&row.override_type) == Some(OverrideType::Enabled)
        })
        .map(|row| row.bundle_name)
        .collect())
}

async fn withdraw_opt_ins(
    cluster_id: i64,
    package_id: &str,
    bundles: Vec<String>,
    ctx: &ContentCtx,
) -> ContentResult<()> {
    for name in bundles {
        bundle_dao::save_override(
            &ctx.db,
            cluster_id,
            &name,
            package_id,
            OverrideType::Removed,
        )
        .await?;
    }
    Ok(())
}

async fn restore_opt_ins(cluster_id: i64, package_id: &str, ctx: &ContentCtx) -> ContentResult<()> {
    let removed: Vec<String> = bundle_dao::list_overrides(&ctx.db, cluster_id)
        .await?
        .into_iter()
        .filter(|row| {
            row.package_id == package_id
                && OverrideType::parse(&row.override_type) == Some(OverrideType::Removed)
        })
        .map(|row| row.bundle_name)
        .collect();
    clear_suppressing_overrides(cluster_id, package_id, ctx).await?;
    for name in removed {
        bundle_dao::save_override(
            &ctx.db,
            cluster_id,
            &name,
            package_id,
            OverrideType::Enabled,
        )
        .await?;
    }
    Ok(())
}

#[tracing::instrument(level = "debug", skip(file, child, ctx), fields(package = %file.display_name()))]
pub async fn install_package_from_bundle(
    file: &BundleFile,
    cluster_id: i64,
    bundle_name: &str,
    skip_compatibility: bool,
    child: Option<&GroupedProgressChild>,
    ctx: &ContentCtx,
) -> ContentResult<String> {
    let cluster = PackageStore::get_cluster(cluster_id, ctx).await?;
    let hash = match &file.kind {
        BundleFileKind::Managed {
            provider,
            project_id,
            version_id,
            sha1,
        } => {
            let project = crate::packages::cached_project_detail(
                ctx,
                *provider,
                project_id,
                file.content_type(),
            )
            .await;
            let version =
                resolve_bundle_version(*provider, project_id, version_id, sha1, ctx).await?;

            let (artifact, _) = PackageStore::install_to_cluster(
                *provider,
                &project,
                &version,
                cluster_id,
                skip_compatibility,
                false,
                child,
                ctx,
            )
            .await?;
            artifact.hash
        }
        BundleFileKind::External { file: ext, .. } => {
            install_external(ext, &cluster, skip_compatibility, child, ctx).await?
        }
    };

    bundle_dao::track_bundle_artifact(
        &ctx.db,
        cluster_id,
        &hash,
        bundle_name,
        &file.kind.bundle_version_id(),
        &file.kind.package_id(),
    )
    .await?;

    Ok(hash)
}

async fn resolve_bundle_version(
    provider: ProviderId,
    project_id: &str,
    version_id: &str,
    sha1: &str,
    ctx: &ContentCtx,
) -> ContentResult<VersionDetail> {
    if is_base62(version_id) {
        return crate::packages::get_version_cached(ctx, provider, project_id, version_id).await;
    }
    if let Ok(Some(release)) =
        artifact_dao::get_release_by_hash(&ctx.db, &polyio::normalize_hash(sha1)).await
        && release.provider == provider as i64
        && release.project_id == project_id
        && let Ok(version) =
            crate::packages::get_version_cached(ctx, provider, project_id, &release.version_id)
                .await
        && (version
            .primary_file()
            .is_some_and(|file| !file.url.is_empty())
            || cached_copy_intact(&release.hash, ctx).await)
    {
        return Ok(version);
    }
    if let Ok(Some((_, version))) = ctx.providers.lookup_version(sha1, ctx).await {
        return Ok(version);
    }
    crate::packages::get_version_cached(ctx, provider, project_id, version_id).await
}

async fn cached_copy_intact(hash: &str, ctx: &ContentCtx) -> bool {
    let Ok(Some(artifact)) = artifact_dao::get_artifact_by_hash(&ctx.db, hash).await else {
        return false;
    };
    let Ok(path) = artifact_absolute_path(&artifact.path) else {
        return false;
    };
    oneclient_net::matches_on_disk(&path, hash).await
}

/// Puts the file in the package cache without linking it to any cluster
/// `install_package_from_bundle` then finds it there and needs no network
#[tracing::instrument(level = "debug", skip_all, fields(package_id = %file.kind.package_id()))]
pub(crate) async fn prefetch_bundle_file(
    file: &BundleFile,
    child: Option<&GroupedProgressChild>,
    ctx: &ContentCtx,
) -> ContentResult<()> {
    match &file.kind {
        BundleFileKind::Managed {
            provider,
            project_id,
            version_id,
            sha1,
        } => {
            let project = crate::packages::cached_project_detail(
                ctx,
                *provider,
                project_id,
                file.content_type(),
            )
            .await;
            let version =
                resolve_bundle_version(*provider, project_id, version_id, sha1, ctx).await?;
            PackageStore::download_and_cache(*provider, &project, &version, false, child, ctx)
                .await?;
        }
        BundleFileKind::External { file: ext, .. } => {
            crate::packages::store::download_external(ext, false, child, ctx).await?;
        }
    }
    Ok(())
}

#[tracing::instrument(level = "debug", skip(ext, cluster, child, ctx), fields(file = %ext.name))]
pub(crate) async fn install_external(
    ext: &ExternalFile,
    cluster: &ClusterRow,
    skip_compatibility: bool,
    child: Option<&GroupedProgressChild>,
    ctx: &ContentCtx,
) -> ContentResult<String> {
    let artifact = crate::packages::store::download_external(ext, false, child, ctx).await?;
    PackageStore::link_artifact(&artifact, cluster, Some(&ext.name), ctx).await?;

    let _ = skip_compatibility;
    Ok(artifact.hash)
}

#[tracing::instrument(level = "debug", skip(archive, ctx), fields(bundle = %archive.manifest.name))]
pub async fn extract_bundle_overrides_for_cluster(
    archive: &BundleArchive,
    cluster_id: i64,
    ctx: &ContentCtx,
) -> ContentResult<()> {
    let cluster = PackageStore::get_cluster(cluster_id, ctx).await?;
    overrides::sync_bundle_overrides(&archive.bundle.path, &archive.manifest.name, &cluster, None)
        .await?;
    Ok(())
}

#[tracing::instrument(skip(bundles, ctx))]
pub async fn install_bundle(
    cluster_id: i64,
    bundle_name: &str,
    skip_compatibility: bool,
    bundles: &BundlesManager,
    ctx: &ContentCtx,
) -> ContentResult<Vec<String>> {
    let cluster = PackageStore::get_cluster(cluster_id, ctx).await?;
    if !cluster.uses_bundles() {
        return Ok(Vec::new());
    }
    let loader = GameLoader::from_repr(cluster.mc_loader as u8).ok_or_else(|| {
        ContentError::InvalidData {
            reason: format!("unknown loader {}", cluster.mc_loader),
        }
    })?;

    let archives = bundles
        .archives_for(ctx, &cluster.mc_version, loader)
        .await?;
    let archive = archives
        .iter()
        .find(|a| a.manifest.name == bundle_name)
        .ok_or(BundleError::NotFound(bundle_name.to_string()))?;

    install_enabled_bundle_files(
        archive,
        &archives,
        cluster_id,
        true,
        skip_compatibility,
        None,
        ctx,
        None,
    )
    .await
}

/// `suppression` comes from [`find_user_suppression`] so a choice filed under a
/// bundle the file has since left still counts
pub(crate) fn disable_was_deliberate(suppression: Option<OverrideType>) -> bool {
    match suppression {
        Some(OverrideType::Removed | OverrideType::Disabled) => true,
        Some(OverrideType::Enabled) | None => false,
    }
}

const DUPLICATE_DISABLE_REPAIR: &str = "repair-hidden-duplicate-disables";

async fn clear_reconciler_disables(
    cluster_id: i64,
    archives: &[BundleArchive],
    ctx: &ContentCtx,
) -> ContentResult<()> {
    let id = format!("{DUPLICATE_DISABLE_REPAIR}:{cluster_id}");
    if migration_dao::is_applied(&ctx.db, &id).await? {
        return Ok(());
    }

    let hidden: std::collections::HashSet<String> = archives
        .iter()
        .flat_map(|archive| &archive.manifest.files)
        .filter(|file| file.hidden)
        .map(|file| file.kind.package_id())
        .collect();

    if hidden.is_empty() {
        return Ok(());
    }

    let mut cleared = 0u64;
    for package_id in &hidden {
        cleared += bundle_dao::clear_disabled_overrides(&ctx.db, cluster_id, package_id).await?;
    }

    if cleared > 0 {
        tracing::info!(
            cluster_id,
            cleared,
            "cleared disabled overrides on hidden bundle files that no user was ever shown"
        );
    }

    migration_dao::mark_applied(&ctx.db, &id).await?;
    Ok(())
}

const STALE_DISABLE_REPAIR: &str = "clear-disables-left-on-live-bundle-content";

async fn clear_stale_disables(cluster_id: i64, ctx: &ContentCtx) -> ContentResult<()> {
    let id = format!("{STALE_DISABLE_REPAIR}:{cluster_id}");
    if migration_dao::is_applied(&ctx.db, &id).await? {
        return Ok(());
    }

    let tracked = bundle_dao::list_bundle_tracked(&ctx.db, cluster_id).await?;
    let overrides = bundle_dao::list_overrides(&ctx.db, cluster_id).await?;
    let stale = stale_disables(&tracked, &overrides);

    for (bundle_name, package_id) in &stale {
        bundle_dao::remove_override(&ctx.db, cluster_id, bundle_name, package_id).await?;
    }

    if !stale.is_empty() {
        tracing::info!(
            cluster_id,
            cleared = stale.len(),
            "cleared disabled overrides left on bundle content that is switched on"
        );
    }

    migration_dao::mark_applied(&ctx.db, &id).await?;
    Ok(())
}

fn stale_disables(
    tracked: &[oneclient_db::models::BundleTrackedArtifactRow],
    overrides: &[oneclient_db::models::ClusterBundleOverrideRow],
) -> Vec<(String, String)> {
    overrides
        .iter()
        .filter(|o| OverrideType::parse(&o.override_type) == Some(OverrideType::Disabled))
        .filter(|o| {
            let mut copies = tracked
                .iter()
                .filter(|row| {
                    row.bundle_name.as_deref() == Some(o.bundle_name.as_str())
                        && row.package_id.as_deref() == Some(o.package_id.as_str())
                })
                .peekable();
            copies.peek().is_some() && copies.all(|row| row.enabled != 0)
        })
        .map(|o| (o.bundle_name.clone(), o.package_id.clone()))
        .collect()
}

pub(crate) fn external_ids_by_sha1(
    archives: &[BundleArchive],
) -> std::collections::HashMap<String, String> {
    archives
        .iter()
        .flat_map(|archive| &archive.manifest.files)
        .filter_map(|file| match &file.kind {
            BundleFileKind::External {
                file: ext,
                id: Some(id),
                ..
            } => Some((ext.sha1.clone(), id.clone())),
            _ => None,
        })
        .collect()
}

async fn adopt_external_ids(
    cluster_id: i64,
    archives: &[BundleArchive],
    ctx: &ContentCtx,
) -> ContentResult<()> {
    let ids = external_ids_by_sha1(archives);
    if ids.is_empty() {
        return Ok(());
    }

    for row in bundle_dao::list_bundle_tracked(&ctx.db, cluster_id).await? {
        let (Some(bundle_name), Some(version_id), Some(package_id)) =
            (&row.bundle_name, &row.bundle_version_id, &row.package_id)
        else {
            continue;
        };
        if *package_id != row.hash {
            continue;
        }
        let Some(id) = ids.get(package_id) else {
            continue;
        };
        bundle_dao::track_bundle_artifact(
            &ctx.db,
            cluster_id,
            &row.hash,
            bundle_name,
            version_id,
            id,
        )
        .await?;
    }

    let overrides = bundle_dao::list_overrides(&ctx.db, cluster_id).await?;
    for row in &overrides {
        let Some(id) = ids.get(&row.package_id) else {
            continue;
        };
        let superseded = overrides
            .iter()
            .any(|other| other.bundle_name == row.bundle_name && other.package_id == *id);
        if !superseded && let Some(override_type) = OverrideType::parse(&row.override_type) {
            bundle_dao::save_override(&ctx.db, cluster_id, &row.bundle_name, id, override_type)
                .await?;
        }
        bundle_dao::remove_override(&ctx.db, cluster_id, &row.bundle_name, &row.package_id).await?;
    }

    Ok(())
}

async fn supersede_outdated_user_copies(
    cluster_id: i64,
    archives: &[BundleArchive],
    all_archives: &[BundleArchive],
    ctx: &ContentCtx,
) -> ContentResult<()> {
    if bisect_dao::is_active(&ctx.db, cluster_id).await? {
        return Ok(());
    }

    let rows = bundle_dao::list_bundle_tracked(&ctx.db, cluster_id).await?;
    let tracked_projects: std::collections::HashSet<String> = rows
        .iter()
        .filter_map(|row| row.package_id.clone())
        .collect();
    let tracked: std::collections::HashSet<String> = rows.into_iter().map(|row| row.hash).collect();
    let mine: Vec<LinkedArtifactInfo> = PackageStore::list_linked_artifacts(cluster_id, ctx)
        .await?
        .into_iter()
        .filter(|info| info.enabled && !tracked.contains(&info.hash))
        .collect();

    let overrides = bundle_dao::list_overrides(&ctx.db, cluster_id).await?;
    let suppressors =
        overrides_outside_declined(cluster_id, all_archives, overrides.clone(), ctx).await?;
    let accepted = accepted_bundles(cluster_id, ctx).await?;
    let wanted = wanted_bundle_files(
        archives.iter().map(|archive| &archive.manifest),
        &accepted,
        |bundle_name, package_id| {
            find_override(&overrides, bundle_name, package_id)
                .or_else(|| find_user_suppression(&suppressors, package_id))
        },
    );

    for file in wanted {
        let BundleFileKind::Managed {
            provider,
            project_id,
            version_id,
            sha1,
        } = &file.kind
        else {
            continue;
        };
        if tracked_projects.contains(project_id) {
            continue;
        }
        let Some(copy) = mine.iter().find(|info| {
            info.provider == Some(*provider) && info.project_id.as_deref() == Some(project_id)
        }) else {
            continue;
        };
        if copy.version_id.as_deref() == Some(version_id.as_str()) {
            continue;
        }

        let shipped = match resolve_bundle_version(*provider, project_id, version_id, sha1, ctx)
            .await
        {
            Ok(shipped) => shipped,
            Err(err) => {
                tracing::warn!(cluster_id, project_id, error = %format!("{err:#}"), "could not read the shipped version, leaving the user's copy on");
                continue;
            }
        };
        if !ships_newer(&shipped, copy) {
            continue;
        }

        tracing::info!(
            cluster_id,
            project_id,
            hash = %copy.hash,
            "switching off the user's older copy so the bundle's package loads instead"
        );
        if let Err(err) =
            PackageStore::set_artifact_enabled_to(cluster_id, &copy.hash, false, ctx).await
        {
            tracing::warn!(hash = %copy.hash, error = %format!("{err:#}"), "failed to switch off the user's older copy");
        }
    }

    Ok(())
}

fn ships_newer(shipped: &VersionDetail, copy: &LinkedArtifactInfo) -> bool {
    copy.published_at
        .as_deref()
        .and_then(|at| DateTime::parse_from_rfc3339(at).ok())
        .is_some_and(|at| shipped.published > at)
}

#[tracing::instrument(level = "debug", skip(archives, ctx))]
pub async fn heal_bundle_activity(
    cluster_id: i64,
    archives: &[BundleArchive],
    ctx: &ContentCtx,
) -> ContentResult<()> {
    heal_bundle_activity_among(cluster_id, archives, archives, ctx).await
}

async fn heal_bundle_activity_among(
    cluster_id: i64,
    archives: &[BundleArchive],
    all_archives: &[BundleArchive],
    ctx: &ContentCtx,
) -> ContentResult<()> {
    clear_reconciler_disables(cluster_id, archives, ctx).await?;
    adopt_external_ids(cluster_id, archives, ctx).await?;
    clear_stale_disables(cluster_id, ctx).await?;

    supersede_outdated_user_copies(cluster_id, archives, all_archives, ctx).await?;

    let tracked = bundle_dao::list_bundle_tracked(&ctx.db, cluster_id).await?;
    if tracked.iter().all(|row| row.enabled != 0)
        || bisect_dao::is_active(&ctx.db, cluster_id).await?
    {
        return Ok(());
    }

    let hidden = hidden_flags(archives);

    let overrides = overrides_outside_declined(
        cluster_id,
        archives,
        bundle_dao::list_overrides(&ctx.db, cluster_id).await?,
        ctx,
    )
    .await?;

    let mut live_packages: std::collections::HashSet<String> = tracked
        .iter()
        .filter(|row| row.enabled != 0)
        .filter_map(|row| row.package_id.clone())
        .collect();

    for row in &tracked {
        let Some((bundle_name, package_id, is_hidden)) =
            heal_restores(row, &hidden, &overrides, &live_packages)
        else {
            continue;
        };

        tracing::info!(
            cluster_id,
            bundle = %bundle_name,
            package_id,
            hidden = is_hidden,
            suppression = ?find_user_suppression(&overrides, package_id),
            "re-enabling bundle content that was switched off with nothing recording the choice"
        );

        // One unrepairable row must not fail the whole install
        if let Err(err) =
            PackageStore::set_artifact_enabled_to(cluster_id, &row.hash, true, ctx).await
        {
            tracing::warn!(hash = %row.hash, error = %err, "failed to re-enable bundle content");
            continue;
        }

        live_packages.insert(package_id.to_string());
    }

    Ok(())
}

pub(crate) fn hidden_flags(
    archives: &[BundleArchive],
) -> std::collections::HashMap<(&str, String), bool> {
    archives
        .iter()
        .flat_map(|archive| {
            archive.manifest.files.iter().map(|file| {
                (
                    (archive.manifest.name.as_str(), file.kind.package_id()),
                    file.hidden,
                )
            })
        })
        .collect()
}

/// The bundle, package and hidden flag of a copy [`heal_bundle_activity`]
/// tries to switch back on, `None` when it is left as it is
pub(crate) fn heal_restores<'a>(
    row: &'a oneclient_db::models::BundleTrackedArtifactRow,
    hidden: &std::collections::HashMap<(&str, String), bool>,
    overrides: &[oneclient_db::models::ClusterBundleOverrideRow],
    live_packages: &std::collections::HashSet<String>,
) -> Option<(&'a str, &'a str, bool)> {
    let (Some(bundle_name), Some(package_id)) = (&row.bundle_name, &row.package_id) else {
        return None;
    };
    if row.enabled != 0 || live_packages.contains(package_id) {
        return None;
    }
    let is_hidden = hidden
        .get(&(bundle_name.as_str(), package_id.clone()))
        .copied()?;

    // Across bundles
    // a package that moved keeps its old override row and reading only its
    // current bundle would switch it back on
    (!disable_was_deliberate(find_user_suppression(overrides, package_id))).then_some((
        bundle_name,
        package_id,
        is_hidden,
    ))
}

#[tracing::instrument(level = "debug", skip(archive, all_archives, progress, ctx), fields(bundle = %archive.manifest.name))]
pub async fn install_enabled_bundle_files(
    archive: &BundleArchive,
    all_archives: &[BundleArchive],
    cluster_id: i64,
    taken: bool,
    skip_compatibility: bool,
    progress: Option<&GroupedProgressSession>,
    ctx: &ContentCtx,
    deadline: Option<Instant>,
) -> ContentResult<Vec<String>> {
    if taken {
        extract_bundle_overrides_for_cluster(archive, cluster_id, ctx).await?;
    }
    heal_bundle_activity_among(cluster_id, std::slice::from_ref(archive), all_archives, ctx)
        .await?;

    let overrides = bundle_dao::list_overrides(&ctx.db, cluster_id).await?;
    let suppressors =
        overrides_outside_declined(cluster_id, all_archives, overrides.clone(), ctx).await?;
    let bundle_name = archive.manifest.name.clone();
    let mut installed = Vec::new();

    // "Already installed" means the database not disk
    // content lives in the cache between sessions so probing the folder would
    // reinstall everything
    let present = PresentContent::load(cluster_id, ctx).await?;

    let to_install: Vec<BundleFile> = archive
        .manifest
        .files
        .iter()
        .filter(|file| {
            let package_id = file.kind.package_id();
            wants_file(
                file,
                find_override(&overrides, &bundle_name, &package_id)
                    .or_else(|| find_user_suppression(&suppressors, &package_id)),
                taken,
            ) && find_user_suppression(&overrides, &package_id) != Some(OverrideType::Removed)
                && !present.contains(file)
        })
        .cloned()
        .collect();

    tracing::info!(
        cluster_id,
        bundle = %bundle_name,
        to_install = to_install.len(),
        "installing enabled bundle files"
    );

    let results = install_bundle_files(
        to_install,
        cluster_id,
        &bundle_name,
        skip_compatibility,
        progress,
        ctx,
        deadline,
    )
    .await;

    for (file, result) in results {
        match result {
            Ok(hash) => installed.push(hash),
            Err(err) => {
                tracing::warn!(file = %file.display_name(), error = %err, "failed to install bundle file");
            }
        }
    }

    Ok(installed)
}

pub(crate) async fn install_bundle_files(
    to_install: Vec<BundleFile>,
    cluster_id: i64,
    bundle_name: &str,
    skip_compatibility: bool,
    progress: Option<&GroupedProgressSession>,
    ctx: &ContentCtx,
    deadline: Option<Instant>,
) -> Vec<(BundleFile, ContentResult<String>)> {
    if let Some(p) = progress {
        let reserved_bytes: u64 = to_install.iter().map(|f| f.size.max(1)).sum();
        p.expect(
            TaskCategory::Packages,
            to_install.len() as u64,
            reserved_bytes,
        );
    }

    let Some(deadline) = deadline else {
        return futures_util::stream::iter(to_install.into_iter().map(|file| async move {
            let child = file_child(&file, progress);
            prefetch_until(&file, child.as_ref(), None, ctx).await;
            let result = link_file(
                &file,
                cluster_id,
                bundle_name,
                skip_compatibility,
                child,
                ctx,
            )
            .await;
            (file, result)
        }))
        .buffer_unordered(BUNDLE_INSTALL_CONCURRENCY)
        .collect::<Vec<_>>()
        .await;
    };

    let fetched = futures_util::future::join_all(to_install.into_iter().map(|file| async move {
        let child = file_child(&file, progress);
        let fetched = prefetch_until(&file, child.as_ref(), Some(deadline), ctx).await;
        (file, child, fetched)
    }))
    .await;

    if fetched.iter().any(|(_, _, fetched)| fetched.is_none()) {
        tracing::info!(
            bundle = %bundle_name,
            "bundle files still downloading at the deadline, linking none of them until all are ready"
        );
        for (_, child, fetched) in fetched {
            if let (Some(child), Some(_)) = (child, fetched) {
                child.finish();
            }
        }
        return Vec::new();
    }

    futures_util::stream::iter(fetched.into_iter().filter_map(|(file, child, fetched)| {
        if let Some(Err(err)) = fetched {
            tracing::warn!(file = %file.display_name(), error = %err, "bundle download failed, leaving it for later");
            if let Some(child) = child {
                child.finish();
            }
            return None;
        }
        Some((file, child))
    }))
    .map(|(file, child)| async move {
        let result =
            link_file(&file, cluster_id, bundle_name, skip_compatibility, child, ctx).await;
        (file, result)
    })
    .buffer_unordered(BUNDLE_INSTALL_CONCURRENCY)
    .collect::<Vec<_>>()
    .await
}

fn file_child(
    file: &BundleFile,
    progress: Option<&GroupedProgressSession>,
) -> Option<GroupedProgressChild> {
    progress.map(|p| {
        let c = p.child(
            format!("Mod {}", file.display_name()),
            file.size.max(1),
            TaskCategory::Packages,
        );
        c.set_phase(TaskPhase::Downloading);
        c
    })
}

async fn link_file(
    file: &BundleFile,
    cluster_id: i64,
    bundle_name: &str,
    skip_compatibility: bool,
    child: Option<GroupedProgressChild>,
    ctx: &ContentCtx,
) -> ContentResult<String> {
    let result = install_package_from_bundle(
        file,
        cluster_id,
        bundle_name,
        skip_compatibility,
        child.as_ref(),
        ctx,
    )
    .await;
    if let Some(child) = child {
        child.set_phase(TaskPhase::Installing);
        child.finish();
    }
    result
}

pub(crate) struct PresentContent {
    projects: std::collections::HashSet<String>,
    hashes: std::collections::HashSet<String>,
    tracked_ids: std::collections::HashSet<String>,
}

impl PresentContent {
    pub(crate) async fn load(cluster_id: i64, ctx: &ContentCtx) -> ContentResult<Self> {
        let linked = PackageStore::list_linked_artifacts(cluster_id, ctx).await?;
        let tracked = bundle_dao::list_bundle_tracked(&ctx.db, cluster_id).await?;
        let tracked_hashes: std::collections::HashSet<&str> =
            tracked.iter().map(|row| row.hash.as_str()).collect();

        Ok(Self {
            projects: linked
                .iter()
                .filter(|info| info.enabled || tracked_hashes.contains(info.hash.as_str()))
                .filter_map(|info| info.project_id.clone())
                .collect(),
            tracked_ids: tracked
                .iter()
                .filter_map(|row| row.package_id.clone())
                .collect(),
            hashes: linked.into_iter().map(|info| info.hash).collect(),
        })
    }

    pub(crate) fn has_hash(&self, hash: &str) -> bool {
        self.hashes.contains(hash)
    }

    pub(crate) fn contains(&self, file: &BundleFile) -> bool {
        match &file.kind {
            BundleFileKind::Managed { project_id, .. } => self.projects.contains(project_id),
            BundleFileKind::External { file: ext, id, .. } => {
                self.hashes.contains(&ext.sha1)
                    || id.as_ref().is_some_and(|id| self.tracked_ids.contains(id))
            }
        }
    }
}

/// Kept modest each fetch also costs a provider API call rate limited per-minute
pub(crate) const BUNDLE_INSTALL_CONCURRENCY: usize = 6;

#[tracing::instrument(level = "debug", skip(bundles, ctx))]
pub async fn enabled_bundle_bytes(
    cluster_id: i64,
    bundles: &BundlesManager,
    ctx: &ContentCtx,
) -> ContentResult<u64> {
    let Some(cluster) = bundle_cluster(cluster_id, ctx).await? else {
        return Ok(0);
    };

    let loader = GameLoader::from_repr(cluster.mc_loader as u8).ok_or_else(|| {
        ContentError::InvalidData {
            reason: format!("unknown loader {}", cluster.mc_loader),
        }
    })?;

    let archives = bundles
        .archives_for(ctx, &cluster.mc_version, loader)
        .await?;
    let overrides = bundle_dao::list_overrides(&ctx.db, cluster_id).await?;
    let suppressors =
        overrides_outside_declined(cluster_id, &archives, overrides.clone(), ctx).await?;
    let accepted = accepted_bundles(cluster_id, ctx).await?;
    let present = PresentContent::load(cluster_id, ctx).await?;

    let mut total = 0u64;
    for archive in &archives {
        let bundle_name = &archive.manifest.name;
        let taken = takes_bundle(archive, &accepted);
        for file in &archive.manifest.files {
            let package_id = file.kind.package_id();
            if !wants_file(
                file,
                find_override(&overrides, bundle_name, &package_id)
                    .or_else(|| find_user_suppression(&suppressors, &package_id)),
                taken,
            ) || present.contains(file)
            {
                continue;
            }
            total += file.size;
        }
    }

    Ok(total)
}

#[tracing::instrument(level = "debug", skip(ctx))]
pub async fn set_bundle_package_override(
    cluster_id: i64,
    bundle_name: &str,
    package_id: &str,
    override_type: Option<OverrideType>,
    ctx: &ContentCtx,
) -> ContentResult<()> {
    if bundle_cluster(cluster_id, ctx).await?.is_none() {
        return Ok(());
    }

    match override_type {
        // The UI shows one row per package across bundles so an objection left
        // under another bundle would let the next pass undo this switch
        Some(ty @ OverrideType::Enabled) => {
            clear_suppressing_overrides(cluster_id, package_id, ctx).await?;
            bundle_dao::save_override(&ctx.db, cluster_id, bundle_name, package_id, ty).await?;
        }
        Some(ty) => {
            bundle_dao::save_override(&ctx.db, cluster_id, bundle_name, package_id, ty).await?;
        }
        None => {
            bundle_dao::remove_override(&ctx.db, cluster_id, bundle_name, package_id).await?;
        }
    }

    Ok(())
}

/// For bundle files the cluster has not installed
/// installed ones go through [`set_artifact_enabled_to`]
#[tracing::instrument(level = "debug", skip(ctx))]
pub async fn set_bundle_package_enabled(
    cluster_id: i64,
    bundle_name: &str,
    package_id: &str,
    enabled: bool,
    manifest_default: bool,
    ctx: &ContentCtx,
) -> ContentResult<()> {
    let override_type = match (enabled, manifest_default) {
        (true, _) => Some(OverrideType::Enabled),
        (false, false) => None,
        (false, true) => Some(OverrideType::Disabled),
    };

    set_bundle_package_override(cluster_id, bundle_name, package_id, override_type, ctx).await
}

/// Deleting unlinks every copy
/// restoring one with no copy left only records the choice, the caller runs
/// [`install_cluster_bundles`] to bring the files back
#[tracing::instrument(level = "debug", skip(ctx))]
pub async fn set_bundle_package_removed(
    cluster_id: i64,
    bundle_name: &str,
    package_id: &str,
    hash: Option<&str>,
    removed: bool,
    ctx: &ContentCtx,
) -> ContentResult<LiveSync> {
    if bundle_cluster(cluster_id, ctx).await?.is_none() {
        return Ok(LiveSync::Skipped);
    }

    let copies: Vec<_> = bundle_dao::list_bundle_tracked(&ctx.db, cluster_id)
        .await?
        .into_iter()
        .filter(|row| row.package_id.as_deref() == Some(package_id))
        .collect();
    let mut untracked = hash.filter(|hash| !copies.iter().any(|row| row.hash == *hash));
    if let Some(hash) = untracked
        && artifact_dao::get_cluster_artifact(&ctx.db, cluster_id, hash)
            .await?
            .is_none()
    {
        untracked = None;
    }
    let opted_in = opted_in_bundles(cluster_id, package_id, ctx).await?;
    let mut live = LiveSync::Skipped;
    if removed {
        // Deleting drops the files, a restore reinstalls them from the bundle
        for hash in copies.iter().map(|row| row.hash.as_str()).chain(untracked) {
            detach_artifact(cluster_id, hash, ctx).await?;
        }
    } else if let Some(hash) = untracked {
        live = set_artifact_enabled_to(cluster_id, hash, true, ctx).await?;
    } else if let Some(row) = copies
        .iter()
        .find(|row| Some(row.hash.as_str()) == hash)
        .or_else(|| {
            copies
                .iter()
                .max_by(|a, b| (a.enabled, &a.installed_at).cmp(&(b.enabled, &b.installed_at)))
        })
    {
        return set_artifact_enabled_to(cluster_id, &row.hash, true, ctx).await;
    }

    if removed {
        clear_suppressing_overrides(cluster_id, package_id, ctx).await?;
        withdraw_opt_ins(cluster_id, package_id, opted_in, ctx).await?;
        let mut owners: Vec<&str> = copies
            .iter()
            .filter_map(|row| row.bundle_name.as_deref())
            .chain([bundle_name])
            .collect();
        owners.sort_unstable();
        owners.dedup();
        for owner in owners {
            bundle_dao::save_override(
                &ctx.db,
                cluster_id,
                owner,
                package_id,
                OverrideType::Removed,
            )
            .await?;
        }
    } else {
        restore_opt_ins(cluster_id, package_id, ctx).await?;
        bundle_dao::save_override(
            &ctx.db,
            cluster_id,
            bundle_name,
            package_id,
            OverrideType::Enabled,
        )
        .await?;
    }

    Ok(live)
}

#[tracing::instrument(level = "debug", skip(overrides, ctx), fields(count = overrides.len()))]
pub async fn set_bundle_package_overrides(
    cluster_id: i64,
    overrides: &[(String, String, OverrideType)],
    ctx: &ContentCtx,
) -> ContentResult<()> {
    if bundle_cluster(cluster_id, ctx).await?.is_none() {
        return Ok(());
    }

    bundle_dao::save_overrides(&ctx.db, cluster_id, overrides).await?;
    Ok(())
}

#[tracing::instrument(level = "debug", skip(ctx))]
pub async fn set_bundle_package_opt_in(
    cluster_id: i64,
    bundle_name: &str,
    package_id: &str,
    opted_in: bool,
    ctx: &ContentCtx,
) -> ContentResult<()> {
    let override_type = if opted_in {
        Some(OverrideType::Enabled)
    } else {
        None
    };
    set_bundle_package_override(cluster_id, bundle_name, package_id, override_type, ctx).await
}

#[tracing::instrument(level = "debug", skip(ctx))]
pub async fn list_cluster_bundle_overrides(
    cluster_id: i64,
    ctx: &ContentCtx,
) -> ContentResult<Vec<(String, String, String)>> {
    let rows = bundle_dao::list_overrides(&ctx.db, cluster_id).await?;
    Ok(rows
        .into_iter()
        .map(|o| (o.bundle_name, o.package_id, o.override_type))
        .collect())
}

#[tracing::instrument(level = "debug", skip(bundles, ctx))]
pub async fn enabled_bundle_projects(
    cluster_id: i64,
    bundles: &BundlesManager,
    ctx: &ContentCtx,
) -> ContentResult<std::collections::HashSet<String>> {
    let cluster = PackageStore::get_cluster(cluster_id, ctx).await?;
    if !cluster.uses_bundles() {
        return Ok(std::collections::HashSet::new());
    }
    let loader = GameLoader::from_repr(cluster.mc_loader as u8).ok_or_else(|| {
        ContentError::InvalidData {
            reason: format!("unknown loader {}", cluster.mc_loader),
        }
    })?;

    let archives = bundles
        .archives_for(ctx, &cluster.mc_version, loader)
        .await?;
    let overrides = bundle_dao::list_overrides(&ctx.db, cluster_id).await?;
    let suppressors =
        overrides_outside_declined(cluster_id, &archives, overrides.clone(), ctx).await?;
    let accepted = accepted_bundles(cluster_id, ctx).await?;

    let mut projects = std::collections::HashSet::new();
    for archive in &archives {
        let bundle_name = &archive.manifest.name;
        let taken = takes_bundle(archive, &accepted);
        for file in &archive.manifest.files {
            let BundleFileKind::Managed { project_id, .. } = &file.kind else {
                continue;
            };
            if wants_file(
                file,
                find_override(&overrides, bundle_name, project_id)
                    .or_else(|| find_user_suppression(&suppressors, project_id)),
                taken,
            ) {
                projects.insert(project_id.clone());
            }
        }
    }

    Ok(projects)
}

pub(crate) async fn bundle_cluster(
    cluster_id: i64,
    ctx: &ContentCtx,
) -> ContentResult<Option<ClusterRow>> {
    let cluster = PackageStore::get_cluster(cluster_id, ctx).await?;
    Ok(cluster.uses_bundles().then_some(cluster))
}

#[tracing::instrument(skip(bundles, progress, ctx))]
pub async fn install_cluster_bundles(
    cluster_id: i64,
    bundles: &BundlesManager,
    progress: Option<&GroupedProgressSession>,
    ctx: &ContentCtx,
    deadline: Option<Instant>,
) -> ContentResult<()> {
    let _mutation = crate::packages::package_mutation_guard().await;
    let cluster = PackageStore::get_cluster(cluster_id, ctx).await?;
    if !cluster.uses_bundles() {
        tracing::debug!(cluster_id, "instance does not take bundle content");
        return Ok(());
    }

    let loader = GameLoader::from_repr(cluster.mc_loader as u8).ok_or_else(|| {
        ContentError::InvalidData {
            reason: format!("unknown loader {}", cluster.mc_loader),
        }
    })?;

    let archives = bundles
        .archives_for(ctx, &cluster.mc_version, loader)
        .await?;
    tracing::info!(
        cluster_id,
        mc_version = %cluster.mc_version,
        bundles = archives.len(),
        "installing enabled bundle content"
    );
    let accepted = accepted_bundles(cluster_id, ctx).await?;
    for archive in &archives {
        let taken = takes_bundle(archive, &accepted);
        let installed = install_enabled_bundle_files(
            archive, &archives, cluster_id, taken, true, progress, ctx, deadline,
        )
        .await?;
        tracing::info!(
            cluster_id,
            bundle = %archive.manifest.name,
            installed = installed.len(),
            "installed bundle files"
        );
    }

    Ok(())
}

#[tracing::instrument(level = "debug", skip(ctx))]
pub async fn on_user_remove_artifact(
    cluster_id: i64,
    hash: &str,
    ctx: &ContentCtx,
) -> ContentResult<()> {
    if let Some(tracked) = bundle_dao::get_bundle_tracked(&ctx.db, cluster_id, hash).await?
        && let Some(package_id) = tracked.package_id
    {
        let opted_in = opted_in_bundles(cluster_id, &package_id, ctx).await?;
        clear_suppressing_overrides(cluster_id, &package_id, ctx).await?;
        withdraw_opt_ins(cluster_id, &package_id, opted_in, ctx).await?;
    }
    handle_user_artifact_action(cluster_id, hash, ctx, OverrideType::Removed).await?;
    detach_artifact(cluster_id, hash, ctx).await
}

/// The caller passes the value it wants
/// a relinked artifact keeps its old `enabled` so a flip on an already-correct
/// row puts it wrong
#[tracing::instrument(level = "debug", skip(ctx))]
pub async fn set_artifact_enabled_to(
    cluster_id: i64,
    hash: &str,
    enabled: bool,
    ctx: &ContentCtx,
) -> ContentResult<LiveSync> {
    let (_, live) = PackageStore::set_artifact_enabled_to(cluster_id, hash, enabled, ctx).await?;

    if enabled {
        on_user_enable_artifact(cluster_id, hash, ctx).await?;
    } else {
        on_user_disable_artifact(cluster_id, hash, ctx).await?;
    }

    Ok(live)
}

// which clusters have to record what the user just did
async fn override_scope(cluster_id: i64, hash: &str, ctx: &ContentCtx) -> ContentResult<Vec<i64>> {
    Ok(sharing_scope(cluster_id, hash, ctx)
        .await?
        .unwrap_or_else(|| vec![cluster_id]))
}

#[tracing::instrument(level = "debug", skip(ctx))]
pub async fn on_user_disable_artifact(
    cluster_id: i64,
    hash: &str,
    ctx: &ContentCtx,
) -> ContentResult<()> {
    for id in override_scope(cluster_id, hash, ctx).await? {
        handle_user_artifact_action(id, hash, ctx, OverrideType::Disabled).await?;
    }

    Ok(())
}

#[tracing::instrument(level = "debug", skip(ctx))]
pub async fn on_user_enable_artifact(
    cluster_id: i64,
    hash: &str,
    ctx: &ContentCtx,
) -> ContentResult<()> {
    for id in override_scope(cluster_id, hash, ctx).await? {
        let Some(tracked) = bundle_dao::get_bundle_tracked(&ctx.db, id, hash).await? else {
            continue;
        };
        let Some(package_id) = tracked.package_id else {
            continue;
        };
        let overrides = bundle_dao::list_overrides(&ctx.db, id).await?;
        let removed = tracked.bundle_name.is_some_and(|name| {
            find_override(&overrides, &name, &package_id) == Some(OverrideType::Removed)
        });
        if removed {
            restore_opt_ins(id, &package_id, ctx).await?;
        } else {
            clear_suppressing_overrides(id, &package_id, ctx).await?;
        }
    }

    Ok(())
}

#[tracing::instrument(level = "debug", skip(ctx))]
async fn handle_user_artifact_action(
    cluster_id: i64,
    hash: &str,
    ctx: &ContentCtx,
    override_type: OverrideType,
) -> ContentResult<()> {
    let Some(tracked) = bundle_dao::get_bundle_tracked(&ctx.db, cluster_id, hash).await? else {
        return Ok(());
    };

    let (Some(bundle_name), Some(package_id)) = (tracked.bundle_name, tracked.package_id) else {
        return Ok(());
    };

    bundle_dao::save_override(
        &ctx.db,
        cluster_id,
        &bundle_name,
        &package_id,
        override_type,
    )
    .await?;

    Ok(())
}

#[tracing::instrument(level = "debug", skip(ctx))]
pub async fn remove_artifact_from_cluster(
    cluster_id: i64,
    hash: &str,
    record_override: bool,
    ctx: &ContentCtx,
) -> ContentResult<()> {
    let bundle_data = bundle_dao::get_bundle_tracked(&ctx.db, cluster_id, hash).await?;

    detach_artifact(cluster_id, hash, ctx).await?;

    if let Some(tracked) = bundle_data
        && let (Some(bundle_name), Some(package_id)) =
            (tracked.bundle_name.clone(), tracked.package_id.clone())
    {
        if record_override {
            let opted_in = opted_in_bundles(cluster_id, &package_id, ctx).await?;
            withdraw_opt_ins(cluster_id, &package_id, opted_in, ctx).await?;
            bundle_dao::save_override(
                &ctx.db,
                cluster_id,
                &bundle_name,
                &package_id,
                OverrideType::Removed,
            )
            .await?;
        } else {
            let replacement_exists =
                bundle_dao::has_bundle_mapping_for_package(&ctx.db, cluster_id, &package_id)
                    .await?;
            if !replacement_exists {
                clear_suppressing_overrides(cluster_id, &package_id, ctx).await?;
            }
        }
    }

    Ok(())
}

pub(crate) async fn detach_artifact(
    cluster_id: i64,
    hash: &str,
    ctx: &ContentCtx,
) -> ContentResult<()> {
    let cluster = PackageStore::get_cluster(cluster_id, ctx).await?;
    let content_type = removable_content_type(cluster_id, hash, ctx).await?;
    let link = artifact_dao::get_cluster_artifact(&ctx.db, cluster_id, hash).await?;
    artifact_dao::unlink_cluster_artifact(&ctx.db, cluster_id, hash).await?;
    finish_detach(&cluster, hash, content_type, link, ctx).await;
    Ok(())
}

/// An Undo owns exactly the manual link its install created.
pub async fn can_undo_artifact(
    cluster_id: i64,
    hash: &str,
    added_at: &str,
    ctx: &ContentCtx,
) -> ContentResult<bool> {
    Ok(artifact_dao::matches_manual_artifact_link(&ctx.db, cluster_id, hash, added_at).await?
        && clusters_sharing_artifact(cluster_id, hash, ctx)
            .await?
            .is_none_or(|count| count <= 1))
}

/// The caller holds the exclusive package mutation guard through planning and
/// removal. The database commits the whole group before files are cleaned up,
/// so circular dependencies cannot leave a partial removal.
pub async fn detach_undo_artifacts(
    cluster_id: i64,
    artifacts: &[(&str, &str)],
    ctx: &ContentCtx,
) -> ContentResult<bool> {
    use crate::packages::store::{manifest, undo::StagedUndoFiles};

    let cluster = PackageStore::get_cluster(cluster_id, ctx).await?;
    let _manifest = manifest::lock().await;
    let mut staged = StagedUndoFiles::default();
    for (hash, _) in artifacts {
        let prepared = async {
            let content_type = removable_content_type(cluster_id, hash, ctx).await?;
            let link = artifact_dao::get_cluster_artifact(&ctx.db, cluster_id, hash).await?;
            if let (Some(content_type), Some(link)) = (content_type, link) {
                staged.stage(&cluster, &link, content_type, ctx).await?;
            }
            ContentResult::Ok(())
        }.await;
        if let Err(err) = prepared {
            staged.rollback().await;
            return Err(err);
        }
    }

    match artifact_dao::unlink_unchanged_manual_artifacts(&ctx.db, cluster_id, artifacts).await {
        Ok(Some(_)) => {}
        Ok(None) => {
            staged.rollback().await;
            return Ok(false);
        }
        Err(err) => {
            staged.rollback().await;
            return Err(err.into());
        }
    }

    staged.commit().await;
    // Other sessions may still load these cache files through shared content
    // directories. Leave cache reclamation to the normal storage cleanup.
    Ok(true)
}

async fn removable_content_type(
    cluster_id: i64,
    hash: &str,
    ctx: &ContentCtx,
) -> ContentResult<Option<ContentType>> {
    let content_type = artifact_dao::get_artifact_by_hash(&ctx.db, hash)
        .await?
        .and_then(|artifact| ContentType::from_repr(artifact.content_type as u8));
    crate::packages::store::ensure_mods_unlocked(cluster_id, content_type, ctx).await?;
    Ok(content_type)
}

async fn finish_detach(
    cluster: &ClusterRow,
    hash: &str,
    content_type: Option<ContentType>,
    link: Option<ClusterArtifactRow>,
    ctx: &ContentCtx,
) {
    // A jar held open on Windows can defer folder cleanup until the next launch.
    let deferred = match (content_type, link) {
        (Some(content_type), Some(link)) => {
            let name = &link.cluster_file_name;
            drop_unmanaged_mod(cluster, content_type, name, hash, &ctx.db).await;
            try_unlink_materialized(cluster, content_type, name, &ctx.db).await
                == LiveSync::Deferred
        }
        _ => false,
    };

    if !deferred && let Err(err) = evict_if_unused(hash, ctx).await {
        tracing::warn!(hash, error = %err, "failed to evict unused artifact from the cache");
    }
}

async fn sharing_scope(
    cluster_id: i64,
    hash: &str,
    ctx: &ContentCtx,
) -> ContentResult<Option<Vec<i64>>> {
    let global = artifact_dao::get_artifact_by_hash(&ctx.db, hash)
        .await?
        .and_then(|artifact| ContentType::from_repr(artifact.content_type as u8))
        .is_some_and(|content_type| content_type.is_global());
    if !global {
        return Ok(None);
    }
    global_sharing_scope(cluster_id, ctx).await
}

async fn global_sharing_scope(
    cluster_id: i64,
    ctx: &ContentCtx,
) -> ContentResult<Option<Vec<i64>>> {
    let Some(cluster) = oneclient_db::dao::cluster::get_by_id(&ctx.db, cluster_id).await? else {
        return Ok(None);
    };
    let sharing = crate::packages::store::sharing_with(&ctx.db, &cluster).await?;

    Ok(sharing.contains(&cluster_id).then_some(sharing))
}

async fn sharing_clusters(
    cluster_id: i64,
    hash: &str,
    ctx: &ContentCtx,
) -> ContentResult<Option<Vec<i64>>> {
    let Some(sharing) = sharing_scope(cluster_id, hash, ctx).await? else {
        return Ok(None);
    };

    Ok(Some(
        artifact_dao::list_clusters_linking(&ctx.db, hash)
            .await?
            .into_iter()
            .filter(|id| sharing.contains(id))
            .collect(),
    ))
}

#[tracing::instrument(level = "debug", skip(ctx))]
pub async fn clusters_sharing_artifact(
    cluster_id: i64,
    hash: &str,
    ctx: &ContentCtx,
) -> ContentResult<Option<usize>> {
    Ok(sharing_clusters(cluster_id, hash, ctx)
        .await?
        .map(|clusters| clusters.len()))
}

#[tracing::instrument(level = "debug", skip(ctx))]
pub async fn clusters_sharing_global_folders(
    cluster_id: i64,
    ctx: &ContentCtx,
) -> ContentResult<Option<usize>> {
    Ok(global_sharing_scope(cluster_id, ctx)
        .await?
        .map(|clusters| clusters.len()))
}

#[tracing::instrument(level = "debug", skip(ctx))]
pub async fn delete_artifact(cluster_id: i64, hash: &str, ctx: &ContentCtx) -> ContentResult<()> {
    let Some(linked_clusters) = sharing_clusters(cluster_id, hash, ctx).await? else {
        return remove_artifact_from_cluster(cluster_id, hash, true, ctx).await;
    };

    let mut first_error = None;
    for linked_cluster in linked_clusters {
        if let Err(err) = remove_artifact_from_cluster(linked_cluster, hash, true, ctx).await {
            tracing::warn!(cluster_id = linked_cluster, hash, error = %err, "failed to delete shared package from a cluster");
            first_error.get_or_insert(err);
        }
    }

    first_error.map_or(Ok(()), Err)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::bundles::types::BundleFileType;
    use oneclient_common::domain::ContentType;
    use oneclient_db::models::ClusterBundleOverrideRow;

    fn file(enabled: bool) -> BundleFile {
        BundleFile {
            enabled,
            hidden: false,
            path: "mods/example.jar".to_string(),
            size: 1,
            file_type: BundleFileType::Normal,
            kind: BundleFileKind::External {
                file: ExternalFile {
                    name: "example.jar".to_string(),
                    url: "https://example.invalid/example.jar".to_string(),
                    sha1: "abc123".to_string(),
                    size: 1,
                    content_type: ContentType::Mod,
                },
                id: None,
                meta: None,
            },
        }
    }

    fn manifest(name: &str, enabled: bool, files: Vec<BundleFile>) -> BundleManifest {
        BundleManifest {
            name: name.to_string(),
            version_id: "1".to_string(),
            category: String::new(),
            mc_version: "1.21.1".to_string(),
            loader: GameLoader::Fabric,
            loader_version: "0.16.5".to_string(),
            enabled,
            java_version_override: None,
            files,
        }
    }

    fn named(name: &str, enabled: bool) -> BundleFile {
        let mut file = file(enabled);
        file.path = format!("mods/{name}.jar");
        if let BundleFileKind::External { file: ext, .. } = &mut file.kind {
            ext.name = format!("{name}.jar");
            ext.sha1 = name.to_string();
        }
        file
    }

    #[test]
    fn the_planned_bundle_files_follow_choices_and_overrides() {
        let manifests = vec![
            manifest(
                "Core",
                true,
                vec![named("a", true), named("b", true), named("off", false)],
            ),
            manifest("Picked", false, vec![named("c", true)]),
            manifest(
                "Declined",
                false,
                vec![named("d", true), named("opted", false)],
            ),
        ];
        let accepted: std::collections::HashSet<String> = ["Picked".to_string()].into();
        let disabled_b = named("b", true).kind.package_id();
        let opted = named("opted", false).kind.package_id();

        let wanted = wanted_bundle_files(&manifests, &accepted, |bundle, package| {
            if bundle == "Core" && package == disabled_b {
                Some(OverrideType::Disabled)
            } else if bundle == "Declined" && package == opted {
                Some(OverrideType::Enabled)
            } else {
                None
            }
        });

        let paths: Vec<&str> = wanted.iter().map(|file| file.path.as_str()).collect();
        assert_eq!(paths, vec!["mods/a.jar", "mods/c.jar", "mods/opted.jar"]);
    }

    #[test]
    fn override_none_falls_back_to_manifest_default() {
        assert!(effective_enabled(&file(true), None));
        assert!(!effective_enabled(&file(false), None));
    }

    #[test]
    fn suppressing_overrides_win_over_enabled_manifest() {
        assert!(!effective_enabled(
            &file(true),
            Some(OverrideType::Disabled)
        ));
        assert!(!effective_enabled(&file(true), Some(OverrideType::Removed)));
    }

    #[test]
    fn enabled_override_wins_over_disabled_manifest() {
        assert!(effective_enabled(&file(false), Some(OverrideType::Enabled)));
    }

    #[test]
    fn enabled_override_round_trips_through_the_db_string() {
        let parsed = OverrideType::parse(OverrideType::Enabled.as_str());
        assert_eq!(parsed, Some(OverrideType::Enabled));
    }

    #[test]
    fn unknown_override_string_is_ignored() {
        assert_eq!(OverrideType::parse("something-new"), None);
    }

    fn row(bundle: &str, pid: &str, ty: OverrideType) -> ClusterBundleOverrideRow {
        ClusterBundleOverrideRow {
            id: 1,
            cluster_id: 1,
            bundle_name: bundle.to_string(),
            package_id: pid.to_string(),
            override_type: ty.as_str().to_string(),
        }
    }

    #[test]
    fn a_disable_with_no_override_behind_it_is_an_accident() {
        assert!(!disable_was_deliberate(None));
    }

    #[test]
    fn a_users_own_disable_is_respected() {
        assert!(disable_was_deliberate(Some(OverrideType::Disabled)));
        assert!(disable_was_deliberate(Some(OverrideType::Removed)));
    }

    #[test]
    fn a_hidden_dependency_can_be_disabled_on_its_own() {
        let file = BundleFile {
            hidden: true,
            ..file(true)
        };

        assert!(
            disable_was_deliberate(Some(OverrideType::Disabled)),
            "the hidden filter offers the toggle so the choice behind it has to outlive a launch"
        );
        assert!(!effective_enabled(&file, Some(OverrideType::Disabled)));
    }

    #[test]
    fn an_opt_in_override_never_reads_as_a_disable() {
        assert!(!disable_was_deliberate(Some(OverrideType::Enabled)));
    }

    #[test]
    fn suppression_is_found_under_a_bundle_the_package_has_since_left() {
        let rows = vec![row("Bundle B", "fabric-api", OverrideType::Disabled)];

        assert_eq!(
            find_override(&rows, "Bundle C", "fabric-api"),
            None,
            "the per-bundle question is still answered per bundle"
        );
        assert_eq!(
            find_user_suppression(&rows, "fabric-api"),
            Some(OverrideType::Disabled),
            "the user's choice follows the package, not the bundle it was filed under"
        );
    }

    #[test]
    fn declining_a_bundle_does_not_suppress_its_mods_elsewhere() {
        let rows = vec![
            row("Declined", "skyblocker", OverrideType::Removed),
            row("Old", "modmenu", OverrideType::Removed),
        ];
        let suppressors: Vec<_> = rows
            .into_iter()
            .filter(|o| survives_decline(o, &["Declined"].into(), &Default::default()))
            .collect();

        assert_eq!(find_user_suppression(&suppressors, "skyblocker"), None);
        assert_eq!(
            find_user_suppression(&suppressors, "modmenu"),
            Some(OverrideType::Removed)
        );
    }

    #[test]
    fn removal_outranks_a_disable_filed_elsewhere() {
        let rows = vec![
            row("Bundle A", "yacl", OverrideType::Disabled),
            row("Bundle B", "yacl", OverrideType::Removed),
        ];

        assert_eq!(
            find_user_suppression(&rows, "yacl"),
            Some(OverrideType::Removed)
        );
    }

    #[test]
    fn an_opt_in_is_not_an_objection() {
        let rows = vec![
            row("Bundle A", "sodium", OverrideType::Enabled),
            row("Bundle B", "lithium", OverrideType::Disabled),
        ];

        assert_eq!(find_user_suppression(&rows, "sodium"), None);
        assert_eq!(find_user_suppression(&rows, "unheard-of"), None);
    }

    #[test]
    fn find_override_matches_on_bundle_and_package() {
        let rows = vec![
            row("Bundle A", "pkg-1", OverrideType::Enabled),
            row("Bundle B", "pkg-2", OverrideType::Disabled),
        ];
        assert_eq!(
            find_override(&rows, "Bundle A", "pkg-1"),
            Some(OverrideType::Enabled)
        );
        assert_eq!(
            find_override(&rows, "Bundle B", "pkg-2"),
            Some(OverrideType::Disabled)
        );
        assert_eq!(find_override(&rows, "Bundle B", "pkg-1"), None);
        assert_eq!(find_override(&rows, "Bundle A", "pkg-3"), None);
    }

    fn tracked(
        bundle: &str,
        pid: &str,
        hash: &str,
        enabled: bool,
    ) -> oneclient_db::models::BundleTrackedArtifactRow {
        oneclient_db::models::BundleTrackedArtifactRow {
            cluster_id: 1,
            hash: hash.to_string(),
            cluster_file_name: format!("{pid}.jar"),
            enabled: i64::from(enabled),
            bundle_name: Some(bundle.to_string()),
            bundle_version_id: Some("v1".to_string()),
            package_id: Some(pid.to_string()),
            installed_at: None,
        }
    }

    #[test]
    fn a_disable_on_a_mod_still_held_from_a_declined_bundle_survives() {
        let declined = std::collections::HashSet::from(["SkyBlock"]);
        let held =
            std::collections::HashSet::from([("SkyBlock".to_string(), "skyhanni".to_string())]);

        assert!(survives_decline(
            &row("SkyBlock", "skyhanni", OverrideType::Disabled),
            &declined,
            &held
        ));
    }

    #[test]
    fn a_removal_filed_by_declining_a_bundle_is_still_dropped() {
        let declined = std::collections::HashSet::from(["SkyBlock"]);
        let held =
            std::collections::HashSet::from([("SkyBlock".to_string(), "skyblocker".to_string())]);

        assert!(
            !survives_decline(
                &row("SkyBlock", "skyblocker", OverrideType::Removed),
                &declined,
                &held
            ),
            "a hand-installed mod the declined bundle also lists must keep updating"
        );
    }

    #[test]
    fn a_disable_on_a_declined_bundle_mod_that_is_not_installed_is_dropped() {
        let declined = std::collections::HashSet::from(["SkyBlock"]);

        assert!(!survives_decline(
            &row("SkyBlock", "skyhanni", OverrideType::Disabled),
            &declined,
            &std::collections::HashSet::new()
        ));
    }

    #[test]
    fn overrides_of_a_taken_bundle_are_untouched() {
        let declined = std::collections::HashSet::from(["SkyBlock"]);
        let none = std::collections::HashSet::new();

        assert!(survives_decline(
            &row("HUD", "modmenu", OverrideType::Disabled),
            &declined,
            &none
        ));
        assert!(survives_decline(
            &row("HUD", "modmenu", OverrideType::Removed),
            &declined,
            &none
        ));
    }

    #[test]
    fn a_disable_left_on_a_mod_that_is_switched_on_is_stale() {
        let stale = stale_disables(
            &[tracked("SkyBlock", "skyhanni", "a", true)],
            &[row("SkyBlock", "skyhanni", OverrideType::Disabled)],
        );

        assert_eq!(stale, [("SkyBlock".to_string(), "skyhanni".to_string())]);
    }

    #[test]
    fn a_disable_on_a_mod_that_is_switched_off_is_kept() {
        assert!(
            stale_disables(
                &[tracked("SkyBlock", "skyhanni", "a", false)],
                &[row("SkyBlock", "skyhanni", OverrideType::Disabled)],
            )
            .is_empty()
        );
    }

    #[test]
    fn a_disable_is_kept_while_any_copy_of_the_package_is_switched_off() {
        assert!(
            stale_disables(
                &[
                    tracked("SkyBlock", "skyhanni", "a", true),
                    tracked("SkyBlock", "skyhanni", "b", false),
                ],
                &[row("SkyBlock", "skyhanni", OverrideType::Disabled)],
            )
            .is_empty()
        );
    }

    #[test]
    fn only_disables_on_held_content_under_the_same_bundle_are_stale() {
        assert!(
            stale_disables(
                &[tracked("HUD", "skyhanni", "a", true)],
                &[
                    row("SkyBlock", "skyhanni", OverrideType::Disabled),
                    row("HUD", "skyhanni", OverrideType::Removed),
                    row("HUD", "skyhanni", OverrideType::Enabled),
                    row("HUD", "unheld", OverrideType::Disabled),
                ],
            )
            .is_empty()
        );
    }

    struct ServedByHash;

    #[async_trait::async_trait]
    impl crate::packages::PackageProvider for ServedByHash {
        fn id(&self) -> ProviderId {
            ProviderId::Modrinth
        }
        async fn search(
            &self,
            _: &crate::packages::SearchFilters,
            _: &ContentCtx,
        ) -> ContentResult<crate::packages::Page<crate::packages::ProjectSummary>> {
            unreachable!()
        }
        async fn get_project(
            &self,
            _: &str,
            _: &ContentCtx,
        ) -> ContentResult<crate::packages::ProjectDetail> {
            unreachable!()
        }
        async fn get_projects(
            &self,
            _: &[String],
            _: &ContentCtx,
        ) -> ContentResult<Vec<crate::packages::ProjectDetail>> {
            unreachable!()
        }
        async fn list_versions(
            &self,
            _: &str,
            _: Option<&str>,
            _: Option<GameLoader>,
            _: usize,
            _: usize,
            _: &ContentCtx,
        ) -> ContentResult<crate::packages::Page<crate::packages::VersionSummary>> {
            unreachable!()
        }
        async fn get_version(
            &self,
            _: &str,
            _: &str,
            _: &ContentCtx,
        ) -> ContentResult<VersionDetail> {
            unreachable!()
        }
        async fn get_versions(
            &self,
            _: &[String],
            _: &ContentCtx,
        ) -> ContentResult<Vec<VersionDetail>> {
            unreachable!()
        }
        async fn lookup_versions(
            &self,
            identities: &[crate::packages::FileIdentity],
            _: &ContentCtx,
        ) -> ContentResult<crate::packages::VersionLookup> {
            Ok(identities
                .iter()
                .map(|identity| {
                    let version = VersionDetail {
                        version_id: "served".to_string(),
                        project_id: "project".to_string(),
                        name: String::new(),
                        version_number: String::new(),
                        changelog: None,
                        game_versions: Vec::new(),
                        loaders: Vec::new(),
                        published: chrono::Utc::now(),
                        downloads: 0,
                        files: vec![crate::packages::VersionFile {
                            sha1: identity.sha1.clone(),
                            url: "https://example.invalid/managed.jar".to_string(),
                            file_name: "managed.jar".to_string(),
                            primary: true,
                            size: 1,
                            fingerprint: None,
                        }],
                        dependencies: Vec::new(),
                    };
                    (identity.sha1.clone(), version)
                })
                .collect())
        }
        async fn latest_for_game_version(
            &self,
            _: &[crate::packages::InstalledPackage],
            _: &str,
            _: GameLoader,
            _: &ContentCtx,
        ) -> ContentResult<std::collections::HashMap<String, VersionDetail>> {
            unreachable!()
        }
    }

    #[tokio::test]
    async fn a_damaged_cached_copy_resolves_to_a_downloadable_version() {
        let dir = polyio::tempdir().await.unwrap();
        let mut providers = crate::packages::PackageProviderRegistry::new();
        providers.register(std::sync::Arc::new(ServedByHash));
        let (tx, _rx) = tokio::sync::mpsc::unbounded_channel();
        let ctx = ContentCtx::new(
            oneclient_db::connect(dir.dir_path().join("test.db"))
                .await
                .unwrap(),
            oneclient_net::RequestClient::new(oneclient_net::NetConfig::default()).unwrap(),
            oneclient_events::EventBus::new(tx),
            providers,
            Default::default(),
        );
        let sha1 = polyio::sha1_bytes(b"the real jar");
        let damaged = dir.dir_path().join("managed.jar");
        tokio::fs::write(&damaged, b"not the real jar")
            .await
            .unwrap();
        artifact_dao::insert_artifact(
            &ctx.db,
            &sha1,
            ContentType::Mod as i64,
            &damaged.to_string_lossy(),
            "managed.jar",
            Some(1),
        )
        .await
        .unwrap();
        artifact_dao::upsert_provider_release(
            &ctx.db,
            ProviderId::Modrinth as i64,
            "project",
            "cached",
            &sha1,
            "",
            "",
            None,
            "[]",
            "[]",
        )
        .await
        .unwrap();

        let version =
            resolve_bundle_version(ProviderId::Modrinth, "project", "1.0.0+mc", &sha1, &ctx)
                .await
                .unwrap();

        assert!(!version.primary_file().unwrap().url.is_empty());
    }
}
