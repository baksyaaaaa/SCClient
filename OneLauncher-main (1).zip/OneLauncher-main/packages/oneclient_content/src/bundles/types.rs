use std::collections::HashSet;

use serde::{Deserialize, Serialize};

use crate::bundles::Bundle;
use crate::packages::types::ExternalFile;
use oneclient_common::domain::{ContentType, GameLoader, ProviderId};

#[derive(Debug, Clone)]
pub struct BundleArchive {
    pub bundle: Bundle,
    pub manifest: BundleManifest,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BundleManifest {
    pub name: String,
    pub version_id: String,
    pub category: String,
    pub mc_version: String,
    pub loader: GameLoader,
    pub loader_version: String,
    pub enabled: bool,
    #[serde(default)]
    pub java_version_override: Option<u32>,
    pub files: Vec<BundleFile>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct BundleFile {
    pub enabled: bool,
    pub hidden: bool,
    #[serde(default)]
    pub path: String,
    #[serde(default)]
    pub size: u64,
    #[serde(default)]
    pub file_type: BundleFileType,
    pub kind: BundleFileKind,
}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum BundleFileType {
    Advanced,
    #[default]
    #[serde(other)]
    Normal,
}

impl BundleFile {
    pub fn is_optional_offer(&self) -> bool {
        !self.enabled && !self.hidden && self.file_type == BundleFileType::Normal
    }

    pub fn content_type(&self) -> ContentType {
        if let BundleFileKind::External { file, .. } = &self.kind {
            return file.content_type;
        }
        content_type_from_bundle_path(&self.path)
    }

    pub fn is_github_hosted(&self) -> bool {
        let BundleFileKind::External { file, .. } = &self.kind else {
            return false;
        };
        url::Url::parse(&file.url).is_ok_and(|url| {
            url.host_str().is_some_and(|host| {
                host == "github.com"
                    || host.ends_with(".github.com")
                    || host.ends_with(".githubusercontent.com")
            })
        })
    }

    pub fn github_repo_url(&self) -> Option<String> {
        let BundleFileKind::External { file, .. } = &self.kind else {
            return None;
        };
        let url = url::Url::parse(&file.url).ok()?;
        if !matches!(url.host_str()?, "github.com" | "raw.githubusercontent.com") {
            return None;
        }
        let mut segments = url.path_segments()?.filter(|s| !s.is_empty());
        let owner = segments.next()?;
        let repo = segments.next()?;
        Some(format!("https://github.com/{owner}/{repo}"))
    }

    pub fn display_name(&self) -> String {
        if let BundleFileKind::External {
            meta: Some(meta), ..
        } = &self.kind
            && let Some(name) = &meta.name
        {
            return name.clone();
        }
        let from_path = self.path.rsplit('/').next().filter(|s| !s.is_empty());
        if let Some(name) = from_path {
            return name.to_string();
        }
        match &self.kind {
            BundleFileKind::External { file, .. } => file.name.clone(),
            BundleFileKind::Managed { project_id, .. } => project_id.clone(),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum BundleFileKind {
    Managed {
        provider: ProviderId,
        project_id: String,
        version_id: String,
        sha1: String,
    },
    External {
        file: ExternalFile,
        id: Option<String>,
        meta: Option<ExternalFileMeta>,
    },
}

#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct ExternalFileMeta {
    pub name: Option<String>,
    pub description: Option<String>,
    pub authors: Vec<String>,
    pub icon_url: Option<String>,
}

impl BundleFileKind {
    pub fn package_id(&self) -> String {
        match self {
            Self::Managed { project_id, .. } => project_id.clone(),
            Self::External { file, id, .. } => id.clone().unwrap_or_else(|| file.sha1.clone()),
        }
    }

    pub fn bundle_version_id(&self) -> String {
        match self {
            Self::Managed { version_id, .. } => version_id.clone(),
            Self::External { file, .. } => file.sha1.clone(),
        }
    }

    pub fn metadata_id(&self) -> String {
        match self {
            Self::Managed { project_id, .. } => project_id.clone(),
            Self::External { file, .. } => file.sha1.clone(),
        }
    }

    pub fn metadata_provider(&self) -> ProviderId {
        match self {
            Self::Managed { provider, .. } => *provider,
            Self::External { .. } => ProviderId::Local,
        }
    }

    pub fn bundle_key(&self) -> String {
        match self {
            Self::Managed {
                provider,
                project_id,
                ..
            } => managed_bundle_key(*provider, project_id),
            Self::External { .. } => external_bundle_key(&self.package_id()),
        }
    }
}

pub fn managed_bundle_key(provider: ProviderId, package_id: &str) -> String {
    format!("m:{}:{package_id}", provider.dir_name())
}

pub fn external_bundle_key(package_id: &str) -> String {
    format!("e:{package_id}")
}

pub fn content_type_from_bundle_path(path: &str) -> ContentType {
    let top = path.split('/').next().unwrap_or("");
    ContentType::from_folder_name(top).unwrap_or(ContentType::Mod)
}

#[derive(Debug, Clone)]
pub struct BundlePackageUpdate {
    pub cluster_id: i64,
    pub installed_hash: String,
    pub installed_version_id: String,
    pub bundle_name: String,
    pub new_version_id: String,
    pub new_file: BundleFile,
}

#[derive(Debug, Clone)]
pub struct BundlePackageRemoval {
    pub cluster_id: i64,
    pub hash: String,
    pub package_id: String,
    pub bundle_name: String,
    /// `None` for external/local files
    pub provider: Option<ProviderId>,
    pub project_id: Option<String>,
    /// Captured at check time
    /// fallback when the meta cache has no entry
    pub display_name: Option<String>,
}

#[derive(Debug, Clone)]
pub struct BundlePackageAddition {
    pub cluster_id: i64,
    pub bundle_name: String,
    pub new_file: BundleFile,
}

#[derive(Debug, Clone, Default)]
pub struct BundleUpdateCheckResult {
    pub cluster_id: i64,
    pub updates_available: Vec<BundlePackageUpdate>,
    pub removals_available: Vec<BundlePackageRemoval>,
    pub additions_available: Vec<BundlePackageAddition>,
    pub optional_available: Vec<BundleOptionalPackage>,
}

#[derive(Debug, Clone)]
pub struct BundleOptionalPackage {
    pub cluster_id: i64,
    pub bundle_name: String,
    pub package_id: String,
    pub file: BundleFile,
}

#[derive(Debug, Clone, Default)]
pub struct ApplyBundleUpdatesResult {
    pub updates_applied: Vec<BundlePackageUpdate>,
    pub removals_applied: Vec<BundlePackageRemoval>,
    pub additions_applied: Vec<BundlePackageAddition>,
    pub optional_available: Vec<BundleOptionalPackage>,
    pub updates_failed: Vec<String>,
    pub removals_failed: Vec<String>,
    pub additions_failed: Vec<String>,
    pub downloads_failed: Vec<String>,
    pub stopped_early: bool,
}

impl ApplyBundleUpdatesResult {
    #[must_use]
    pub fn settled(&self) -> bool {
        !self.stopped_early && self.failures().next().is_none()
    }

    pub fn failures(&self) -> impl Iterator<Item = &String> {
        self.updates_failed
            .iter()
            .chain(&self.additions_failed)
            .chain(&self.removals_failed)
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum FileUpdateStatus {
    NotInstalled,
    RemovedByUser,
    UpToDate,
    UpdateAvailable {
        installed_version_id: String,
        new_version_id: String,
    },
}

#[derive(Debug, Clone)]
pub struct BundleWithUpdateStatus {
    pub archive: BundleArchive,
    pub files: Vec<(BundleFile, FileUpdateStatus)>,
    pub has_updates: bool,
    pub opted_in_types: HashSet<ContentType>,
    pub taken: bool,
}
