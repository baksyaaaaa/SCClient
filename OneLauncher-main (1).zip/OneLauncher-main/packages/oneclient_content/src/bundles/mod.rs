mod error;
pub(crate) mod install;
mod manager;
mod manifest;
mod optional;
pub(crate) mod overrides;
pub(crate) mod polymrpack;
mod types;
mod updates;

pub use error::BundleError;
pub use install::{
    can_undo_artifact, clusters_sharing_artifact, clusters_sharing_global_folders, delete_artifact,
    detach_undo_artifacts, effective_enabled, enabled_bundle_bytes,
    enabled_bundle_projects, extract_bundle_overrides_for_cluster, heal_bundle_activity,
    inherit_bundle_choices, install_bundle, install_cluster_bundles, install_enabled_bundle_files,
    install_package_from_bundle, list_cluster_bundle_overrides, on_user_disable_artifact,
    on_user_enable_artifact, on_user_remove_artifact, pending_bundle_choices,
    remove_artifact_from_cluster, set_artifact_enabled_to, set_bundle_choices,
    set_bundle_package_enabled, set_bundle_package_opt_in, set_bundle_package_override,
    set_bundle_package_overrides, set_bundle_package_removed, taken_bundle_names,
    wanted_bundle_files,
};
pub use manager::{Bundle, BundlesManager};
pub use manifest::BundleManifest as RemoteBundleManifest;
pub use optional::{
    PendingOptionalMod, pending_optional_mods, resolve_optional_mods, skip_optional_mods,
};
pub use overrides::bundle_override_paths;
pub(crate) use updates::compare_version_like;
pub use types::{
    ApplyBundleUpdatesResult, BundleArchive, BundleFile, BundleFileKind, BundleFileType,
    BundleManifest, BundleOptionalPackage, BundlePackageAddition, BundlePackageRemoval,
    BundlePackageUpdate, BundleUpdateCheckResult, BundleWithUpdateStatus, FileUpdateStatus,
};
pub use updates::{
    BUNDLE_APPLY_BUDGET, Prefetches, apply_bundle_updates, apply_bundle_updates_with,
    check_bundle_updates, cluster_has_bundle_content, get_bundles_with_update_status,
};
