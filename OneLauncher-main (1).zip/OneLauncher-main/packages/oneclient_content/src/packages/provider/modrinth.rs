use std::collections::{HashMap, HashSet};
use std::str::FromStr;

use chrono::{DateTime, Utc};
use reqwest::Method;
use serde::Deserialize;
use url::Url;

use serde::de::DeserializeOwned;

use super::PackageProvider;
use super::http::fetch_json_with_headers;
use crate::ctx::ContentCtx;
use crate::error::ContentResult;
use crate::packages::file_identity::FileIdentity;
use crate::packages::types::{
    DependencyKind, GalleryImage, InstalledPackage, PackageBody, Page, ProjectDetail,
    ProjectMember, ProjectSummary, ReleaseType, SearchFilters, VersionDependency, VersionDetail,
    VersionFile, VersionLookup, VersionSummary,
};
use oneclient_common::constants::MODRINTH_API_URL;
use oneclient_common::domain::{ContentType, GameLoader, ProviderId};
use oneclient_net::{RequestClient, RequestError};

pub struct ModrinthProvider;

fn v2(path: &str) -> String {
    format!("{MODRINTH_API_URL}/v2{path}")
}

fn v3(path: &str) -> String {
    format!("{MODRINTH_API_URL}/v3{path}")
}

async fn fetch_json<T: DeserializeOwned>(
    client: &RequestClient,
    method: Method,
    url: impl reqwest::IntoUrl,
    body: Option<serde_json::Value>,
) -> Result<T, RequestError> {
    fetch_json_with_headers(
        client,
        method,
        url,
        body,
        &client.config().modrinth_headers(),
    )
    .await
}

#[async_trait::async_trait]
impl PackageProvider for ModrinthProvider {
    fn id(&self) -> ProviderId {
        ProviderId::Modrinth
    }

    #[tracing::instrument(level = "debug", skip(self, filters, ctx))]
    async fn search(
        &self,
        filters: &SearchFilters,
        ctx: &ContentCtx,
    ) -> ContentResult<Page<ProjectSummary>> {
        tracing::debug!(query = ?filters.query, "searching modrinth");
        let mut url = Url::parse(&v2("/search"))?;
        {
            let limit = filters
                .limit
                .unwrap_or(super::super::types::DEFAULT_PAGE_SIZE);

            let offset = filters.offset.unwrap_or(0);
            let mut params = url.query_pairs_mut();
            params.append_pair("limit", &limit.to_string());
            params.append_pair("offset", &offset.to_string());
            params.append_pair("query", &filters.normalized_query());

            let mut groups: Vec<Vec<String>> = Vec::new();
            if let Some(content_type) = filters.content_type {
                groups.push(vec![format!(
                    "project_type:{}",
                    content_type.modrinth_type()
                )]);
            }
            if let Some(versions) = &filters.game_versions {
                let group: Vec<String> = versions.iter().map(|v| format!("versions:{v}")).collect();
                if !group.is_empty() {
                    groups.push(group);
                }
            }
            if let Some(loaders) = &filters.loaders {
                let group: Vec<String> = loaders
                    .iter()
                    .map(|l| format!("categories:{}", l.modrinth_name()))
                    .collect();
                if !group.is_empty() {
                    groups.push(group);
                }
            }
            if let Some(categories) = &filters.categories {
                for category in categories {
                    groups.push(vec![format!("categories:{category}")]);
                }
            }
            if let Some(side) = filters.side {
                groups.push(side.modrinth_facets());
            }
            if !groups.is_empty() {
                params.append_pair(
                    "facets",
                    &serde_json::to_string(&groups).unwrap_or_default(),
                );
            }

            if let Some(sort) = filters.sort {
                params.append_pair("index", sort.modrinth_index());
            }
        }

        #[derive(Deserialize)]
        struct Response {
            hits: Vec<Hit>,
            offset: usize,
            limit: usize,
            total_hits: usize,
        }

        #[derive(Deserialize)]
        struct Hit {
            project_id: String,
            project_type: String,
            slug: String,
            author: String,
            title: String,
            description: String,
            #[serde(default)]
            categories: Vec<String>,
            #[serde(default, alias = "versions")]
            game_versions: Vec<String>,
            downloads: u64,
            icon_url: Option<String>,
            #[serde(default)]
            featured_gallery: Option<String>,
            #[serde(default)]
            gallery: Vec<String>,
            date_created: DateTime<Utc>,
            date_modified: DateTime<Utc>,
        }

        let response: Response = fetch_json(&ctx.net, Method::GET, url.as_str(), None).await?;

        Ok(Page {
            offset: response.offset,
            limit: response.limit,
            total: response.total_hits,
            items: response
                .hits
                .into_iter()
                .map(|h| ProjectSummary {
                    id: h.project_id,
                    slug: h.slug,
                    provider: ProviderId::Modrinth,
                    content_type: parse_content_type(&h.project_type),
                    name: h.title,
                    summary: h.description,
                    author: h.author,
                    icon_url: h.icon_url,
                    banner_url: h
                        .featured_gallery
                        .or_else(|| h.gallery.into_iter().next())
                        .filter(|url| !url.is_empty()),
                    downloads: h.downloads,
                    created: h.date_created,
                    updated: h.date_modified,
                    loaders: h
                        .categories
                        .iter()
                        .filter_map(|c| GameLoader::from_str(c).ok())
                        .collect(),
                    game_versions: h.game_versions,
                })
                .collect(),
        })
    }

    #[tracing::instrument(level = "debug", skip(self, ctx))]
    async fn get_project(
        &self,
        project_id: &str,
        ctx: &ContentCtx,
    ) -> ContentResult<ProjectDetail> {
        Ok(fetch_modrinth_project(&ctx.net, project_id).await?.0)
    }

    #[tracing::instrument(level = "debug", skip(self, ctx))]
    async fn get_project_with_body(
        &self,
        project_id: &str,
        ctx: &ContentCtx,
    ) -> ContentResult<ProjectDetail> {
        let (mut detail, org_id) = fetch_modrinth_project(&ctx.net, project_id).await?;
        if let Some(id) = org_id {
            let org = fetch_modrinth_organizations(&ctx.net, std::slice::from_ref(&id))
                .await
                .ok()
                .and_then(|mut orgs| orgs.remove(&id));
            apply_modrinth_organization(&mut detail, org);
        }
        Ok(detail)
    }

    #[tracing::instrument(level = "debug", skip(self, ctx))]
    async fn list_categories(
        &self,
        content_type: ContentType,
        ctx: &ContentCtx,
    ) -> ContentResult<Vec<String>> {
        #[derive(Deserialize)]
        struct Tag {
            name: String,
            project_type: String,
        }
        let tags: Vec<Tag> = fetch_json(&ctx.net, Method::GET, &v2("/tag/category"), None).await?;
        let want = match content_type {
            ContentType::DataPack => ContentType::Mod.modrinth_type(),
            other => other.modrinth_type(),
        };
        Ok(tags
            .into_iter()
            .filter(|t| t.project_type == want)
            .map(|t| t.name)
            .collect())
    }

    #[tracing::instrument(level = "debug", skip(self, project_ids, ctx))]
    async fn get_projects(
        &self,
        project_ids: &[String],
        ctx: &ContentCtx,
    ) -> ContentResult<Vec<ProjectDetail>> {
        if project_ids.is_empty() {
            return Ok(Vec::new());
        }
        let raw: Vec<ModrinthProject> = fetch_json(
            &ctx.net,
            Method::GET,
            &v2(&format!("/projects?ids={}", ids_param(project_ids))),
            None,
        )
        .await?;

        let team_ids: Vec<String> = raw
            .iter()
            .map(|p| p.team.clone())
            .collect::<HashSet<_>>()
            .into_iter()
            .collect();

        let org_ids: Vec<String> = raw
            .iter()
            .filter_map(|p| p.organization.clone())
            .collect::<HashSet<_>>()
            .into_iter()
            .collect();

        let (members_by_team, orgs) = tokio::join!(
            fetch_modrinth_team_members(&ctx.net, &team_ids),
            fetch_modrinth_organizations(&ctx.net, &org_ids),
        );
        let mut members_by_team = members_by_team.unwrap_or_default();
        let orgs = orgs.unwrap_or_default();

        Ok(raw
            .into_iter()
            .map(|project| {
                let team_id = project.team.clone();
                let org = project
                    .organization
                    .as_ref()
                    .and_then(|id| orgs.get(id))
                    .cloned();
                let mut detail = project.into_detail();
                if let Some(members) = members_by_team.remove(&team_id) {
                    apply_modrinth_members(&mut detail, members);
                }
                apply_modrinth_organization(&mut detail, org);
                detail
            })
            .collect())
    }

    #[tracing::instrument(level = "debug", skip(self, ctx))]
    async fn list_versions(
        &self,
        project_id: &str,
        game_version: Option<&str>,
        loader: Option<GameLoader>,
        offset: usize,
        limit: usize,
        ctx: &ContentCtx,
    ) -> ContentResult<Page<VersionSummary>> {
        let mut url = Url::parse(&v2(&format!("/project/{project_id}/version")))?;
        if let Some(v) = game_version {
            url.query_pairs_mut()
                .append_pair("game_versions", &format!("[\"{v}\"]"));
        }
        if let Some(loader) = loader {
            url.query_pairs_mut()
                .append_pair("loaders", &format!("[\"{}\"]", loader.modrinth_name()));
        }

        let versions: Vec<ModrinthVersion> =
            fetch_json(&ctx.net, Method::GET, url.as_str(), None).await?;

        let total = versions.len();
        let items = versions
            .into_iter()
            .skip(offset)
            .take(limit)
            .map(VersionSummary::from)
            .collect();

        Ok(Page {
            offset,
            limit,
            total,
            items,
        })
    }

    #[tracing::instrument(level = "debug", skip(self, _project_id, ctx))]
    async fn get_version(
        &self,
        _project_id: &str,
        version_id: &str,
        ctx: &ContentCtx,
    ) -> ContentResult<VersionDetail> {
        let raw: ModrinthVersion = fetch_json(
            &ctx.net,
            Method::GET,
            &v2(&format!("/version/{version_id}")),
            None,
        )
        .await?;
        Ok(raw.into())
    }

    #[tracing::instrument(level = "debug", skip(self, version_ids, ctx))]
    async fn get_versions(
        &self,
        version_ids: &[String],
        ctx: &ContentCtx,
    ) -> ContentResult<Vec<VersionDetail>> {
        if version_ids.is_empty() {
            return Ok(Vec::new());
        }
        let ids = version_ids
            .iter()
            .map(|id| format!("\"{id}\""))
            .collect::<Vec<_>>()
            .join(",");
        let raw: Vec<ModrinthVersion> = fetch_json(
            &ctx.net,
            Method::GET,
            &v2(&format!("/versions?ids=[{ids}]")),
            None,
        )
        .await?;
        Ok(raw.into_iter().map(Into::into).collect())
    }

    #[tracing::instrument(level = "debug", skip_all)]
    async fn lookup_versions(
        &self,
        identities: &[FileIdentity],
        ctx: &ContentCtx,
    ) -> ContentResult<VersionLookup> {
        let sha1_hashes: Vec<String> = identities
            .iter()
            .map(|id| id.sha1.clone())
            .collect::<HashSet<_>>()
            .into_iter()
            .collect();

        if sha1_hashes.is_empty() {
            return Ok(HashMap::new());
        }

        let body = serde_json::json!({
            "hashes": sha1_hashes,
            "algorithm": "sha1"
        });

        let fetched: HashMap<String, ModrinthVersion> =
            fetch_json(&ctx.net, Method::POST, &v2("/version_files"), Some(body)).await?;

        let mut out = HashMap::new();
        for identity in identities {
            if let Some(version) = fetched.get(&identity.sha1) {
                out.insert(identity.sha1.clone(), version.clone().into());
            }
        }

        Ok(out)
    }

    #[tracing::instrument(level = "debug", skip(self, packages, ctx))]
    async fn latest_for_game_version(
        &self,
        packages: &[InstalledPackage],
        mc_version: &str,
        loader: GameLoader,
        ctx: &ContentCtx,
    ) -> ContentResult<HashMap<String, VersionDetail>> {
        let mut groups: HashMap<ContentType, Vec<String>> = HashMap::new();
        for package in packages {
            groups
                .entry(package.content_type)
                .or_default()
                .push(package.hash.clone());
        }

        let mut out = HashMap::new();
        for (content_type, hashes) in groups {
            let loaders = modrinth_loader_filter(content_type, loader);

            let releases =
                latest_version_files(ctx, &hashes, mc_version, loaders.as_deref(), true).await?;
            let missing: Vec<String> = hashes
                .iter()
                .filter(|hash| !releases.contains_key(*hash))
                .cloned()
                .collect();
            out.extend(releases);

            if !missing.is_empty() {
                out.extend(
                    latest_version_files(ctx, &missing, mc_version, loaders.as_deref(), false)
                        .await?,
                );
            }
        }

        Ok(out)
    }
}

fn modrinth_loader_filter(content_type: ContentType, loader: GameLoader) -> Option<Vec<String>> {
    if content_type != ContentType::Mod || !loader.is_modded() {
        return None;
    }
    Some(
        [
            GameLoader::Forge,
            GameLoader::NeoForge,
            GameLoader::Quilt,
            GameLoader::Fabric,
            GameLoader::Ornithe,
        ]
        .into_iter()
        .filter(|other| loader.compatible_with(*other))
        .map(|other| other.modrinth_name().to_string())
        .collect(),
    )
}

async fn latest_version_files(
    ctx: &ContentCtx,
    hashes: &[String],
    mc_version: &str,
    loaders: Option<&[String]>,
    releases_only: bool,
) -> ContentResult<HashMap<String, VersionDetail>> {
    if hashes.is_empty() {
        return Ok(HashMap::new());
    }

    let mut body = serde_json::json!({
        "hashes": hashes,
        "algorithm": "sha1",
        "game_versions": [mc_version],
    });
    if let Some(loaders) = loaders {
        body["loaders"] = serde_json::json!(loaders);
    }
    if releases_only {
        body["version_types"] = serde_json::json!(["release"]);
    }

    let fetched: HashMap<String, ModrinthVersion> = fetch_json(
        &ctx.net,
        Method::POST,
        &v2("/version_files/update"),
        Some(body),
    )
    .await?;

    Ok(fetched
        .into_iter()
        .map(|(hash, version)| (polyio::normalize_hash(&hash), version.into()))
        .collect())
}

fn ids_param(ids: &[String]) -> String {
    let quoted = ids
        .iter()
        .map(|id| format!("\"{id}\""))
        .collect::<Vec<_>>()
        .join(",");
    format!("[{quoted}]")
}

async fn fetch_modrinth_project(
    client: &RequestClient,
    project_id: &str,
) -> ContentResult<(ProjectDetail, Option<String>)> {
    let project_url = v2(&format!("/project/{project_id}"));
    let members_url = v2(&format!("/project/{project_id}/members"));
    let project_fut = fetch_json::<ModrinthProject>(client, Method::GET, &project_url, None);
    let members_fut = fetch_json::<Vec<ModrinthMember>>(client, Method::GET, &members_url, None);
    let (raw, members) = tokio::join!(project_fut, members_fut);

    let mut raw = raw?;
    let org_id = raw.organization.take();
    let mut detail = raw.into_detail();
    if let Ok(members) = members {
        apply_modrinth_members(&mut detail, members);
    }
    Ok((detail, org_id))
}

#[tracing::instrument(level = "debug", skip(client, team_ids))]
async fn fetch_modrinth_team_members(
    client: &RequestClient,
    team_ids: &[String],
) -> Result<HashMap<String, Vec<ModrinthMember>>, RequestError> {
    if team_ids.is_empty() {
        return Ok(HashMap::new());
    }
    let teams: Vec<Vec<ModrinthMember>> = fetch_json(
        client,
        Method::GET,
        &v2(&format!("/teams?ids={}", ids_param(team_ids))),
        None,
    )
    .await?;
    Ok(teams
        .into_iter()
        .filter_map(|members| {
            let team_id = members.first()?.team_id.clone();
            Some((team_id, members))
        })
        .collect())
}

#[tracing::instrument(level = "debug", skip(client, org_ids))]
async fn fetch_modrinth_organizations(
    client: &RequestClient,
    org_ids: &[String],
) -> Result<HashMap<String, ProjectMember>, RequestError> {
    #[derive(Deserialize)]
    struct Organization {
        id: String,
        slug: String,
        name: String,
        #[serde(default)]
        icon_url: Option<String>,
    }

    if org_ids.is_empty() {
        return Ok(HashMap::new());
    }
    let orgs: Vec<Organization> = fetch_json(
        client,
        Method::GET,
        &v3(&format!("/organizations?ids={}", ids_param(org_ids))),
        None,
    )
    .await?;
    Ok(orgs
        .into_iter()
        .map(|org| {
            let member = ProjectMember {
                url: Some(format!("https://modrinth.com/organization/{}", org.slug)),
                name: org.name,
                role: "Organization".to_string(),
                avatar_url: org.icon_url,
            };
            (org.id, member)
        })
        .collect())
}

#[derive(Deserialize)]
struct ModrinthProject {
    id: String,
    slug: String,
    team: String,
    #[serde(default)]
    organization: Option<String>,
    project_type: String,
    title: String,
    description: String,
    body: Option<String>,
    body_url: Option<String>,
    #[serde(default)]
    game_versions: Vec<String>,
    #[serde(default)]
    loaders: Vec<String>,
    #[serde(default)]
    icon_url: Option<String>,
    published: DateTime<Utc>,
    updated: DateTime<Utc>,
    downloads: u64,
    license: Option<ModrinthLicense>,
    source_url: Option<String>,
    issues_url: Option<String>,
    wiki_url: Option<String>,
    discord_url: Option<String>,
    #[serde(default)]
    gallery: Vec<ModrinthGalleryItem>,
}

#[derive(Deserialize)]
struct ModrinthGalleryItem {
    url: String,
    /// Original upload
    /// `url` is Modrinth's re-encoded copy and looks soft when scaled up
    #[serde(default)]
    raw_url: Option<String>,
    #[serde(default)]
    title: Option<String>,
    #[serde(default)]
    featured: bool,
}

#[derive(Deserialize)]
struct ModrinthMember {
    #[serde(default)]
    team_id: String,
    role: String,
    user: ModrinthUser,
}

#[derive(Deserialize)]
struct ModrinthUser {
    username: String,
    #[serde(default)]
    avatar_url: Option<String>,
}

impl ModrinthMember {
    fn into_member(self) -> ProjectMember {
        ProjectMember {
            url: Some(format!("https://modrinth.com/user/{}", self.user.username)),
            name: self.user.username,
            role: self.role,
            avatar_url: self.user.avatar_url,
        }
    }
}

fn apply_modrinth_members(detail: &mut ProjectDetail, members: Vec<ModrinthMember>) {
    detail.members = members
        .into_iter()
        .map(ModrinthMember::into_member)
        .collect();
    if detail.author.is_empty() {
        detail.author = detail
            .members
            .iter()
            .find(|m| m.role.eq_ignore_ascii_case("owner"))
            .or_else(|| detail.members.first())
            .map(|m| m.name.clone())
            .unwrap_or_default();
    }
}

fn apply_modrinth_organization(detail: &mut ProjectDetail, org: Option<ProjectMember>) {
    let Some(org) = org else { return };
    if detail.author.is_empty() {
        detail.author = org.name.clone();
    }
    detail.members.insert(0, org);
}

#[derive(Deserialize)]
struct ModrinthLicense {
    #[serde(default)]
    name: Option<String>,
    id: Option<String>,
}

impl ModrinthProject {
    fn into_detail(self) -> ProjectDetail {
        let body = if let Some(raw) = self.body {
            PackageBody::raw(raw)
        } else if let Some(url) = self.body_url {
            PackageBody::Url(url)
        } else {
            PackageBody::Raw(String::new())
        };

        let license = self
            .license
            .and_then(|l| l.name.or(l.id))
            .filter(|s| !s.is_empty());

        let mut links = Vec::new();
        for (label, url) in [
            ("Source", self.source_url),
            ("Issues", self.issues_url),
            ("Wiki", self.wiki_url),
            ("Discord", self.discord_url),
        ] {
            if let Some(url) = url.filter(|u| !u.is_empty()) {
                links.push((label.to_string(), url));
            }
        }

        ProjectDetail {
            id: self.id.clone(),
            slug: self.slug,
            provider: ProviderId::Modrinth,
            content_type: parse_content_type(&self.project_type),
            name: self.title,
            summary: self.description,
            author: String::new(),
            members: Vec::new(),
            gallery: self
                .gallery
                .into_iter()
                .map(|g| {
                    let raw_url = g.raw_url.filter(|url| !url.is_empty());
                    GalleryImage {
                        thumbnail_url: raw_url.is_some().then(|| g.url.clone()),
                        url: raw_url.unwrap_or(g.url),
                        title: g.title.filter(|t| !t.is_empty()),
                        featured: g.featured,
                    }
                })
                .collect(),
            license,
            links,
            body,
            version_ids: Vec::new(),
            game_versions: self.game_versions,
            loaders: self
                .loaders
                .iter()
                .filter_map(|l| GameLoader::from_str(l).ok())
                .collect(),
            icon_url: self.icon_url,
            created: self.published,
            updated: self.updated,
            downloads: self.downloads,
        }
    }
}

#[derive(Clone, Deserialize)]
struct ModrinthVersion {
    id: String,
    project_id: String,
    name: String,
    version_number: String,
    changelog: Option<String>,
    game_versions: Vec<String>,
    loaders: Vec<String>,
    date_published: DateTime<Utc>,
    downloads: u64,
    #[serde(default)]
    files: Vec<ModrinthFile>,
    #[serde(default)]
    version_type: String,
    #[serde(default)]
    dependencies: Vec<ModrinthDependency>,
}

#[derive(Clone, Deserialize)]
struct ModrinthDependency {
    #[serde(default)]
    project_id: Option<String>,
    #[serde(default)]
    version_id: Option<String>,
    #[serde(default)]
    dependency_type: String,
}

impl From<ModrinthDependency> for VersionDependency {
    fn from(d: ModrinthDependency) -> Self {
        Self {
            project_id: d.project_id.filter(|id| !id.is_empty()),
            version_id: d.version_id.filter(|id| !id.is_empty()),
            kind: match d.dependency_type.as_str() {
                "required" => DependencyKind::Required,
                "incompatible" => DependencyKind::Incompatible,
                "embedded" => DependencyKind::Embedded,
                _ => DependencyKind::Optional,
            },
        }
    }
}

#[derive(Clone, Deserialize)]
struct ModrinthFile {
    hashes: ModrinthHashes,
    url: String,
    filename: String,
    #[serde(default)]
    primary: bool,
    #[serde(default)]
    size: u64,
}

#[derive(Clone, Deserialize)]
struct ModrinthHashes {
    sha1: String,
}

impl From<ModrinthVersion> for VersionDetail {
    fn from(v: ModrinthVersion) -> Self {
        Self {
            version_id: v.id,
            project_id: v.project_id,
            name: v.name.clone(),
            version_number: v.version_number,
            changelog: v.changelog,
            game_versions: v.game_versions,
            loaders: v
                .loaders
                .iter()
                .filter_map(|l| GameLoader::from_str(l).ok())
                .collect(),
            published: v.date_published,
            downloads: v.downloads,
            files: v.files.into_iter().map(Into::into).collect(),
            dependencies: v.dependencies.into_iter().map(Into::into).collect(),
        }
    }
}

impl From<ModrinthVersion> for VersionSummary {
    fn from(v: ModrinthVersion) -> Self {
        let file_size = v
            .files
            .iter()
            .find(|f| f.primary)
            .or_else(|| v.files.first())
            .map(|f| f.size)
            .unwrap_or(0);
        VersionSummary {
            version_id: v.id,
            project_id: v.project_id,
            name: v.name,
            version_number: v.version_number,
            published: v.date_published,
            release_type: parse_release_type(&v.version_type),
            game_versions: v.game_versions,
            loaders: v
                .loaders
                .iter()
                .filter_map(|l| GameLoader::from_str(l).ok())
                .collect(),
            downloads: v.downloads,
            file_size,
            dependencies: v.dependencies.into_iter().map(Into::into).collect(),
            blocked: false,
        }
    }
}

impl From<ModrinthFile> for VersionFile {
    fn from(f: ModrinthFile) -> Self {
        Self {
            sha1: f.hashes.sha1,
            url: f.url,
            file_name: f.filename,
            primary: f.primary,
            size: f.size,
            fingerprint: None,
        }
    }
}

fn parse_content_type(s: &str) -> ContentType {
    match s {
        "mod" => ContentType::Mod,
        "resourcepack" => ContentType::ResourcePack,
        "shader" => ContentType::Shader,
        "datapack" => ContentType::DataPack,
        "modpack" => ContentType::Modpack,
        _ => ContentType::Mod,
    }
}

fn parse_release_type(s: &str) -> ReleaseType {
    match s {
        "beta" => ReleaseType::Beta,
        "alpha" => ReleaseType::Alpha,
        _ => ReleaseType::Release,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// A field rename here silently empties the dependency list
    #[test]
    fn version_carries_its_dependencies() {
        let raw = serde_json::json!({
            "id": "abc",
            "project_id": "sodium",
            "name": "Sodium 0.6",
            "version_number": "0.6",
            "changelog": null,
            "game_versions": ["1.21.4"],
            "loaders": ["fabric"],
            "date_published": "2025-01-01T00:00:00Z",
            "downloads": 10,
            "version_type": "release",
            "files": [],
            "dependencies": [
                {"project_id": "fabric-api", "version_id": null, "dependency_type": "required"},
                {"project_id": null, "version_id": "pinned", "dependency_type": "required"},
                {"project_id": "sodium-extra", "version_id": null, "dependency_type": "optional"},
                {"project_id": "optifine", "version_id": null, "dependency_type": "incompatible"},
            ],
        });

        let version: VersionDetail = serde_json::from_value::<ModrinthVersion>(raw)
            .expect("modrinth version")
            .into();

        assert_eq!(version.dependencies.len(), 4);
        assert_eq!(
            version.dependencies[0],
            VersionDependency {
                project_id: Some("fabric-api".into()),
                version_id: None,
                kind: DependencyKind::Required,
            }
        );
        assert_eq!(
            version.dependencies[1],
            VersionDependency {
                project_id: None,
                version_id: Some("pinned".into()),
                kind: DependencyKind::Required,
            }
        );
        assert_eq!(version.dependencies[2].kind, DependencyKind::Optional);
        assert_eq!(version.dependencies[3].kind, DependencyKind::Incompatible);
    }
}
