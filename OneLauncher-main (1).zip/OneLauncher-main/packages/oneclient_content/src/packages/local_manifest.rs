use std::collections::BTreeMap;
use std::path::Path;

use oneclient_common::domain::GameLoader;
use serde::Deserialize;

const MAX_DESCRIPTION: usize = 600;
const MAX_DESCRIPTION_WINDOW: usize = MAX_DESCRIPTION * 8;

const FABRIC: &str = "fabric.mod.json";
const QUILT: &str = "quilt.mod.json";
const NEOFORGE: &str = "META-INF/neoforge.mods.toml";
const FORGE: &str = "META-INF/mods.toml";
const LEGACY_FORGE: &str = "mcmod.info";

const MANIFESTS: [&str; 5] = [FABRIC, QUILT, NEOFORGE, FORGE, LEGACY_FORGE];

#[derive(Debug, Default, Clone, PartialEq, Eq)]
pub struct JarManifest {
    pub name: Option<String>,
    pub description: Option<String>,
    pub authors: Vec<String>,
    pub icon_entry: Option<String>,
    pub mod_id: Option<String>,
    pub version: Option<String>,
}

impl JarManifest {
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.name.is_none()
            && self.description.is_none()
            && self.authors.is_empty()
            && self.icon_entry.is_none()
    }

    #[must_use]
    pub fn author_line(&self) -> String {
        self.authors.join(", ")
    }

    fn fill_from(&mut self, other: Self) {
        if self.name.is_none() {
            self.name = other.name;
        }
        if self.description.is_none() {
            self.description = other.description;
        }
        if self.authors.is_empty() {
            self.authors = other.authors;
        }
        if self.icon_entry.is_none() {
            self.icon_entry = other.icon_entry;
        }
        if self.mod_id.is_none() {
            self.mod_id = other.mod_id;
        }
        if self.version.is_none() {
            self.version = other.version;
        }
    }
}

#[tracing::instrument(level = "debug", fields(jar = %jar.display()))]
pub async fn read_jar_manifest(jar: &Path) -> JarManifest {
    let entries = match polyio::read_zip_file_entries(jar, |name| MANIFESTS.contains(&name)).await {
        Ok(entries) => entries,
        Err(err) => {
            tracing::debug!("could not read {}: {err}", jar.display());
            return JarManifest::default();
        }
    };

    let mut out = JarManifest::default();
    for wanted in MANIFESTS {
        let Some((_, bytes)) = entries.iter().find(|(name, _)| name == wanted) else {
            continue;
        };
        let Ok(text) = std::str::from_utf8(bytes) else {
            continue;
        };

        let parsed = match wanted {
            FABRIC => parse_fabric(text),
            QUILT => parse_quilt(text),
            NEOFORGE | FORGE => parse_forge(text),
            _ => parse_legacy_forge(text),
        };

        match parsed {
            Some(parsed) => out.fill_from(parsed),
            None => tracing::debug!("{wanted} in {} did not parse", jar.display()),
        }
    }

    out
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct JarModId {
    pub id: String,
    pub version: Option<String>,
}

#[tracing::instrument(level = "debug", fields(jar = %jar.display()))]
pub async fn read_jar_mod_id(jar: &Path) -> Option<JarModId> {
    let entries = polyio::read_zip_file_entries(jar, |name| MANIFESTS.contains(&name))
        .await
        .inspect_err(|err| tracing::debug!("could not read {}: {err}", jar.display()))
        .ok()?;

    MANIFESTS.into_iter().find_map(|wanted| {
        let (_, bytes) = entries.iter().find(|(name, _)| name == wanted)?;
        parse_mod(wanted, std::str::from_utf8(bytes).ok()?)
    })
}

const MAX_BUNDLED_JARS: usize = 64;

#[tracing::instrument(level = "debug", fields(jar = %jar.display()))]
pub async fn read_jar_bundled_mod_ids(jar: &Path) -> Vec<JarModId> {
    let Ok(entries) = polyio::read_zip_file_entries(jar, |name| name == FABRIC).await else {
        return Vec::new();
    };

    let Some(json) = entries
        .first()
        .and_then(|(_, bytes)| serde_json::from_slice::<serde_json::Value>(bytes).ok())
    else {
        return Vec::new();
    };

    let bundled: Vec<String> = json
        .pointer("/jars")
        .and_then(serde_json::Value::as_array)
        .map(|jars| {
            jars.iter()
                .filter_map(|entry| entry.get("file")?.as_str().map(str::to_owned))
                .take(MAX_BUNDLED_JARS)
                .collect()
        })
        .unwrap_or_default();

    if bundled.is_empty() {
        return Vec::new();
    }

    let Ok(mut cursor) =
        polyio::ZipEntryCursor::open(jar, |name| bundled.iter().any(|file| file == name)).await
    else {
        return Vec::new();
    };

    let mut found = Vec::new();
    for file in &bundled {
        let Ok(bytes) = cursor.read(file).await else {
            continue;
        };
        let Ok(manifest) =
            polyio::try_read_zip_entry_bytes(std::io::Cursor::new(bytes), FABRIC).await
        else {
            continue;
        };

        if let Some(id) = std::str::from_utf8(&manifest)
            .ok()
            .and_then(|text| parse_mod(FABRIC, text))
        {
            found.push(id);
        }
    }

    found
}

fn parse_mod(manifest: &str, text: &str) -> Option<JarModId> {
    let (id, version) = match manifest {
        NEOFORGE | FORGE => {
            let id = toml::from_str::<toml::Value>(text)
                .ok()?
                .get("mods")?
                .get(0)?
                .get("modId")?
                .as_str()?
                .to_owned();
            (id, None)
        }
        _ => {
            let json: serde_json::Value = serde_json::from_str(text).ok()?;
            let pointers: &[&str] = match manifest {
                FABRIC => &["/id"],
                QUILT => &["/quilt_loader/id"],
                _ => &["/0/modid", "/modList/0/modid"],
            };
            let id = pointers
                .iter()
                .find_map(|pointer| json.pointer(pointer)?.as_str())?
                .to_owned();
            let version = (manifest == FABRIC)
                .then(|| json.pointer("/version")?.as_str().map(str::to_owned))
                .flatten();
            (id, version)
        }
    };

    Some(JarModId {
        id: clean(Some(id)).filter(|id| !is_placeholder_id(id))?,
        version: clean(version).filter(|version| !version.contains('$')),
    })
}

fn is_placeholder_id(id: &str) -> bool {
    id.contains('$') || id.eq_ignore_ascii_case("examplemod")
}

#[tracing::instrument(level = "debug", fields(jar = %jar.display()))]
pub async fn read_jar_loader(jar: &Path) -> Option<GameLoader> {
    let entries = polyio::read_zip_file_entries(jar, |name| MANIFESTS.contains(&name))
        .await
        .inspect_err(|err| tracing::debug!("could not read {}: {err}", jar.display()))
        .ok()?;
    let has = |wanted: &str| entries.iter().any(|(name, _)| name == wanted);

    let fabric_family = has(FABRIC) || has(QUILT);
    let forge_family = has(FORGE) || has(LEGACY_FORGE) || has(NEOFORGE);
    if fabric_family && forge_family {
        return None;
    }

    [
        (FABRIC, GameLoader::Fabric),
        (QUILT, GameLoader::Quilt),
        (FORGE, GameLoader::Forge),
        (LEGACY_FORGE, GameLoader::Forge),
        (NEOFORGE, GameLoader::NeoForge),
    ]
    .into_iter()
    .find(|(wanted, _)| has(wanted))
    .map(|(_, loader)| loader)
}

#[tracing::instrument(level = "debug", fields(jar = %jar.display()))]
pub async fn read_jar_icon(jar: &Path, entry: &str) -> Option<Vec<u8>> {
    let entry = entry.to_string();
    let found = polyio::read_zip_file_entries(jar, |name| name == entry)
        .await
        .inspect_err(|err| tracing::debug!("no icon in {}: {err}", jar.display()))
        .ok()?;

    found.into_iter().next().map(|(_, bytes)| bytes)
}

#[must_use]
pub fn parse_fabric(text: &str) -> Option<JarManifest> {
    #[derive(Deserialize)]
    struct FabricMod {
        id: Option<String>,
        version: Option<String>,
        name: Option<String>,
        description: Option<String>,
        #[serde(default)]
        authors: Vec<serde_json::Value>,
        icon: Option<Icon>,
    }

    let parsed: FabricMod = serde_json::from_str(text).ok()?;

    Some(JarManifest {
        name: clean(parsed.name),
        description: clean_description(parsed.description),
        authors: people(parsed.authors),
        icon_entry: parsed.icon.and_then(Icon::path).and_then(entry_path),
        mod_id: clean(parsed.id),
        version: real_version(parsed.version),
    })
}

#[must_use]
pub fn parse_quilt(text: &str) -> Option<JarManifest> {
    #[derive(Deserialize)]
    struct QuiltMod {
        quilt_loader: QuiltLoader,
    }

    #[derive(Deserialize)]
    struct QuiltLoader {
        id: Option<String>,
        version: Option<String>,
        metadata: Option<QuiltMetadata>,
    }

    #[derive(Deserialize, Default)]
    struct QuiltMetadata {
        name: Option<String>,
        description: Option<String>,
        #[serde(default)]
        contributors: BTreeMap<String, serde_json::Value>,
        icon: Option<Icon>,
    }

    let parsed: QuiltMod = serde_json::from_str(text).ok()?;
    let mod_id = clean(parsed.quilt_loader.id);
    let version = real_version(parsed.quilt_loader.version);
    let metadata = parsed.quilt_loader.metadata.unwrap_or_default();

    Some(JarManifest {
        name: clean(metadata.name),
        description: clean_description(metadata.description),
        authors: metadata
            .contributors
            .into_keys()
            .filter_map(|name| clean(Some(name)))
            .collect(),
        icon_entry: metadata.icon.and_then(Icon::path).and_then(entry_path),
        mod_id,
        version,
    })
}

#[must_use]
pub fn parse_forge(text: &str) -> Option<JarManifest> {
    #[derive(Deserialize)]
    struct ForgeManifest {
        #[serde(default)]
        mods: Vec<ForgeMod>,
        /// Some older jars put it above the mod list rather than inside it
        #[serde(rename = "logoFile")]
        logo_file: Option<String>,
    }

    #[derive(Deserialize)]
    struct ForgeMod {
        #[serde(rename = "modId")]
        mod_id: Option<String>,
        version: Option<String>,
        #[serde(rename = "displayName")]
        display_name: Option<String>,
        description: Option<String>,
        authors: Option<StringOrList>,
        credits: Option<StringOrList>,
        #[serde(rename = "logoFile")]
        logo_file: Option<String>,
    }

    let parsed: ForgeManifest = toml::from_str(text).ok()?;
    let first = parsed.mods.into_iter().next()?;

    Some(JarManifest {
        name: clean(first.display_name),
        description: clean_description(first.description),
        authors: first
            .authors
            .or(first.credits)
            .map(StringOrList::into_people)
            .unwrap_or_default(),
        icon_entry: first.logo_file.or(parsed.logo_file).and_then(entry_path),
        mod_id: clean(first.mod_id),
        version: real_version(first.version),
    })
}

#[must_use]
pub fn parse_legacy_forge(text: &str) -> Option<JarManifest> {
    #[derive(Deserialize)]
    #[serde(untagged)]
    enum McModInfo {
        Bare(Vec<LegacyMod>),
        Wrapped {
            #[serde(rename = "modList")]
            mod_list: Vec<LegacyMod>,
        },
    }

    #[derive(Deserialize)]
    struct LegacyMod {
        modid: Option<String>,
        version: Option<String>,
        name: Option<String>,
        description: Option<String>,
        #[serde(rename = "authorList", default)]
        author_list: Vec<String>,
        credits: Option<String>,
        #[serde(rename = "logoFile")]
        logo_file: Option<String>,
    }

    let mods = match serde_json::from_str::<McModInfo>(text).ok()? {
        McModInfo::Bare(mods) | McModInfo::Wrapped { mod_list: mods } => mods,
    };
    let first = mods.into_iter().next()?;

    let authors: Vec<String> = first
        .author_list
        .into_iter()
        .filter_map(|name| clean(Some(name)))
        .collect();

    Some(JarManifest {
        name: clean(first.name),
        description: clean_description(first.description),
        authors: if authors.is_empty() {
            clean(first.credits).into_iter().collect()
        } else {
            authors
        },
        icon_entry: first.logo_file.and_then(entry_path),
        mod_id: clean(first.modid),
        version: real_version(first.version),
    })
}

#[derive(Deserialize)]
#[serde(untagged)]
enum Icon {
    Path(String),
    Sizes(BTreeMap<String, String>),
}

impl Icon {
    fn path(self) -> Option<String> {
        match self {
            Self::Path(path) => Some(path),
            Self::Sizes(sizes) => sizes
                .into_iter()
                .max_by_key(|(size, _)| size.parse::<u32>().unwrap_or(0))
                .map(|(_, path)| path),
        }
    }
}

fn people(list: Vec<serde_json::Value>) -> Vec<String> {
    list.into_iter()
        .filter_map(|person| match person {
            serde_json::Value::String(name) => clean(Some(name)),
            serde_json::Value::Object(mut fields) => match fields.remove("name") {
                Some(serde_json::Value::String(name)) => clean(Some(name)),
                _ => None,
            },
            _ => None,
        })
        .collect()
}

#[derive(Deserialize)]
#[serde(untagged)]
enum StringOrList {
    One(String),
    Many(Vec<String>),
}

impl StringOrList {
    fn into_people(self) -> Vec<String> {
        match self {
            Self::One(text) => clean(Some(text)).into_iter().collect(),
            Self::Many(list) => list
                .into_iter()
                .filter_map(|name| clean(Some(name)))
                .collect(),
        }
    }
}

fn real_version(value: Option<String>) -> Option<String> {
    clean(value).filter(|version| !version.contains("${"))
}

fn clean(value: Option<String>) -> Option<String> {
    let value = value?.trim().to_string();
    (!value.is_empty()).then_some(value)
}

fn clean_description(value: Option<String>) -> Option<String> {
    let raw = clean(value)?;

    // Collapsing whitespace only shortens so a window this wide still holds
    // words to spare and a megabyte long blurb is never copied whole
    let end = raw
        .char_indices()
        .nth(MAX_DESCRIPTION_WINDOW)
        .map_or(raw.len(), |(idx, _)| idx);

    let mut text = raw[..end].split_whitespace().collect::<Vec<_>>().join(" ");
    if text.is_empty() {
        return None;
    }

    if text.chars().count() > MAX_DESCRIPTION {
        let cut = text
            .char_indices()
            .nth(MAX_DESCRIPTION)
            .map_or(text.len(), |(idx, _)| idx);
        text.truncate(cut);
        text.push('…');
    } else if end < raw.len() {
        text.push('…');
    }

    Some(text)
}

fn entry_path(raw: String) -> Option<String> {
    let path = raw
        .trim()
        .replace('\\', "/")
        .trim_start_matches('/')
        .trim_start_matches("./")
        .to_string();

    if path.is_empty() || path.split('/').any(|part| part == "..") {
        return None;
    }

    Some(path)
}

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct JarDependencies {
    /// The jar's own mod ids
    pub provides: Vec<String>,
    /// Ids of the libraries nested inside it several jars often bundle the same one
    pub bundled: Vec<String>,
    pub requires: Vec<String>,
}

const NESTED_JAR_DIRS: [&str; 2] = ["META-INF/jars/", "META-INF/jarjar/"];

fn is_nested_jar(name: &str) -> bool {
    name.ends_with(".jar") && NESTED_JAR_DIRS.iter().any(|dir| name.starts_with(dir))
}

#[tracing::instrument(level = "debug", fields(jar = %jar.display()))]
pub async fn read_jar_dependencies(jar: &Path) -> JarDependencies {
    read_dependencies(jar, false).await.unwrap_or_default()
}

/// Returns no dependency proof when nested jars or unfamiliar metadata could
/// declare additional requirements or mod IDs.
pub(crate) async fn verified_jar_dependencies(jar: &Path) -> Option<JarDependencies> {
    read_dependencies(jar, true).await
}

async fn read_dependencies(jar: &Path, verify: bool) -> Option<JarDependencies> {
    const JARJAR_METADATA: &str = "META-INF/jarjar/metadata.json";
    let entries = match polyio::read_zip_file_entries(jar, |name| {
        MANIFESTS.contains(&name) || is_nested_jar(name) || (verify && name == JARJAR_METADATA)
    })
    .await
    {
        Ok(entries) => entries,
        Err(err) => {
            tracing::debug!("could not read {}: {err}", jar.display());
            return None;
        }
    };

    let mut out = JarDependencies::default();
    for (name, bytes) in &entries {
        if is_nested_jar(name) || name == JARJAR_METADATA {
            if verify {
                return None;
            }
            out.bundled.extend(nested_provides(bytes).await);
            continue;
        }
        if verify {
            let text = std::str::from_utf8(bytes).ok()?;
            if !manifest_can_verify_dependencies(name, text) {
                return None;
            }
        }
        let Ok(text) = std::str::from_utf8(bytes) else {
            continue;
        };
        if let Some(parsed) = parse_dependencies(name, text) {
            out.provides.extend(parsed.provides);
            out.requires.extend(parsed.requires);
        } else if verify {
            return None;
        }
    }

    out.provides.sort();
    out.provides.dedup();
    out.bundled.sort();
    out.bundled.dedup();
    out.bundled
        .retain(|id| out.provides.binary_search(id).is_err());
    out.requires.sort();
    out.requires.dedup();
    out.requires.retain(|id| {
        out.provides.binary_search(id).is_err() && out.bundled.binary_search(id).is_err()
    });
    Some(out)
}

fn manifest_can_verify_dependencies(name: &str, text: &str) -> bool {
    fn no_declared_jars(value: &serde_json::Value) -> bool {
        value
            .get("jars")
            .is_none_or(|jars| jars.as_array().is_some_and(Vec::is_empty))
    }

    match name {
        FABRIC => serde_json::from_str::<serde_json::Value>(text).is_ok_and(|value| {
            no_declared_jars(&value)
                && value.get("requires").is_none()
                && value
                    .get("depends")
                    .is_none_or(serde_json::Value::is_object)
        }),
        QUILT => serde_json::from_str::<serde_json::Value>(text).is_ok_and(|value| {
            no_declared_jars(&value)
                && value.get("quilt_loader").is_some_and(|loader| {
                    no_declared_jars(loader)
                        && ["depends", "provides"].into_iter().all(|key| {
                            loader.get(key).is_none_or(|entries| {
                                entries.as_array().is_some_and(|entries| {
                                    entries.iter().all(|entry| {
                                        // Group-qualified IDs and dependency
                                        // alternatives require more than a literal ID.
                                        quilt_id(entry)
                                            .is_some_and(|id| !id.is_empty() && !id.contains(':'))
                                            && entry.get("group").is_none()
                                            && entry
                                                .get("optional")
                                                .is_none_or(serde_json::Value::is_boolean)
                                    })
                                })
                            })
                        })
                })
        }),
        LEGACY_FORGE => false,
        _ => true,
    }
}

async fn nested_provides(bytes: &[u8]) -> Vec<String> {
    let mut ids = Vec::new();
    for wanted in MANIFESTS {
        let Ok(data) = polyio::try_read_zip_entry_bytes(std::io::Cursor::new(bytes), wanted).await
        else {
            continue;
        };
        let Ok(text) = std::str::from_utf8(&data) else {
            continue;
        };
        if let Some(parsed) = parse_dependencies(wanted, text) {
            ids.extend(parsed.provides);
        }
    }
    ids
}

fn parse_dependencies(manifest: &str, text: &str) -> Option<JarDependencies> {
    let (provides, requires) = match manifest {
        FABRIC => {
            let json: serde_json::Value = serde_json::from_str(text).ok()?;
            let provides = json
                .get("id")
                .into_iter()
                .chain(
                    json.get("provides")
                        .and_then(|v| v.as_array())
                        .into_iter()
                        .flatten(),
                )
                .filter_map(|v| v.as_str().map(str::to_owned))
                .collect();
            let requires = json
                .get("depends")
                .and_then(|v| v.as_object())
                .map(|map| map.keys().cloned().collect())
                .unwrap_or_default();
            (provides, requires)
        }
        QUILT => {
            let json: serde_json::Value = serde_json::from_str(text).ok()?;
            let loader = json.get("quilt_loader")?;
            let provides = loader
                .get("id")
                .and_then(|v| v.as_str())
                .map(str::to_owned)
                .into_iter()
                .chain(
                    loader
                        .get("provides")
                        .and_then(|v| v.as_array())
                        .into_iter()
                        .flatten()
                        .filter_map(quilt_id),
                )
                .collect();
            let requires = loader
                .get("depends")
                .and_then(|v| v.as_array())
                .into_iter()
                .flatten()
                .filter(|dep| dep.get("optional").and_then(|v| v.as_bool()) != Some(true))
                .filter_map(quilt_id)
                .collect();
            (provides, requires)
        }
        NEOFORGE | FORGE => {
            let toml: toml::Value = toml::from_str(text).ok()?;
            let provides = toml
                .get("mods")
                .and_then(|v| v.as_array())
                .into_iter()
                .flatten()
                .filter_map(|m| m.get("modId")?.as_str().map(str::to_owned))
                .collect();
            let requires = toml
                .get("dependencies")
                .and_then(|v| v.as_table())
                .into_iter()
                .flat_map(|table| table.values())
                .filter_map(|v| v.as_array())
                .flatten()
                .filter(|dep| forge_required(dep))
                .filter_map(|dep| dep.get("modId")?.as_str().map(str::to_owned))
                .collect();
            (provides, requires)
        }
        LEGACY_FORGE => {
            let json: serde_json::Value = serde_json::from_str(text).ok()?;
            let mods = json
                .as_array()
                .or_else(|| json.get("modList")?.as_array())?;
            let provides = mods
                .iter()
                .filter_map(|m| m.get("modid")?.as_str().map(str::to_owned))
                .collect();
            let requires = mods
                .iter()
                .filter_map(|m| m.get("requiredMods")?.as_array())
                .flatten()
                .filter_map(|v| v.as_str())
                .map(|spec| spec.split('@').next().unwrap_or(spec).to_owned())
                .collect();
            (provides, requires)
        }
        _ => return None,
    };

    Some(JarDependencies {
        provides: normalize_ids(provides),
        bundled: Vec::new(),
        requires: normalize_ids(requires),
    })
}

fn quilt_id(value: &serde_json::Value) -> Option<String> {
    match value {
        serde_json::Value::String(id) => Some(id.clone()),
        other => other.get("id")?.as_str().map(str::to_owned),
    }
}

fn forge_required(dep: &toml::Value) -> bool {
    match dep.get("type").and_then(|v| v.as_str()) {
        Some(kind) => kind.eq_ignore_ascii_case("required"),
        None => dep.get("mandatory").and_then(|v| v.as_bool()) == Some(true),
    }
}

fn normalize_ids(ids: Vec<String>) -> Vec<String> {
    ids.into_iter()
        .map(|id| id.trim().to_ascii_lowercase())
        .filter(|id| !id.is_empty() && !is_placeholder_id(id))
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn parse_mod_id(manifest: &str, text: &str) -> Option<String> {
        parse_mod(manifest, text).map(|parsed| parsed.id)
    }

    fn parse_mod_version(manifest: &str, text: &str) -> Option<String> {
        parse_mod(manifest, text)?.version
    }

    #[tokio::test]
    async fn a_fabric_jar_outside_standard_prefixes_is_unverified() {
        let dir = polyio::testing::ScratchDir::new("undo_external_embedded_jar");
        let jar = dir.path().join("outer.jar");
        polyio::create_dir_all(dir.path()).await.unwrap();
        let file = tokio::fs::File::create(&jar).await.unwrap();
        let mut writer = async_zip::tokio::write::ZipFileWriter::with_tokio(file);
        for (name, bytes) in [
            (
                FABRIC,
                br#"{"id":"outer", "jars":[{"file":"assets/extra.jar"}]}"#.as_slice(),
            ),
            ("assets/extra.jar", b"opaque nested jar".as_slice()),
        ] {
            let entry =
                async_zip::ZipEntryBuilder::new(name.into(), async_zip::Compression::Stored);
            writer.write_entry_whole(entry, bytes).await.unwrap();
        }
        writer.close().await.unwrap();

        assert_eq!(read_jar_dependencies(&jar).await.provides, ["outer"]);
        assert!(verified_jar_dependencies(&jar).await.is_none());
    }

    #[test]
    fn quilt_grouped_ids_and_alternatives_are_not_literal_id_proof() {
        assert!(manifest_can_verify_dependencies(
            QUILT,
            r#"{"quilt_loader":{"id":"outer","depends":[{"id":"plain","versions":"*"}]}}"#,
        ));
        for depends in [
            r#"["org.example:library"]"#,
            r#"[{"group":"org.example","id":"library"}]"#,
            r#"[["alternative-a","alternative-b"]]"#,
        ] {
            let manifest = format!(r#"{{"quilt_loader":{{"id":"outer","depends":{depends}}}}}"#);
            assert!(!manifest_can_verify_dependencies(QUILT, &manifest));
        }
    }

    #[test]
    fn every_loader_names_its_mod_id() {
        assert_eq!(
            parse_mod_id(FABRIC, r#"{"id":"argentum","name":"Argentum"}"#).as_deref(),
            Some("argentum")
        );
        assert_eq!(
            parse_mod_id(QUILT, r#"{"quilt_loader":{"id":"qsl"}}"#).as_deref(),
            Some("qsl")
        );
        assert_eq!(
            parse_mod_id(FORGE, "[[mods]]\nmodId = \"jei\"\n").as_deref(),
            Some("jei")
        );
        assert_eq!(
            parse_mod_id(LEGACY_FORGE, r#"[{"modid":"patcher"}]"#).as_deref(),
            Some("patcher")
        );
        assert_eq!(
            parse_mod_id(LEGACY_FORGE, r#"{"modList":[{"modid":"oneconfig"}]}"#).as_deref(),
            Some("oneconfig")
        );
        assert_eq!(parse_mod_id(FABRIC, r#"{"id":"  "}"#), None);

        assert_eq!(
            parse_mod_version(FABRIC, r#"{"id":"fabric-api","version":"0.141.6+1.21.11"}"#)
                .as_deref(),
            Some("0.141.6+1.21.11")
        );
        assert_eq!(
            parse_mod_version(QUILT, r#"{"quilt_loader":{"id":"qsl","version":"1.2.3"}}"#),
            None
        );
        assert_eq!(
            parse_mod_version(FABRIC, r#"{"id":"a","version":"${version}"}"#),
            None
        );
        assert_eq!(
            parse_mod_version(FORGE, "[[mods]]\nmodId = \"jei\"\nversion = \"1\"\n"),
            None
        );
        assert_eq!(
            parse_mod_id(LEGACY_FORGE, r#"[{"modid":"examplemod"}]"#),
            None
        );
        assert_eq!(
            parse_mod_id(LEGACY_FORGE, r#"[{"modid":"${modid}"}]"#),
            None
        );
    }

    #[test]
    fn fabric_reads_every_field() {
        let parsed = parse_fabric(
            r#"{
				"schemaVersion": 1,
				"id": "sodium",
				"name": "Sodium",
				"description": "A modern\n  rendering engine",
				"authors": ["JellySquid", {"name": "Someone", "contact": {}}],
				"icon": "assets/sodium/icon.png"
			}"#,
        )
        .expect("valid fabric manifest");

        assert_eq!(parsed.name.as_deref(), Some("Sodium"));
        assert_eq!(
            parsed.description.as_deref(),
            Some("A modern rendering engine"),
            "hard wrapping collapses so the card lays out its own lines"
        );
        assert_eq!(parsed.author_line(), "JellySquid, Someone");
        assert_eq!(parsed.icon_entry.as_deref(), Some("assets/sodium/icon.png"));
    }

    #[test]
    fn fabric_icon_map_takes_the_largest() {
        let parsed = parse_fabric(
            r#"{"id": "x", "icon": {"32": "small.png", "128": "big.png", "64": "mid.png"}}"#,
        )
        .expect("valid fabric manifest");

        assert_eq!(parsed.icon_entry.as_deref(), Some("big.png"));
    }

    #[test]
    fn fabric_survives_an_author_shaped_oddly() {
        let parsed = parse_fabric(r#"{"id": "x", "name": "X", "authors": [["nested"], "Real"]}"#)
            .expect("one odd author must not sink the manifest");

        assert_eq!(parsed.author_line(), "Real");
    }

    #[test]
    fn quilt_reads_contributor_names() {
        let parsed = parse_quilt(
            r#"{
				"schema_version": 1,
				"quilt_loader": {
					"id": "example",
					"metadata": {
						"name": "Example",
						"description": "Does things",
						"contributors": {"Alice": "Owner", "Bob": "Author"},
						"icon": "assets/example/icon.png"
					}
				}
			}"#,
        )
        .expect("valid quilt manifest");

        assert_eq!(parsed.name.as_deref(), Some("Example"));
        assert_eq!(parsed.author_line(), "Alice, Bob");
        assert_eq!(
            parsed.icon_entry.as_deref(),
            Some("assets/example/icon.png")
        );
    }

    #[test]
    fn quilt_keeps_the_mod_id_without_metadata() {
        let parsed = parse_quilt(
            r#"{"schema_version": 1, "quilt_loader": {"id": "example", "version": "1.2.0"}}"#,
        )
        .expect("metadata is optional in quilt");

        assert_eq!(parsed.mod_id.as_deref(), Some("example"));
        assert_eq!(parsed.version.as_deref(), Some("1.2.0"));
        assert!(parsed.is_empty());
    }

    #[test]
    fn forge_reads_the_first_mod_entry() {
        let parsed = parse_forge(
            r#"
modLoader="javafml"
loaderVersion="[47,)"
license="MIT"

[[mods]]
modId="examplemod"
version="1.0.0"
displayName="Example Mod"
authors="Someone"
logoFile="examplemod.png"
description='''
A mod that
spans lines
'''

[[dependencies.examplemod]]
modId="forge"
mandatory=true
"#,
        )
        .expect("valid forge manifest");

        assert_eq!(parsed.name.as_deref(), Some("Example Mod"));
        assert_eq!(
            parsed.description.as_deref(),
            Some("A mod that spans lines")
        );
        assert_eq!(parsed.author_line(), "Someone");
        assert_eq!(parsed.icon_entry.as_deref(), Some("examplemod.png"));
    }

    #[test]
    fn forge_falls_back_to_credits_and_a_root_logo() {
        let parsed = parse_forge(
            r#"
logoFile="logo.png"

[[mods]]
modId="x"
displayName="X"
credits="Thanks to everyone"
"#,
        )
        .expect("valid forge manifest");

        assert_eq!(parsed.author_line(), "Thanks to everyone");
        assert_eq!(parsed.icon_entry.as_deref(), Some("logo.png"));
    }

    #[test]
    fn legacy_forge_reads_both_shapes() {
        let bare = parse_legacy_forge(
			r#"[{"modid":"x","name":"X","description":"Old","authorList":["A","B"],"logoFile":"/logo.png"}]"#,
		)
		.expect("valid mcmod.info");

        assert_eq!(bare.name.as_deref(), Some("X"));
        assert_eq!(bare.author_line(), "A, B");
        assert_eq!(
            bare.icon_entry.as_deref(),
            Some("logo.png"),
            "the leading slash is jar relative not absolute"
        );

        let wrapped = parse_legacy_forge(
            r#"{"modListVersion":2,"modList":[{"modid":"y","name":"Y","authorList":["C"]}]}"#,
        )
        .expect("valid v2 mcmod.info");

        assert_eq!(wrapped.name.as_deref(), Some("Y"));
    }

    #[test]
    fn reads_mod_id_and_version_but_not_placeholders() {
        let fabric =
            parse_fabric(r#"{"id":"sodium-extra","version":"0.9.4+mc26.2"}"#).expect("fabric");
        assert_eq!(fabric.mod_id.as_deref(), Some("sodium-extra"));
        assert_eq!(fabric.version.as_deref(), Some("0.9.4+mc26.2"));

        let forge = parse_forge("[[mods]]\nmodId = \"jei\"\nversion = \"${file.jarVersion}\"\n")
            .expect("forge");
        assert_eq!(forge.mod_id.as_deref(), Some("jei"));
        assert_eq!(forge.version, None);
    }

    #[test]
    fn a_second_manifest_only_fills_gaps() {
        let mut fabric = JarManifest {
            name: Some("Fabric Name".into()),
            ..JarManifest::default()
        };
        fabric.fill_from(JarManifest {
            name: Some("Forge Name".into()),
            description: Some("From forge".into()),
            authors: vec!["Someone".into()],
            icon_entry: Some("logo.png".into()),
            ..JarManifest::default()
        });

        assert_eq!(fabric.name.as_deref(), Some("Fabric Name"));
        assert_eq!(fabric.description.as_deref(), Some("From forge"));
        assert_eq!(fabric.author_line(), "Someone");
        assert_eq!(fabric.icon_entry.as_deref(), Some("logo.png"));
    }

    #[test]
    fn traversing_icon_paths_are_refused() {
        assert_eq!(entry_path("../../etc/passwd".into()), None);
        assert_eq!(entry_path("   ".into()), None);
        assert_eq!(entry_path("./icon.png".into()).as_deref(), Some("icon.png"));
    }

    #[test]
    fn long_descriptions_are_cut_on_a_char_boundary() {
        let long = "ż".repeat(MAX_DESCRIPTION + 50);
        let cut = clean_description(Some(long)).expect("non empty");

        assert_eq!(
            cut.chars().count(),
            MAX_DESCRIPTION + 1,
            "the ellipsis is the extra one"
        );
        assert!(cut.ends_with('…'));
    }

    #[test]
    fn garbage_is_not_a_manifest() {
        assert!(parse_fabric("not json").is_none());
        assert!(parse_forge("[[mods").is_none());
        assert!(
            parse_forge("modLoader=\"javafml\"").is_none(),
            "no mod entry to describe"
        );
    }

    #[test]
    fn fabric_dependencies_list_depends_keys() {
        let parsed = parse_dependencies(
            FABRIC,
            r#"{"id":"Sodium-Extra","provides":["extras"],"depends":{"sodium":"*","fabric-api":"*"},"recommends":{"modmenu":"*"}}"#,
        )
        .unwrap();
        assert_eq!(parsed.provides, ["sodium-extra", "extras"]);
        // `depends` is a JSON object, so its keys come back in whatever order
        // serde_json's map keeps, which depends on whether `preserve_order` is
        // enabled anywhere in the build. The caller sorts them anyway.
        let mut requires = parsed.requires;
        requires.sort();
        assert_eq!(requires, ["fabric-api", "sodium"]);
    }

    #[test]
    fn quilt_skips_optional_dependencies() {
        let parsed = parse_dependencies(
            QUILT,
            r#"{"quilt_loader":{"id":"a","depends":["b",{"id":"c"},{"id":"d","optional":true}]}}"#,
        )
        .unwrap();
        assert_eq!(parsed.provides, ["a"]);
        assert_eq!(parsed.requires, ["b", "c"]);
    }

    #[test]
    fn forge_reads_mandatory_and_typed_dependencies() {
        let parsed = parse_dependencies(
            FORGE,
            r#"
            [[mods]]
            modId = "examplemod2"

            [[dependencies.examplemod2]]
            modId = "forge"
            mandatory = true

            [[dependencies.examplemod2]]
            modId = "jei"
            mandatory = false

            [[dependencies.examplemod2]]
            modId = "cloth_config"
            type = "required"

            [[dependencies.examplemod2]]
            modId = "emi"
            type = "optional"
            "#,
        )
        .unwrap();
        assert_eq!(parsed.provides, ["examplemod2"]);
        assert_eq!(parsed.requires, ["forge", "cloth_config"]);
    }

    #[test]
    fn legacy_forge_strips_version_from_required_mods() {
        let parsed = parse_dependencies(
            LEGACY_FORGE,
            r#"[{"modid":"skyblockaddons","requiredMods":["oneconfig@[1.0,)"]}]"#,
        )
        .unwrap();
        assert_eq!(parsed.provides, ["skyblockaddons"]);
        assert_eq!(parsed.requires, ["oneconfig"]);
    }
}
